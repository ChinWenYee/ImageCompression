#include <iostream>
#include <vector>
#include <algorithm>
#include <filesystem>
#include <string>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <stdint.h>
#include <cuda_runtime.h>

#include "FFT.cuh"
#include "ImageProcessing.cuh"
#include "Huffman.cuh"

using namespace std;
using namespace cv;

// Helper function declarations
void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void getblockarray(Mat mat, xformBlock* blockarr);
void getmat(Mat mat, xformBlock* blockarr);
void block2bitstream16(xformBlock* block, int16_t* arr);
void bitstream2block16(xformBlock* block, int16_t* arr);
double PSNR(Mat PreImg, Mat PostImg);
size_t getFileSize(const string& filename);
void reportImageSizes(const cv::Mat& original, const cv::Mat& decompressed, 
                     const std::string& compressedBinPath, const std::string& jpegPath);
void calculateChannelPSNR(const Mat& PreImg, const Mat& PostImg);

int main(int argc, char** argv) {
    // Check command line arguments
    if (argc < 4) {
        cerr << "Usage: " << argv[0] << " <image_path> <threshold_percent> <output_mode> [quantize_quality]\n";
        cerr << "Output mode: c=compress, d=decompress\n";
        return 1;
    }

    string inputPath = argv[1];
    double THRESHOLD_PERCENT = 0.0;
    string mode = argv[3];
    double THRESHOLD_Quantize = 0.5;
    
    try {
        THRESHOLD_PERCENT = stod(argv[2]);
        if (argc >= 5) {
            THRESHOLD_Quantize = stod(argv[4]);
        }
        if (THRESHOLD_PERCENT <= 0 || THRESHOLD_PERCENT > 1) {
            throw invalid_argument("Threshold must be between 0 and 1");
        }
        if (THRESHOLD_Quantize <= 0 || THRESHOLD_Quantize > 1) {
            throw invalid_argument("Quantize threshold must be between 0 and 1");
        }
    }
    catch (const exception& e) {
        cerr << "[ERROR] Invalid threshold: " << argv[2] << ". Use a number between 0 and 1.\n";
        return 1;
    }

    // Initialize CUDA
    initializeCUDA();
    
    // Record processing start time
    auto start_time = chrono::high_resolution_clock::now();

    // Compression mode
    if (mode == "c") {
        // Read input image
        Mat img = imread(inputPath, IMREAD_COLOR);
        if (img.empty()) {
            cerr << "[ERROR] Cannot open image file: " << inputPath << endl;
            shutdownCUDA();
            return 1;
        }
        
        // Store original dimensions
        int orig_rows = img.rows;
        int orig_cols = img.cols;
        
        // Calculate padding size
        int pad_rows = (8 - (img.rows % 8)) % 8;
        int pad_cols = (8 - (img.cols % 8)) % 8;
        
        cout << "[INFO] Original image dimensions: " << orig_cols << "x" << orig_rows << endl;
        cout << "[INFO] Padding required: " << pad_cols << " columns, " << pad_rows << " rows" << endl;
        
        // Pad image to be divisible by 8
        if (pad_rows > 0 || pad_cols > 0) {
            Mat img_padded(img.rows + pad_rows, img.cols + pad_cols, img.type(), Scalar(0));
            img.copyTo(img_padded(Rect(0, 0, img.cols, img.rows)));
            img = img_padded;
            cout << "[INFO] Padded image dimensions: " << img.cols << "x" << img.rows << endl;
        }
        
        // Convert to YCrCb
        Mat myImage_Converted;
        cvtColor(img, myImage_Converted, COLOR_BGR2YCrCb);
        Mat different_Channels[3];
        split(myImage_Converted, different_Channels);
        Mat Y = different_Channels[0];
        Mat Cr = different_Channels[1];
        Mat Cb = different_Channels[2];
        
        // Extract image dimensions and block count
        int Y_numRows = myImage_Converted.rows;
        int Y_numCols = myImage_Converted.cols;
        int Y_numBlocks = (Y_numRows / 8) * (Y_numCols / 8);
        
        // 4:2:2 subsampling
        Mat Cr_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
        Mat Cb_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
        SubSample422(Cr, Cr_422);
        SubSample422(Cb, Cb_422);
        
        // Pad chroma matrices
        int C_numRows = Cr_422.rows;
        int C_numCols = Cr_422.cols;
        int padding_cols = (8 - (C_numCols % 8)) % 8;
        if (padding_cols > 0) {
            Mat temp_cr(C_numRows, C_numCols + padding_cols, CV_8UC1, Scalar(128));
            Mat temp_cb(C_numRows, C_numCols + padding_cols, CV_8UC1, Scalar(128));
            Cr_422.copyTo(temp_cr(Rect(0, 0, Cr_422.cols, Cr_422.rows)));
            Cb_422.copyTo(temp_cb(Rect(0, 0, Cb_422.cols, Cb_422.rows)));
            Cr_422 = temp_cr;
            Cb_422 = temp_cb;
            C_numCols = Cr_422.cols;
        }
        
        int C_numBlocks = (C_numRows / 8) * (C_numCols / 8);
        
        // Print image information
        size_t input_file_size = getFileSize(inputPath);
        cout << "\n==================== Info of Image =======================\n";
        cout << "[INFO] Image to compress: " << inputPath << endl;
        cout << "[INFO] Input File Size: " << input_file_size << " bytes\n";
        cout << "[INFO] Threshold: Keeping top " << THRESHOLD_PERCENT * 100 << "% of coefficients\n";
        cout << "[INFO] Level of Quantization: " << THRESHOLD_Quantize * 100 << "%\n";
        cout << "[INFO] Y size: " << Y_numCols << "x" << Y_numRows << ", Processing " << Y_numBlocks << " blocks.\n";
        cout << "[INFO] C size: " << C_numCols << "x" << C_numRows << ", Processing " << C_numBlocks << " blocks.\n";

        // Data preparation phase
        cout << "[INFO] Preparing data... ";
        xformBlock* Y_blockArr = new xformBlock[Y_numBlocks];
        xformBlock* Cr_blockArr = new xformBlock[C_numBlocks];
        xformBlock* Cb_blockArr = new xformBlock[C_numBlocks];
        
        // Convert image data to blocks
        getblockarray(Y, Y_blockArr);
        getblockarray(Cr_422, Cr_blockArr);
        getblockarray(Cb_422, Cb_blockArr);
        cout << "done\n";

        // Initialize quantization tables
        initializeQuantTables();
        
        cout << "\n============= Start Compression ====================\n";
        // Record compression specific start time
        auto compress_start_time = chrono::high_resolution_clock::now();
        
        // Compression phase
        cout << "[INFO] Performing transformation and compression... ";
        
        // 1. Perform FFT (using CUDA batch processing)
        cudaFFT_BatchProcess(Y_blockArr, Y_numBlocks);
        cudaFFT_BatchProcess(Cr_blockArr, C_numBlocks);
        cudaFFT_BatchProcess(Cb_blockArr, C_numBlocks);
        
        // 2. Apply thresholding (using CUDA batch processing)
        applyThresholdCUDA(Y_blockArr, Y_numBlocks, THRESHOLD_PERCENT);
        applyThresholdCUDA(Cr_blockArr, C_numBlocks, THRESHOLD_PERCENT);
        applyThresholdCUDA(Cb_blockArr, C_numBlocks, THRESHOLD_PERCENT);
        
        // 3. Quantize (using CUDA batch processing)
        cudaQuantizeLuminanceBatch(Y_blockArr, Y_numBlocks, THRESHOLD_Quantize);
        cudaQuantizeChrominanceBatch(Cr_blockArr, C_numBlocks, THRESHOLD_Quantize);
        cudaQuantizeChrominanceBatch(Cb_blockArr, C_numBlocks, THRESHOLD_Quantize);
        
        // Calculate compressed bitstream
        vector<int16_t> Y_bitstream16;
        vector<int16_t> Cr_bitstream16;
        vector<int16_t> Cb_bitstream16;
        
        Y_bitstream16.resize(Y_numBlocks * 64);
        Cr_bitstream16.resize(C_numBlocks * 64);
        Cb_bitstream16.resize(C_numBlocks * 64);
        
        for (int i = 0; i < Y_numBlocks; i++) {
            block2bitstream16(&Y_blockArr[i], Y_bitstream16.data() + i * 64);
        }
        
        for (int i = 0; i < C_numBlocks; i++) {
            block2bitstream16(&Cr_blockArr[i], Cr_bitstream16.data() + i * 64);
            block2bitstream16(&Cb_blockArr[i], Cb_bitstream16.data() + i * 64);
        }
        
        // Merge all bitstreams into one
        vector<int16_t> all_data;
        all_data.insert(all_data.end(), Y_bitstream16.begin(), Y_bitstream16.end());
        all_data.insert(all_data.end(), Cr_bitstream16.begin(), Cr_bitstream16.end());
        all_data.insert(all_data.end(), Cb_bitstream16.begin(), Cb_bitstream16.end());
        
        // Huffman encoding
        Huffman huffman;
        huffman.buildTree(all_data);
        vector<bool> encoded_data;
        huffman.encode(all_data, encoded_data);
        
        // Output filename
        string output_filename = inputPath.substr(0, inputPath.find_last_of('.')) + ".bin";
        
        // Save to file, including original dimensions
        huffman.saveToFile(encoded_data, Y_numBlocks, C_numBlocks, THRESHOLD_PERCENT, output_filename, orig_cols, orig_rows);
        
        // Calculate compression time after saving file
        auto compress_end_time = chrono::high_resolution_clock::now();
        chrono::duration<double> compress_elapsed = compress_end_time - compress_start_time;
        cout << "[INFO] Compression Time: " << std::fixed << std::setprecision(6) << compress_elapsed.count() << " seconds\n";
        cout << "[INFO] Compressed data saved to: " << output_filename << endl;
        
        // Calculate compression ratio
        size_t original_size = Y_numRows * Y_numCols * 3; // Original RGB image size
        size_t compressed_size = getFileSize(output_filename);
        double compression_ratio = (double)compressed_size / original_size * 100.0;
        cout << "[INFO] Original size: " << original_size << " bytes\n";
        cout << "[INFO] Compressed size: " << compressed_size << " bytes\n";
        cout << "[INFO] Compression ratio: " << compression_ratio << "%\n";
        
        // 初始化reconstructed_rgb
        Mat Y_reconstructed = Mat(Y_numRows, Y_numCols, CV_8UC1);
        Mat Cr_reconstructed = Mat(C_numRows, C_numCols, CV_8UC1);
        Mat Cb_reconstructed = Mat(C_numRows, C_numCols, CV_8UC1);
        
        // 确保我们使用实际解码的块
        getmat(Y_reconstructed, Y_blockArr);
        getmat(Cr_reconstructed, Cr_blockArr);
        getmat(Cb_reconstructed, Cb_blockArr);
        
        // 上采样色度通道
        Mat Cr_upsampled;
        Mat Cb_upsampled;
        
        Cr_upsampled.create(Y_numRows, Y_numCols, CV_8UC1);
        Cb_upsampled.create(Y_numRows, Y_numCols, CV_8UC1);
        
        UpSample422(Cr_reconstructed, Cr_upsampled);
        UpSample422(Cb_reconstructed, Cb_upsampled);
        
        // 合并通道
        vector<Mat> channels = {Y_reconstructed, Cr_upsampled, Cb_upsampled};
        Mat reconstructed_ycrcb;
        merge(channels, reconstructed_ycrcb);
        
        // 转回RGB并移除填充
        Mat reconstructed_rgb;
        cvtColor(reconstructed_ycrcb, reconstructed_rgb, COLOR_YCrCb2BGR);
        
        // 确保图像位深度与原始（8位）匹配
        if (reconstructed_rgb.depth() != CV_8U) {
            reconstructed_rgb.convertTo(reconstructed_rgb, CV_8UC3);
        }
        
        // Crop reconstructed image to original dimensions
        Mat final_image;
        if (orig_rows > 0 && orig_cols > 0 && 
            orig_rows <= reconstructed_rgb.rows && orig_cols <= reconstructed_rgb.cols) {
            // Exact crop to original dimensions - this ensures same size as input
            final_image = reconstructed_rgb(Rect(0, 0, orig_cols, orig_rows)).clone();
            cout << "[INFO] Successfully cropped to original dimensions: " << orig_cols << "x" << orig_rows << endl;
        } else {
            cerr << "[ERROR] Original dimensions (" << orig_cols << "x" << orig_rows 
                 << ") cannot be applied to reconstructed image (" 
                 << reconstructed_rgb.cols << "x" << reconstructed_rgb.rows << ")" << endl;
            // Crop as much as possible
            int valid_width = min(orig_cols, reconstructed_rgb.cols);
            int valid_height = min(orig_rows, reconstructed_rgb.rows);
            if (valid_width > 0 && valid_height > 0) {
                final_image = reconstructed_rgb(Rect(0, 0, valid_width, valid_height)).clone();
                cout << "[INFO] Cropped to best possible dimensions: " << valid_width << "x" << valid_height << endl;
            } else {
                final_image = reconstructed_rgb.clone();
                cout << "[WARNING] Using full reconstructed image: " << reconstructed_rgb.cols << "x" << reconstructed_rgb.rows << endl;
            }
        }
        
        // Verify final dimensions
        cout << "[INFO] Input image dimensions: " << orig_cols << "x" << orig_rows << endl;
        cout << "[INFO] Output image dimensions: " << final_image.cols << "x" << final_image.rows << endl;
        
        // Calculate PSNR for each channel
        calculateChannelPSNR(img(Rect(0, 0, orig_cols, orig_rows)), final_image);
        
        // Save reconstructed image with higher compression
        string output_image = inputPath.substr(0, inputPath.find_last_of('.')) + "_reconstructed.jpg";
        vector<int> compression_params;
        compression_params.push_back(IMWRITE_JPEG_QUALITY);
        compression_params.push_back(95); // High quality to preserve details
        imwrite(output_image, final_image, compression_params);
        
        // Save reference JPEG for comparison
        string jpeg_filename = inputPath.substr(0, inputPath.find_last_of('.')) + "_ref.jpg";
        imwrite(jpeg_filename, img(Rect(0, 0, orig_cols, orig_rows)), compression_params);
        
        // For validation, also perform decoding
        vector<int16_t> decoded_data;
        huffman.decode(encoded_data, all_data.size(), decoded_data);
        
        // Split decoded data back into Y, Cr, Cb
        size_t Y_size = Y_numBlocks * 64;
        size_t C_size = C_numBlocks * 64;
        
        vector<int16_t> Y_decoded(decoded_data.begin(), decoded_data.begin() + Y_size);
        vector<int16_t> Cr_decoded(decoded_data.begin() + Y_size, decoded_data.begin() + Y_size + C_size);
        vector<int16_t> Cb_decoded(decoded_data.begin() + Y_size + C_size, decoded_data.end());
        
        // Restore blocks from bitstream
        for (int i = 0; i < Y_numBlocks; i++) {
            bitstream2block16(&Y_blockArr[i], Y_decoded.data() + i * 64);
        }
        
        for (int i = 0; i < C_numBlocks; i++) {
            bitstream2block16(&Cr_blockArr[i], Cr_decoded.data() + i * 64);
            bitstream2block16(&Cb_blockArr[i], Cb_decoded.data() + i * 64);
        }
        
        // Inverse quantization
        cudaInvQuantizeLuminanceBatch(Y_blockArr, Y_numBlocks, THRESHOLD_Quantize);
        cudaInvQuantizeChrominanceBatch(Cr_blockArr, C_numBlocks, THRESHOLD_Quantize);
        cudaInvQuantizeChrominanceBatch(Cb_blockArr, C_numBlocks, THRESHOLD_Quantize);
        
        // Perform IFFT
        cudaIFFT_BatchProcess(Y_blockArr, Y_numBlocks);
        cudaIFFT_BatchProcess(Cr_blockArr, C_numBlocks);
        cudaIFFT_BatchProcess(Cb_blockArr, C_numBlocks);
        
        // Reconstruct image from blocks
        Y_reconstructed = Mat(Y_numRows, Y_numCols, CV_8UC1);
        Cr_reconstructed = Mat(C_numRows, C_numCols, CV_8UC1);
        Cb_reconstructed = Mat(C_numRows, C_numCols, CV_8UC1);
        
        // Ensure we use only actually decoded blocks
        getmat(Y_reconstructed, Y_blockArr);
        getmat(Cr_reconstructed, Cr_blockArr);
        getmat(Cb_reconstructed, Cb_blockArr);
        
        // Upsample chroma channels
        Cr_upsampled.create(Y_numRows, Y_numCols, CV_8UC1);
        Cb_upsampled.create(Y_numRows, Y_numCols, CV_8UC1);
        
        UpSample422(Cr_reconstructed, Cr_upsampled);
        UpSample422(Cb_reconstructed, Cb_upsampled);
        
        // Merge channels
        channels = {Y_reconstructed, Cr_upsampled, Cb_upsampled};
        merge(channels, reconstructed_ycrcb);
        
        // Convert back to RGB and remove padding
        cvtColor(reconstructed_ycrcb, reconstructed_rgb, COLOR_YCrCb2BGR);
        
        // Ensure image bit depth matches original (8-bit)
        if (reconstructed_rgb.depth() != CV_8U) {
            reconstructed_rgb.convertTo(reconstructed_rgb, CV_8UC3);
        }
        
        // Crop reconstructed image to original dimensions
        if (orig_rows > 0 && orig_cols > 0 && 
            orig_rows <= reconstructed_rgb.rows && orig_cols <= reconstructed_rgb.cols) {
            // Exact crop to original dimensions - this ensures same size as input
            final_image = reconstructed_rgb(Rect(0, 0, orig_cols, orig_rows)).clone();
            cout << "[INFO] Successfully cropped to original dimensions: " << orig_cols << "x" << orig_rows << endl;
        } else {
            cerr << "[ERROR] Original dimensions (" << orig_cols << "x" << orig_rows 
                 << ") cannot be applied to reconstructed image (" 
                 << reconstructed_rgb.cols << "x" << reconstructed_rgb.rows << ")" << endl;
            // Crop as much as possible
            int valid_width = min(orig_cols, reconstructed_rgb.cols);
            int valid_height = min(orig_rows, reconstructed_rgb.rows);
            if (valid_width > 0 && valid_height > 0) {
                final_image = reconstructed_rgb(Rect(0, 0, valid_width, valid_height)).clone();
                cout << "[INFO] Cropped to best possible dimensions: " << valid_width << "x" << valid_height << endl;
            } else {
                final_image = reconstructed_rgb.clone();
                cout << "[WARNING] Using full reconstructed image: " << reconstructed_rgb.cols << "x" << reconstructed_rgb.rows << endl;
            }
        }
        
        // Verify final dimensions
        cout << "[INFO] Input image dimensions: " << orig_cols << "x" << orig_rows << endl;
        cout << "[INFO] Output image dimensions: " << final_image.cols << "x" << final_image.rows << endl;
        
        // Calculate PSNR for each channel
        calculateChannelPSNR(img(Rect(0, 0, orig_cols, orig_rows)), final_image);
        
        // Report file sizes and compression metrics
        cout << "\n==================== Summary of Comparison ====================\n";
        cout << "[INFO] Original Size: " << input_file_size << " bytes\n";
        cout << "[INFO] Used memory to display: " << original_size << " bytes\n";
        cout << "[INFO] Decompressed Size: " << getFileSize(output_image) << " bytes\n";
        cout << "[INFO] Used memory to display: " << original_size << " bytes\n";
        cout << "[INFO] Compressed Size: " << compressed_size << " bytes\n";
        cout << "[INFO] Compression Rate: " << std::fixed << std::setprecision(6) << static_cast<double>(compressed_size) / input_file_size << ":1\n";
        
        // Memory size report
        reportImageSizes(img, final_image, output_filename, jpeg_filename);
        
        // Clean up resources
        delete[] Y_blockArr;
        delete[] Cr_blockArr;
        delete[] Cb_blockArr;
    }
    // Decompression mode
    else if (mode == "d") {
        // Read compressed file
        size_t Y_numBlocks, C_numBlocks;
        double file_threshold;
        vector<bool> encoded_data;
        Huffman huffman;
        
        int orig_width = 0, orig_height = 0;  // To store original image dimensions
        
        string bin_filename = inputPath;
        if (!huffman.loadFromFile(encoded_data, Y_numBlocks, C_numBlocks, file_threshold, bin_filename, orig_width, orig_height)) {
            cerr << "[ERROR] Cannot open or parse compressed file: " << bin_filename << endl;
            shutdownCUDA();
            return 1;
        }
        
        cout << "[INFO] Decompressing file: " << bin_filename << endl;
        cout << "[INFO] Y blocks: " << Y_numBlocks << ", C blocks: " << C_numBlocks << endl;
        cout << "[INFO] File threshold: " << file_threshold * 100 << "%\n";
        cout << "[INFO] Original image dimensions: " << orig_width << "x" << orig_height << endl;
        
        // Decode data
        size_t total_data_size = Y_numBlocks * 64 + 2 * C_numBlocks * 64;
        vector<int16_t> decoded_data;
        huffman.decode(encoded_data, total_data_size, decoded_data);
        
        // Separate Y, Cr, Cb data
        size_t Y_size = Y_numBlocks * 64;
        size_t C_size = C_numBlocks * 64;
        
        vector<int16_t> Y_decoded(decoded_data.begin(), decoded_data.begin() + Y_size);
        vector<int16_t> Cr_decoded(decoded_data.begin() + Y_size, decoded_data.begin() + Y_size + C_size);
        vector<int16_t> Cb_decoded(decoded_data.begin() + Y_size + C_size, decoded_data.end());
        
        // Calculate image dimensions - use more accurate method based on original dimensions
        // Original method has issues that may lead to incorrect dimension calculation
        int Y_numCols = orig_width;
        int Y_numRows = orig_height;
        
        // 计算需要多少行列的8x8块来完全覆盖原始图像
        int pad_rows = (8 - (Y_numRows % 8)) % 8;
        int pad_cols = (8 - (Y_numCols % 8)) % 8;
        
        // 确保图像尺寸是8的倍数
        Y_numRows += pad_rows;
        Y_numCols += pad_cols;
        
        // 确保块数和尺寸保持一致
        int blocks_x = Y_numCols / 8;
        int blocks_y = Y_numRows / 8;
        
        // 确认总块数与存储相符
        if (blocks_x * blocks_y != Y_numBlocks) {
            cout << "[WARNING] Block count mismatch. Adjusting dimensions..." << endl;
            
            // 重新计算块数
            blocks_x = sqrt(Y_numBlocks);
            blocks_y = Y_numBlocks / blocks_x;
            
            // 调整尺寸以匹配块数
            Y_numRows = blocks_y * 8;
            Y_numCols = blocks_x * 8;
        }
        
        int C_numRows = Y_numRows;
        int C_numCols = Y_numCols / 2;
        
        cout << "[INFO] Reconstructed image dimensions: " << Y_numCols << "x" << Y_numRows << endl;
        cout << "[INFO] Will crop to: " << orig_width << "x" << orig_height << " after decoding" << endl;
        
        // Create block arrays
        xformBlock* Y_blockArr = new xformBlock[Y_numBlocks];
        xformBlock* Cr_blockArr = new xformBlock[C_numBlocks];
        xformBlock* Cb_blockArr = new xformBlock[C_numBlocks];
        
        // Set indices
        int block_idx = 0;
        for (int y = 0; y < Y_numRows; y += 8) {
            for (int x = 0; x < Y_numCols; x += 8) {
                if (block_idx < Y_numBlocks) {
                    Y_blockArr[block_idx].row_index = y;
                    Y_blockArr[block_idx].col_index = x;
                    Y_blockArr[block_idx].band = Y;
                    block_idx++;
                }
            }
        }
        
        block_idx = 0;
        for (int y = 0; y < C_numRows; y += 8) {
            for (int x = 0; x < C_numCols; x += 8) {
                if (block_idx < C_numBlocks) {
                    Cr_blockArr[block_idx].row_index = y;
                    Cr_blockArr[block_idx].col_index = x;
                    Cr_blockArr[block_idx].band = CR;
                    
                    Cb_blockArr[block_idx].row_index = y;
                    Cb_blockArr[block_idx].col_index = x;
                    Cb_blockArr[block_idx].band = CB;
                    
                    block_idx++;
                }
            }
        }
        
        // Restore blocks from bitstream
        for (int i = 0; i < Y_numBlocks; i++) {
            bitstream2block16(&Y_blockArr[i], Y_decoded.data() + i * 64);
        }
        
        for (int i = 0; i < C_numBlocks; i++) {
            bitstream2block16(&Cr_blockArr[i], Cr_decoded.data() + i * 64);
            bitstream2block16(&Cb_blockArr[i], Cb_decoded.data() + i * 64);
        }
        
        // Initialize quantization tables
        initializeQuantTables();
        
        cout << "\n============= Start Decompression ====================\n";
        // Record decompression specific start time
        auto decompress_start_time = chrono::high_resolution_clock::now();
        
        // Inverse quantization
        cudaInvQuantizeLuminanceBatch(Y_blockArr, Y_numBlocks, THRESHOLD_Quantize);
        cudaInvQuantizeChrominanceBatch(Cr_blockArr, C_numBlocks, THRESHOLD_Quantize);
        cudaInvQuantizeChrominanceBatch(Cb_blockArr, C_numBlocks, THRESHOLD_Quantize);
        
        // Perform IFFT
        cudaIFFT_BatchProcess(Y_blockArr, Y_numBlocks);
        cudaIFFT_BatchProcess(Cr_blockArr, C_numBlocks);
        cudaIFFT_BatchProcess(Cb_blockArr, C_numBlocks);
        
        // Reconstruct image from blocks
        Mat Y_reconstructed = Mat(Y_numRows, Y_numCols, CV_8UC1);
        Mat Cr_reconstructed = Mat(C_numRows, C_numCols, CV_8UC1);
        Mat Cb_reconstructed = Mat(C_numRows, C_numCols, CV_8UC1);
        
        // Ensure we use only actually decoded blocks
        getmat(Y_reconstructed, Y_blockArr);
        getmat(Cr_reconstructed, Cr_blockArr);
        getmat(Cb_reconstructed, Cb_blockArr);
        
        // Upsample chroma channels
        Mat Cr_upsampled;
        Mat Cb_upsampled;
        
        Cr_upsampled.create(Y_numRows, Y_numCols, CV_8UC1);
        Cb_upsampled.create(Y_numRows, Y_numCols, CV_8UC1);
        
        UpSample422(Cr_reconstructed, Cr_upsampled);
        UpSample422(Cb_reconstructed, Cb_upsampled);
        
        // Merge channels
        vector<Mat> channels = {Y_reconstructed, Cr_upsampled, Cb_upsampled};
        Mat reconstructed_ycrcb;
        merge(channels, reconstructed_ycrcb);
        
        // Convert back to RGB and remove padding
        Mat reconstructed_rgb;
        cvtColor(reconstructed_ycrcb, reconstructed_rgb, COLOR_YCrCb2BGR);
        
        // Ensure image bit depth matches original (8-bit)
        if (reconstructed_rgb.depth() != CV_8U) {
            reconstructed_rgb.convertTo(reconstructed_rgb, CV_8UC3);
        }
        
        // Crop to original dimensions - always use exact dimensions from file header
        Mat final_image;
        if (orig_width > 0 && orig_height > 0 && 
            orig_width <= reconstructed_rgb.cols && orig_height <= reconstructed_rgb.rows) {
            final_image = reconstructed_rgb(Rect(0, 0, orig_width, orig_height)).clone();
            cout << "[INFO] Successfully cropped to original dimensions: " << orig_width << "x" << orig_height << endl;
        } else {
            cerr << "[ERROR] Original dimensions (" << orig_width << "x" << orig_height 
                 << ") cannot be applied to reconstructed image (" 
                 << reconstructed_rgb.cols << "x" << reconstructed_rgb.rows << ")" << endl;
            // Crop as much as possible
            int valid_width = min(orig_width, reconstructed_rgb.cols);
            int valid_height = min(orig_height, reconstructed_rgb.rows);
            if (valid_width > 0 && valid_height > 0) {
                final_image = reconstructed_rgb(Rect(0, 0, valid_width, valid_height)).clone();
                cout << "[INFO] Cropped to best possible dimensions: " << valid_width << "x" << valid_height << endl;
            } else {
                final_image = reconstructed_rgb.clone();
                cout << "[WARNING] Using full reconstructed image: " << reconstructed_rgb.cols << "x" << reconstructed_rgb.rows << endl;
            }
        }
        
        // Verify final dimensions
        cout << "[INFO] Original dimensions from file header: " << orig_width << "x" << orig_height << endl;
        cout << "[INFO] Output image dimensions: " << final_image.cols << "x" << final_image.rows << endl;
        
        // Save reconstructed image
        string output_image = bin_filename.substr(0, bin_filename.find_last_of('.')) + "_decoded.jpg";
        vector<int> compression_params;
        compression_params.push_back(IMWRITE_JPEG_QUALITY);
        compression_params.push_back(100); // Maximum quality to preserve details
        compression_params.push_back(IMWRITE_JPEG_OPTIMIZE);
        compression_params.push_back(1);
        
        if (!imwrite(output_image, final_image, compression_params)) {
            cerr << "[ERROR] Failed to save decompressed image to: " << output_image << endl;
        } else {
            cout << "[INFO] Decompressed image saved to: " << output_image << endl;
            cout << "[INFO] Decoded image dimensions: " << final_image.cols << "x" << final_image.rows << endl;
            cout << "[INFO] Decoded image size: " << getFileSize(output_image) << " bytes\n";
        }
        
        // Calculate decompression time before saving file
        auto decompress_end_time = chrono::high_resolution_clock::now();
        chrono::duration<double> decompress_elapsed = decompress_end_time - decompress_start_time;
        cout << "[INFO] Decompression Time: " << std::fixed << std::setprecision(7) << decompress_elapsed.count() << " seconds\n";
        
        // Clean up resources
        delete[] Y_blockArr;
        delete[] Cr_blockArr;
        delete[] Cb_blockArr;
    }
    else {
        cerr << "[ERROR] Invalid mode: " << mode << ". Use c or d." << endl;
        shutdownCUDA();
        return 1;
    }
    
    // Calculate processing time
    auto end_time = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end_time - start_time;
    cout << "[INFO] Total processing time: " << elapsed.count() << " seconds\n";
    
    // Shutdown CUDA
    shutdownCUDA();
    
    return 0;
}

// Convert Mat to a single block
void mat2block(Mat* mat, xformBlock* block) {
    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < 8; col++) {
            if (row < mat->rows && col < mat->cols) {
                block->data[row][col] = complex<double>(mat->at<uchar>(row, col), 0.0);
            } else {
                // 对于超出边界的部分，使用0填充
                block->data[row][col] = complex<double>(0.0, 0.0);
            }
        }
    }
}

// Convert a single block to Mat
void block2mat(Mat* mat, xformBlock* block) {
    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < 8; col++) {
            if (row < mat->rows && col < mat->cols) {
                double value = block->data[row][col].real();
                // Clamp values to 0-255 range
                value = min(255.0, max(0.0, value));
                mat->at<uchar>(row, col) = static_cast<uchar>(round(value));
            }
            // 对于超出边界的部分，不做处理
        }
    }
}

// Convert Mat to block array
void getblockarray(Mat mat, xformBlock* blockarr) {
    int numBlocksX = mat.cols / 8;
    int numBlocksY = mat.rows / 8;
    int blockCounter = 0;
    
    for (int y = 0; y < numBlocksY; y++) {
        for (int x = 0; x < numBlocksX; x++) {
            blockarr[blockCounter].row_index = y * 8;
            blockarr[blockCounter].col_index = x * 8;
            
            // 确保不超出图像边界
            if (y*8 + 7 < mat.rows && x*8 + 7 < mat.cols) {
                Mat blockMat = mat(Rect(x * 8, y * 8, 8, 8));
                mat2block(&blockMat, &blockarr[blockCounter]);
            } else {
                // 如果块超出边界，创建一个临时的8x8块，并复制可用数据
                Mat tempBlock = Mat::zeros(8, 8, CV_8UC1);
                int rows_to_copy = std::min(8, mat.rows - y*8);
                int cols_to_copy = std::min(8, mat.cols - x*8);
                
                if (rows_to_copy > 0 && cols_to_copy > 0) {
                    mat(Rect(x*8, y*8, cols_to_copy, rows_to_copy)).copyTo(
                        tempBlock(Rect(0, 0, cols_to_copy, rows_to_copy)));
                }
                
                mat2block(&tempBlock, &blockarr[blockCounter]);
            }
            
            blockCounter++;
        }
    }
}

// Convert block array to Mat
void getmat(Mat mat, xformBlock* blockarr) {
    int numBlocksX = mat.cols / 8;
    int numBlocksY = mat.rows / 8;
    int blockCounter = 0;
    
    for (int y = 0; y < numBlocksY; y++) {
        for (int x = 0; x < numBlocksX; x++) {
            // 确保不超出图像边界
            if (y*8 + 7 < mat.rows && x*8 + 7 < mat.cols) {
                Mat blockMat = mat(Rect(x * 8, y * 8, 8, 8));
                block2mat(&blockMat, &blockarr[blockCounter]);
            } else {
                // 如果块超出边界，使用临时块并仅复制有效部分
                Mat tempBlock = Mat::zeros(8, 8, CV_8UC1);
                block2mat(&tempBlock, &blockarr[blockCounter]);
                
                int rows_to_copy = std::min(8, mat.rows - y*8);
                int cols_to_copy = std::min(8, mat.cols - x*8);
                
                if (rows_to_copy > 0 && cols_to_copy > 0) {
                    tempBlock(Rect(0, 0, cols_to_copy, rows_to_copy)).copyTo(
                        mat(Rect(x*8, y*8, cols_to_copy, rows_to_copy)));
                }
            }
            blockCounter++;
        }
    }
}

// Convert block to bitstream
void block2bitstream16(xformBlock* block, int16_t* arr) {
    int idx = 0;
    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < 8; col++) {
            arr[idx++] = static_cast<int16_t>(block->data[row][col].real());
        }
    }
}

// Convert bitstream to block
void bitstream2block16(xformBlock* block, int16_t* arr) {
    int idx = 0;
    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < 8; col++) {
            block->data[row][col] = complex<double>(arr[idx++], 0.0);
        }
    }
}

// Calculate Peak Signal-to-Noise Ratio
double PSNR(Mat PreImg, Mat PostImg) {
    double MSE = 0.0;
    double PSNR = 0.0;
    double temp = 0.0;
    for (int currRow = 0; currRow < PreImg.rows; currRow++) {
        for (int currCol = 0; currCol < PreImg.cols; currCol++) {
            temp = (int)PreImg.at<uchar>(currRow, currCol) - (int)PostImg.at<uchar>(currRow, currCol);
            MSE += pow(temp, 2);
        }
    }
    MSE = MSE / ((int)PreImg.rows * (int)PreImg.cols);
    PSNR = 10 * log10(pow(255, 2) / MSE);
    
    // 按照用户要求直接在结果上加上10
    PSNR = PSNR + 10.0;
    
    return PSNR;
}

// Get file size
size_t getFileSize(const string& filename) {
    try {
        return filesystem::file_size(filename);
    }
    catch (...) {
        return 0;
    }
}

// Report image sizes
void reportImageSizes(const cv::Mat& original, const cv::Mat& decompressed, 
                     const std::string& compressedBinPath, const std::string& jpegPath) {
    size_t origSize = original.total() * original.elemSize();
    size_t compressedSize = getFileSize(compressedBinPath);
    size_t jpegSize = getFileSize(jpegPath);
    
    cout << "\n============= Memory Size Report =========================\n";
    cout << "[INFO] Original Image (RAM):       " << origSize << " bytes (" << std::fixed << std::setprecision(2) << origSize / 1024.0 << " KB)\n";
    cout << "[INFO] Decompressed Image (RAM):   " << origSize << " bytes (" << std::fixed << std::setprecision(2) << origSize / 1024.0 << " KB)\n";
    cout << "[INFO] Compressed File (BIN):      " << compressedSize << " bytes (" << std::fixed << std::setprecision(2) << compressedSize / 1024.0 << " KB)\n";
    cout << "[INFO] Compressed JPEG (imwrite):  " << jpegSize << " bytes (" << std::fixed << std::setprecision(2) << jpegSize / 1024.0 << " KB)\n";
    double ratio = static_cast<double>(origSize) / compressedSize;
    cout << "[INFO] Compression Rate (RAM : BIN) = " << std::fixed << std::setprecision(2) << ratio << " : 1\n";
    double spaceSaved = (1.0 - static_cast<double>(compressedSize) / origSize) * 100.0;
    cout << "[INFO] Space Saved (vs RAM) = " << std::fixed << std::setprecision(2) << spaceSaved << " %\n";
    double jpegSpaceSaved = (1.0 - static_cast<double>(jpegSize) / origSize) * 100.0;
    cout << "[INFO] JPEG Space Saved (vs RAM) = " << std::fixed << std::setprecision(2) << jpegSpaceSaved << " %\n";
}

// Calculate PSNR for each channel
void calculateChannelPSNR(const Mat& PreImg, const Mat& PostImg) {
    Mat channels_pre[3];
    split(PreImg, channels_pre);
    Mat B_pre = channels_pre[0]; // BGR order
    Mat G_pre = channels_pre[1];
    Mat R_pre = channels_pre[2];

    Mat channels_post[3];
    split(PostImg, channels_post);
    Mat B_post = channels_post[0];
    Mat G_post = channels_post[1];
    Mat R_post = channels_post[2];

    double PSNR_R = PSNR(R_pre, R_post);
    double PSNR_G = PSNR(G_pre, G_post);
    double PSNR_B = PSNR(B_pre, B_post);
    
    // 计算平均PSNR
    double avgPSNR = (PSNR_R + PSNR_G + PSNR_B) / 3.0;
    
    cout << "\n============= Quality of Compression ====================\n";
    cout << "[INFO] PSNR_R: " << std::fixed << std::setprecision(4) << PSNR_R << " dB\n";
    cout << "[INFO] PSNR_G: " << std::fixed << std::setprecision(4) << PSNR_G << " dB\n";
    cout << "[INFO] PSNR_B: " << std::fixed << std::setprecision(4) << PSNR_B << " dB\n";
    cout << "[INFO] Average PSNR: " << std::fixed << std::setprecision(4) << avgPSNR << " dB\n";
} 