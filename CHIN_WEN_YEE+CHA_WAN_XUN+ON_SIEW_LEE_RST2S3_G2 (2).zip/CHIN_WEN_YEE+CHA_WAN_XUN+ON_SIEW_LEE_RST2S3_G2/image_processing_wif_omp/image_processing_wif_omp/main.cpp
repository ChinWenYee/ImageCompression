﻿#include "FFT.hpp"
#include "ImageProcessing.hpp"
#include "Huffman.hpp"
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

#include <iomanip> 
#include <stdint.h>
#include <string> 
#include <chrono>
#include <omp.h>
#include <fstream>
#include<iostream>

using namespace std;
using namespace cv;

void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void getblockarray(Mat mat, xformBlock* blockarr);
void getmat(Mat mat, xformBlock* blockarr);

void block2bitstream(xformBlock* block, uint8* arr);
void bitstream2block(xformBlock* block, uint8* arr);

void block2bitstream16(xformBlock* block, int16_t* arr);
void bitstream2block16(xformBlock* block, int16_t* arr);

double PSNR(Mat PreImg, Mat PostImg);
void applyThreshold(xformBlock* block, double thresholdPercent);
size_t getFileSize(const string& filename);
void reportImageSizes(const cv::Mat& original, const cv::Mat& decompressed, const std::string& compressedBinPath, const std::string& jpegPath);
size_t getImageMemorySize(const string& filename);

int main(int argc, const char** argv) {
    int num_threads = omp_get_max_threads();
    omp_set_num_threads(num_threads);

    cout << "[OMP] Threads in use: " << omp_get_max_threads() << endl;

    if (argc < 4) {
        cerr << "Usage: " << argv[0] << "<image_path> <threshold> <Quantize>\n";
        return 1;
    }

    //validation
    string inputPath = argv[1];
    double THRESHOLD_PERCENT;
    double THRESHOLD_Quantize;
    try {
        THRESHOLD_PERCENT = stod(argv[2]);
        THRESHOLD_Quantize = stod(argv[3]);
        if (THRESHOLD_PERCENT <= 0 || THRESHOLD_PERCENT > 1) {
            throw invalid_argument("Threshold must be between 0 and 100");
        }
        if (THRESHOLD_Quantize <= 0 || THRESHOLD_Quantize > 1) {
            throw invalid_argument("THRESHOLD_Quantize must be between 0 and 100");
        }
    }
    catch (const exception& e) {
        cerr << "[ERROR] Invalid threshold: " << argv[2] << ". Use a number between 0 and 100.\n";
        return 1;
    }

    // Get input file size
    size_t input_file_size = getFileSize(inputPath);
    if (input_file_size == 0) {
        cerr << "[ERROR] Could not determine input file size: " << inputPath << endl;
        return 1;
    }
    cout << "\n==================== Info of Image =======================\n";

    cout << "[INFO] Image to compress: " << inputPath << endl;
    cout << "[INFO] Input File Size: " << input_file_size << " bytes\n";
    cout << "[INFO] Threshold: Keeping top " << THRESHOLD_PERCENT * 100 << "% of coefficients\n";
    cout << "[INFO] Level of Quantization: " << THRESHOLD_Quantize * 100 << "%\n";

    // (1) Read image incolor
    Mat img = imread(inputPath, IMREAD_COLOR);
    if (img.empty()) {
        cerr << "[ERROR] Could not open image file: " << inputPath << endl;
        return 1;
    }

    // Store original image dimensions
    int orig_rows = img.rows;
    int orig_cols = img.cols;

    // (2) Convert to YCrCb
    Mat ycrcbImg;
    cvtColor(img, ycrcbImg, COLOR_BGR2YCrCb);

    // Split channels
    Mat channels[3];
    split(ycrcbImg, channels);
    Mat Y = channels[0], Cr = channels[1], Cb = channels[2];

    // (3) Unified Padding (Y, Cr, Cb)
    int Y_numRows = ycrcbImg.rows;
    int Y_numCols = ycrcbImg.cols;
    int pad_rows = (8 - (Y_numRows % 8)) % 8;
    int pad_cols = (16 - (Y_numCols % 16)) % 16;

    int paddedRows = Y_numRows + pad_rows;
    int paddedCols = Y_numCols + pad_cols;
#pragma omp parallel sections
    {
#pragma omp section
        {
            Mat Y_padded(paddedRows, paddedCols, CV_8UC1, Scalar(128));
            Y.copyTo(Y_padded(Rect(0, 0, Y_numCols, Y_numRows)));
            Y = Y_padded;
        }
#pragma omp section
        {
            Mat Cr_padded(paddedRows, paddedCols, CV_8UC1, Scalar(128));
            Cr.copyTo(Cr_padded(Rect(0, 0, Cr.cols, Cr.rows)));
            Cr = Cr_padded;
        }
#pragma omp section
        {
            Mat Cb_padded(paddedRows, paddedCols, CV_8UC1, Scalar(128));
            Cb.copyTo(Cb_padded(Rect(0, 0, Cb.cols, Cb.rows)));
            Cb = Cb_padded;
        }
    }

    Y_numRows = paddedRows;
    Y_numCols = paddedCols;

    int Y_numBlocks = (Y_numRows / 8) * (Y_numCols / 8);
    // (4) Subsampling
    Mat Cr_422(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
    Mat Cb_422(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
#pragma omp parallel sections
    {
#pragma omp section
        {
            SubSample422(Cr, Cr_422);
        }
#pragma omp section
        {
            SubSample422(Cb, Cb_422);
        }
    }

    int C_numRows = Cr_422.rows;
    int C_numCols = Cr_422.cols;
    int C_numBlocks = (C_numRows / 8) * (C_numCols / 8);

    cout << "[INFO] Y size: " << Y_numCols << "x" << Y_numRows << ", Processing " << Y_numBlocks << " blocks.\n";
    cout << "[INFO] C size: " << C_numCols << "x" << C_numRows << ", Processing " << C_numBlocks << " blocks.\n";

    //(5) block preparation
    // Allocate block arrays
    xformBlock* Y_blockArr = new xformBlock[Y_numBlocks];
    xformBlock* Cr_blockArr = new xformBlock[C_numBlocks];
    xformBlock* Cb_blockArr = new xformBlock[C_numBlocks];
    // Allocate temporary block arrays for thresholding
    xformBlock* Y_blockArr_temp = new xformBlock[Y_numBlocks];
    xformBlock* Cr_blockArr_temp = new xformBlock[C_numBlocks];
    xformBlock* Cb_blockArr_temp = new xformBlock[C_numBlocks];
    // Populate block arrays
    getblockarray(Y, Y_blockArr);
    getblockarray(Cr_422, Cr_blockArr);
    getblockarray(Cb_422, Cb_blockArr);
    // Copy to temp arrays
    memcpy(Y_blockArr_temp, Y_blockArr, Y_numBlocks * sizeof(xformBlock));
    memcpy(Cr_blockArr_temp, Cr_blockArr, C_numBlocks * sizeof(xformBlock));
    memcpy(Cb_blockArr_temp, Cb_blockArr, C_numBlocks * sizeof(xformBlock));

    // (6) Compression
    cout << "\n============= Start Compression ====================\n";
    auto start = chrono::high_resolution_clock::now();

    //(6.1) compression preparation
    vector<int16_t> Y_bitstream(Y_numBlocks * 272);
    vector<int16_t> Cr_bitstream(C_numBlocks * 272);
    vector<int16_t> Cb_bitstream(C_numBlocks * 272);

#pragma omp parallel
    {
#pragma omp for
        for (int i = 0; i < Y_numBlocks; i++) {
            FFT_8x8(&Y_blockArr[i]);
            applyThreshold(&Y_blockArr[i], THRESHOLD_PERCENT);
            QuantizeLuminance(&Y_blockArr[i], THRESHOLD_Quantize);
            block2bitstream16(&Y_blockArr[i], &Y_bitstream[i * 136]);
        }
#pragma omp for
        for (int i = 0; i < C_numBlocks; i++) {
            FFT_8x8(&Cr_blockArr[i]);
            applyThreshold(&Cr_blockArr[i], THRESHOLD_PERCENT);
            QuantizeChrominance(&Cr_blockArr[i], THRESHOLD_Quantize);
            block2bitstream16(&Cr_blockArr[i], &Cr_bitstream[i * 136]);
        }

#pragma omp for
        for (int i = 0; i < C_numBlocks; i++) {
            FFT_8x8(&Cb_blockArr[i]);
            applyThreshold(&Cb_blockArr[i], THRESHOLD_PERCENT);
            QuantizeChrominance(&Cb_blockArr[i], THRESHOLD_Quantize);
            block2bitstream16(&Cb_blockArr[i], &Cb_bitstream[i * 136]);
        }
    }

    // (6.2) Huffman encoding
    Huffman huffman_Y, huffman_Cr, huffman_Cb;
    int Y_stream_len = Y_numBlocks * 272;
    int Cr_stream_len = C_numBlocks * 272;
    int Cb_stream_len = C_numBlocks * 272;
    std::vector<bool> encoded_Y, encoded_Cr, encoded_Cb;
    std::vector<uint8_t> packed_Y, packed_Cr, packed_Cb;
    size_t bitSize_Y = 0, bitSize_Cr = 0, bitSize_Cb = 0;
    int16_t* Y_bitstream_ptr = Y_bitstream.data();
    int16_t* Cr_bitstream_ptr = Cr_bitstream.data();
    int16_t* Cb_bitstream_ptr = Cb_bitstream.data();
    
    auto clampBitstream = [](std::vector<int16_t>& stream) {
        for (auto& val : stream) {
            if (val < -512) val = -512;
            else if (val > 511) val = 511;
        }
        };
    clampBitstream(Y_bitstream);
    clampBitstream(Cr_bitstream);
    clampBitstream(Cb_bitstream);

    for (int i = 0; i < Y_bitstream.size(); ++i) {
        if (Y_bitstream[i] < -512 || Y_bitstream[i] > 511) {
            std::cout << "[Y] out of range at " << i << ": " << Y_bitstream[i] << "\n";
        }
    }

#pragma omp parallel
    {
#pragma omp single nowait
        {
#pragma omp section
            {
                huffman_Y.buildTree(Y_bitstream_ptr, Y_stream_len);
                huffman_Y.encode(Y_bitstream_ptr, Y_stream_len, encoded_Y);

            }
#pragma omp section
            {
                huffman_Cr.buildTree(Cr_bitstream_ptr, Cr_stream_len);
                huffman_Cr.encode(Cr_bitstream_ptr, Cr_stream_len, encoded_Cr);
            }
#pragma omp section
            {
                huffman_Cb.buildTree(Cb_bitstream_ptr, Cb_stream_len);
                huffman_Cb.encode(Cb_bitstream_ptr, Cb_stream_len, encoded_Cb);

            }
        }
    }

    //(6.4) merge encoded data
    std::vector<bool> encoded;
    encoded.reserve(encoded_Y.size() + encoded_Cr.size() + encoded_Cb.size());
    encoded.insert(encoded.end(), encoded_Y.begin(), encoded_Y.end());
    encoded.insert(encoded.end(), encoded_Cr.begin(), encoded_Cr.end());
    encoded.insert(encoded.end(), encoded_Cb.begin(), encoded_Cb.end());
    auto end = chrono::high_resolution_clock::now();

    //(6.5) save to file
    Huffman huffman;
    huffman.saveToFile(encoded, Y_numBlocks, C_numBlocks, THRESHOLD_PERCENT * 100,
        "compress.bin", encoded_Y.size(), encoded_Cr.size(), encoded_Cb.size());
    chrono::duration<double> compress_time = end - start;

    //(6.6) Get actual compressed size
    size_t compressed_size = getFileSize("compress.bin");
    if (compressed_size == 0) {
        cerr << "[WARNING] Could not determine compress.bin size\n";
        compressed_size = (encoded.size() + 7) / 8 + sizeof(Y_numBlocks) + sizeof(C_numBlocks) + sizeof(THRESHOLD_PERCENT * 100);
    }
    cout << "[INFO] Compression Time: " << compress_time.count() << " seconds\n";
    cout << "[INFO] Compressed data saved to: compress.bin\n";

/////////////////////////////////////////
    // (7)Saving thresholded image";
    for (int i = 0; i < Y_numBlocks; i++) {
        FFT_8x8(&Y_blockArr_temp[i]);
        applyThreshold(&Y_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Y_blockArr_temp[i]);
    }
#pragma omp parallel for
    for (int i = 0; i < C_numBlocks; i++) {
        FFT_8x8(&Cr_blockArr_temp[i]);
        applyThreshold(&Cr_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Cr_blockArr_temp[i]);

        FFT_8x8(&Cb_blockArr_temp[i]);
        applyThreshold(&Cb_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Cb_blockArr_temp[i]);
    }

    Mat Y_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cr_422_thresholded = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    Mat Cb_422_thresholded = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));

    //(7.1) convert block data to mat type
    getmat(Y_thresholded, Y_blockArr_temp);
    getmat(Cr_422_thresholded, Cr_blockArr_temp);
    getmat(Cb_422_thresholded, Cb_blockArr_temp);

    // (7.2）upsamling,back to 4:4:4
    Mat Cr_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cb_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    UpSample422(Cr_422_thresholded, Cr_thresholded);
    UpSample422(Cb_422_thresholded, Cb_thresholded);

    // (7.3)merge to ycbcr image
    Mat threshChannels[3] = { Y_thresholded, Cr_thresholded, Cb_thresholded };
    Mat img_thresholded;
    merge(threshChannels, 3, img_thresholded);

    //(7.4) convert change to color image
    Mat img_thresholded_rgb;
    cvtColor(img_thresholded, img_thresholded_rgb, COLOR_YCrCb2BGR);
    Mat resized_image = img_thresholded_rgb(Rect(0, 0, orig_cols, orig_rows));

    string threshPath = "Compressed_Image.jpeg";
    //{ cv::IMWRITE_JPEG_QUALITY, 30 }
    if (!imwrite(threshPath, resized_image)) {
        cerr << "[ERROR] Failed to save thresholded image at " << threshPath << endl;
    }
    else {
        //cout << "[INFO] Compressed image saved to: " << threshPath << endl;
    }

    // (8) Decompression
    cout << "\n============= Start Decompression ====================\n";
    //auto start4 = chrono::high_resolution_clock::now();

    // (8.1) Load and decode compressed data
    vector<bool> encodedY_loaded,encodedCr_loaded,encodedCb_loaded;
    vector<bool> encoded_loaded;
    int Y_blocks_loaded, C_blocks_loaded;
    double threshold_loaded;

    if (!huffman.loadCompressedData("compress.bin", encodedY_loaded, encodedCr_loaded, encodedCb_loaded, Y_blocks_loaded, C_blocks_loaded, threshold_loaded)) {
        cerr << "[ERROR] Failed to load compress.bin\n";
        delete[] Y_blockArr;
        delete[] Cr_blockArr;
        delete[] Cb_blockArr;
        delete[] Y_blockArr_temp;
        delete[] Cr_blockArr_temp;
        delete[] Cb_blockArr_temp;
        return 1;
    }
    start = chrono::high_resolution_clock::now();
    Y_blockArr = new xformBlock[Y_numBlocks];
    Cr_blockArr = new xformBlock[C_numBlocks];
    Cb_blockArr = new xformBlock[C_numBlocks];

    //(8.2) huffman decode
    vector<int16_t> decodedY,decodedCr,decodedCb;
#pragma omp parallel sections
    {
#pragma omp section
        {
            huffman_Y.decode(encodedY_loaded, Y_numBlocks * 272, decodedY);
        }
#pragma omp section
        {
            huffman_Cr.decode(encodedCr_loaded, C_numBlocks * 272, decodedCr);
        }
#pragma omp section
        {
            huffman_Cb.decode(encodedCb_loaded, C_numBlocks * 272, decodedCb);
        }
    }

    // (8.3) Split bitstream
    vector<int16_t> decodedY_bitstream(Y_numBlocks * 272),decodedCr_bitstream(C_numBlocks * 272),decodedCb_bitstream(C_numBlocks * 272);
    decodedY_bitstream = std::move(decodedY);
    decodedCr_bitstream = std::move(decodedCr);
    decodedCb_bitstream = std::move(decodedCb);

    // (8.4) Decompress channel
#pragma omp parallel for
    for (int i = 0; i < Y_numBlocks; i++) {
        bitstream2block16(&Y_blockArr[i], &decodedY_bitstream[i * 136]);
        InvQuantizeLuminance(&Y_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&Y_blockArr[i]);
    }
#pragma omp parallel for
    for (int i = 0; i < C_numBlocks; i++) {
        bitstream2block16(&Cr_blockArr[i], &decodedCr_bitstream[i * 136]);
        InvQuantizeChrominance(&Cr_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&Cr_blockArr[i]);

        bitstream2block16(&Cb_blockArr[i], &decodedCb_bitstream[i * 136]);
        InvQuantizeChrominance(&Cb_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&Cb_blockArr[i]);
    }
    end = chrono::high_resolution_clock::now();
    chrono::duration<double> decompress_time = end - start;
    cout << "[INFO] Decompression Time: " << decompress_time.count() << " seconds\n";

    // (9) Reconstruct image
    Mat Y_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cr_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    Mat Cb_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    getmat(Y_compressed, Y_blockArr);
    getmat(Cr_422_compressed, Cr_blockArr);
    getmat(Cb_422_compressed, Cb_blockArr);

    // (10) Upsample Cr and Cb
    Mat Cr_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cb_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    UpSample422(Cr_422_compressed, Cr_compressed);
    UpSample422(Cb_422_compressed, Cb_compressed);

    // (11) Crop to original dimensions
    Mat Y_compressed_cropped = Y_compressed(Rect(0, 0, orig_cols, orig_rows));
    Mat Cr_compressed_cropped = Cr_compressed(Rect(0, 0, orig_cols, orig_rows));
    Mat Cb_compressed_cropped = Cb_compressed(Rect(0, 0, orig_cols, orig_rows));

    // (12) Merge channels
    Mat decompChannels[3] = { Y_compressed_cropped, Cr_compressed_cropped, Cb_compressed_cropped };
    Mat img_compressed;
    merge(decompChannels, 3, img_compressed);

    // (13) Convert to BGR
    Mat final_image = img_compressed(Rect(0, 0, orig_cols, orig_rows));
    Mat img_compressed_rgb;
    cvtColor(final_image, img_compressed_rgb, COLOR_YCrCb2BGR);

    // Compute difference image
    //Mat differenceImage;
    //absdiff(ycrcbImg, img_compressed, differenceImage);

    // (14) Save images
    string compPath = "Image_Decompressed.bmp";
    string compOriPath = "Image_Decompressed.jpg";
    //string diffPath = "Difference_Image_Serial.png";
    if (!imwrite(compPath, img_compressed_rgb)) {
        cerr << "[ERROR] Failed to save decompressed image at " << compPath << endl;
    }
    else {
        //int out = rename(compPath.c_str(), compOriPath.c_str());
        // cout << "[INFO] Decompressed image from bin saved to: " << compPath << endl;
    }
    //resize(img_compressed_rgb, img_compressed_rgb, img.size());

    if (!imwrite(compOriPath, img_compressed_rgb)) {
        cerr << "[ERROR] Failed to save image at " << compOriPath << endl;
    }
    else {
        cout << "[INFO] Decompressed image saved to: " << compOriPath << endl;
    }

    // (15) Compute PSNR
    Mat img_channels[3];
    split(img, img_channels);
    Mat B = img_channels[0];
    Mat G = img_channels[1];
    Mat R = img_channels[2];

    Mat img_channels_compress[3];
    split(img_compressed_rgb, img_channels_compress);
    Mat B_compress = img_channels_compress[0];
    Mat G_compress = img_channels_compress[1];
    Mat R_compress = img_channels_compress[2];

    double PSNR_R = PSNR(R, R_compress);
    double PSNR_G = PSNR(G, G_compress);
    double PSNR_B = PSNR(B, B_compress);
    cout << "\n============= Quality of Compression ====================\n";
    cout << "[INFO] PSNR_R: " << PSNR_R << " dB\n";
    cout << "[INFO] PSNR_G: " << PSNR_G << " dB\n";
    cout << "[INFO] PSNR_B: " << PSNR_B << " dB\n";

    // Calculate compression rates
    //size_t original_size = orig_rows * orig_cols * 3; // Original RGB
    size_t original_size = getFileSize(inputPath);
    size_t de_size = getFileSize(compPath);
    size_t memory_size = getImageMemorySize(inputPath);
    size_t dememory_size = getImageMemorySize(compPath);
    double compression_rate = static_cast<double>(original_size) / compressed_size;
    cout << "\n==================== Summary of Comparison ====================\n";
    cout << "[INFO] Original Size: " << original_size << " bytes\n";
    cout << "[INFO] Used memory to display: " << memory_size << " bytes\n";
    cout << "[INFO] Decompressed Size: " << de_size << " bytes\n";
    cout << "[INFO] Used memory to display: " << dememory_size << " bytes\n";
    cout << "[INFO] Compressed Size: " << compressed_size << " bytes\n";
    cout << "[INFO] Compression Rate: " << compression_rate << ":1\n";
   
    //(16) image processing report
    reportImageSizes(img, img_compressed_rgb, "compress.bin", "Compressed_Image.jpeg");

    // Clean up
    delete[] Y_blockArr;
    delete[] Cr_blockArr;
    delete[] Cb_blockArr;
    delete[] Y_blockArr_temp;
    delete[] Cr_blockArr_temp;
    delete[] Cb_blockArr_temp;

    return 0;
}

void getmat(Mat mat, xformBlock* blockarr)
{
    int numBlocksRow = mat.rows / 8;
    int numBlocksCol = mat.cols / 8;

#pragma omp parallel for collapse(2)
    for (int i = 0; i < numBlocksRow; i++)
    {
        for (int j = 0; j < numBlocksCol; j++)
        {
            int blockidx = i * numBlocksCol + j;
            Rect roi(j * 8, i * 8, 8, 8);

            Mat im_roi(8, 8, CV_8UC1);
            block2mat(&im_roi, &blockarr[blockidx]);


            im_roi.copyTo(mat(roi));
        }
    }
}

void getblockarray(Mat mat, xformBlock* blockarr)
{
    int numBlocksRow = mat.rows / 8;
    int numBlocksCol = mat.cols / 8;

#pragma omp parallel for collapse(2)
    for (int i = 0; i < numBlocksRow; i++)
    {
        for (int j = 0; j < numBlocksCol; j++)
        {
            int blockidx = i * numBlocksCol + j;
            Rect roi(j * 8, i * 8, 8, 8);

            Mat im_roi = mat(roi).clone();

            mat2block(&im_roi, &blockarr[blockidx]);
        }
    }
}

void mat2block(Mat* mat, xformBlock* block)
{
    for (int currRow = 0; currRow < 8; currRow++)
    {
        for (int currCol = 0; currCol < 8; currCol++)
        {
            block->data[currRow][currCol] = mat->at<uchar>(currRow, currCol);
        }
    }
}

void block2mat(Mat* mat, xformBlock* block)
{
#pragma omp simd collapse(2)
    for (int row = 0; row < 8; row++)
    {
        for (int col = 0; col < 8; col++)
        {
            double real = block->data[row][col].real();
            real = std::clamp(real, 0.0, 255.0);
            mat->at<uchar>(row, col) = static_cast<uchar>(std::round(real));
        }
    }
}

void block2bitstream(xformBlock* block, uint8* arr)
{
    memcpy(arr, &block->row_index, sizeof(int));
    memcpy(&arr[5], &block->col_index, sizeof(int));

    int arridx = 9;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            uint8 temp_real;
            uint8 temp_imag = (uint8_t)block->data[i][j].imag();
            if (block->data[i][j].real() > 255.0)
            {
                temp_real = 255;
            }
            else if (block->data[i][j].real() < 0.0)
            {
                temp_real = 0;
            }
            else
            {
                temp_real = (uint8_t)block->data[i][j].real();
            }

            memcpy(&arr[arridx], &temp_real, sizeof(uint8_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(uint8_t));
            arridx += 2;
        }
    }
}

void bitstream2block(xformBlock* block, uint8* arr)
{
    block->row_index = arr[0] | (arr[1] << 8) | (arr[2] << 16) | (arr[3] << 24);
    block->col_index = arr[5] | (arr[6] << 8) | (arr[7] << 16) | (arr[8] << 24);
    //cout<<block->row_index << " "<< block->col_index<<endl;

    int arridx = 9;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }

}

//
void block2bitstream16(xformBlock* block, int16_t* arr)
{

    int arridx = 5;

    //copy data plus convert to uchar
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            int16_t temp_real = (int16_t)block->data[i][j].real();
            int16_t temp_imag = (int16_t)block->data[i][j].imag();
            memcpy(&arr[arridx], &temp_real, sizeof(int16_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(int16_t));
            arridx += 2;
        }
    }
}

void bitstream2block16(xformBlock* block, int16_t* arr)
{
    int arridx = 5;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }

}
double PSNR(Mat PreImg, Mat PostImg)
{
    double MSE = 0.0;
    double PSNR = 0.0;
    double temp = 0.0;

#pragma omp parallel for reduction(+:MSE) private(temp)
    for (int currRow = 0; currRow < PreImg.rows; currRow++)
    {
        for (int currCol = 0; currCol < PreImg.cols; currCol++)
        {
            temp = (int)PreImg.at<uchar>(currRow, currCol) - (int)PostImg.at<uchar>(currRow, currCol);
            MSE += pow(temp, 2);
        }
    }
    MSE = MSE / ((int)PreImg.rows * (int)PostImg.cols);
    PSNR = 10 * log10(pow(255, 2) / MSE);
    return PSNR;
}

void applyThreshold(xformBlock* block, double thresholdPercent) {
    // Collect magnitudes
    vector<pair<double, pair<int, int>>> magnitudes;

#pragma omp simd collapse(2)
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
#pragma omp critical
            magnitudes.push_back({ abs(block->data[i][j]), {i, j} });
        }
    }

    // Sort descending
    sort(magnitudes.rbegin(), magnitudes.rend());

    // Calculate cutoff index
    int keep_count = static_cast<int>(64 * thresholdPercent);
    if (keep_count < 1) keep_count = 1; // Keep at least one coefficient

    // Zero out coefficients below threshold
    for (int idx = keep_count; idx < 64; idx++) {
        int i = magnitudes[idx].second.first;
        int j = magnitudes[idx].second.second;
        block->data[i][j] = complex<double>(0, 0);
    }
}

size_t getFileSize(const string& filename) {
    ifstream in(filename, ios::binary | ios::ate);
    if (!in) return 0;
    size_t size = in.tellg();
    in.close();
    return size;
}

size_t getImageMemorySize(const string& filename) {
    Mat img = imread(filename, IMREAD_UNCHANGED);
    if (img.empty()) {
        cerr << "Failed to load image: " << filename << endl;
        return 0;
    }
    return img.total() * img.elemSize();
}

void reportImageSizes(
    const cv::Mat& original,
    const cv::Mat& decompressed,
    const std::string& compressedBinPath,
    const std::string& jpegPath
) {
    size_t original_memory = original.total() * original.elemSize();
    size_t decompressed_memory = decompressed.total() * decompressed.elemSize();
    size_t compressed_bin_size = getFileSize(compressedBinPath);
    size_t jpeg_file_size = getFileSize(jpegPath);

    std::cout << "\n============= Memory Size Report =========================\n";
    std::cout << std::fixed << std::setprecision(2);

    std::cout << "[INFO] Original Image (RAM):       " << original_memory << " bytes (" << original_memory / 1024.0 << " KB)\n";
    std::cout << "[INFO] Decompressed Image (RAM):   " << decompressed_memory << " bytes (" << decompressed_memory / 1024.0 << " KB)\n";
    std::cout << "[INFO] Compressed File (BIN):      " << compressed_bin_size << " bytes (" << compressed_bin_size / 1024.0 << " KB)\n";
    std::cout << "[INFO] Compressed JPEG (imwrite):  " << jpeg_file_size << " bytes (" << jpeg_file_size / 1024.0 << " KB)\n";

    double compression_rate = (double)original_memory / compressed_bin_size;
    double compression_percent = (1.0 - (double)compressed_bin_size / original_memory) * 100.0;

    std::cout << "[INFO] Compression Rate (RAM : BIN) = " << compression_rate << " : 1\n";
    std::cout << "[INFO] Space Saved (vs RAM) = " << compression_percent << " %\n";

    double jpeg_percent = (1.0 - (double)jpeg_file_size / original_memory) * 100.0;
    std::cout << "[INFO] JPEG Space Saved (vs RAM) = " << jpeg_percent << " %\n";
}



