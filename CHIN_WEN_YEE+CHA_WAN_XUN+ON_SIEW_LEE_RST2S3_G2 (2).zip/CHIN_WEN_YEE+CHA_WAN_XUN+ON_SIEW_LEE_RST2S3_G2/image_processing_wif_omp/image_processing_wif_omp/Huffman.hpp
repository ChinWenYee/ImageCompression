﻿#pragma once
#include <vector>
#include <unordered_map>
#include <memory>
#include <queue>
#include <cstdint>
#include <string>
#include <fstream>
#include <iostream>

struct HuffmanNode {
    int16_t symbol;
    int freq;
    std::shared_ptr<HuffmanNode> left;
    std::shared_ptr<HuffmanNode> right;

    HuffmanNode(int16_t sym, int f) : symbol(sym), freq(f), left(nullptr), right(nullptr) {}
    bool isLeaf() const { return !left && !right; }
};

class Huffman {
public:
    int max_bits_per_symbol = 0;

    Huffman();

    void buildTree(const int16_t* data, size_t length);
    void encode(const int16_t* data, size_t length, std::vector<bool>& encoded);
    void decode(const std::vector<bool>& encoded, size_t data_size, std::vector<int16_t>& decoded);
    void saveToFile(const std::vector<bool>& fullStream, int YBlocks, int CBlocks, double thresholdPercent, const std::string& filename, size_t ySize, size_t crSize, size_t cbSize);
    bool loadCompressedData(const std::string& filename,
        std::vector<bool>& encodedY,
        std::vector<bool>& encodedCr,
        std::vector<bool>& encodedCb,
        int& YBlocks, int& CBlocks, double& thresholdPercent);
    //void packBitsToBytes(const std::vector<bool>& bits, std::vector<uint8_t>& bytes);
    //void unpackBytesToBits(const std::vector<uint8_t>& bytes, std::vector<bool>& bits, size_t bitSize);
    ////void decode_parallel(const std::vector<bool>& encoded, int16_t* decoded, size_t total_symbols);
    //void encodeAndPack(const int16_t* data, size_t length, std::vector<uint8_t>& packedBytes);

private:
    std::shared_ptr<HuffmanNode> root;

    std::unordered_map<int16_t, std::vector<bool>> codeTable;
    std::vector<size_t> lastOffsets;
    void buildCodeTable(const std::shared_ptr<HuffmanNode>& node, std::vector<bool>& code);
    
    void writeBits(std::ofstream& out, const std::vector<bool>& bits);
    void readBits(std::ifstream& in, size_t bitCount, std::vector<bool>& bits);
};

