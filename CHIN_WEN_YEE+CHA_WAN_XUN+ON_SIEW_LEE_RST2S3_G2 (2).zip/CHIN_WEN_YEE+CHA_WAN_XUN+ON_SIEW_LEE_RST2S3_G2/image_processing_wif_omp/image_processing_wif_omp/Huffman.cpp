﻿#include "Huffman.hpp"
#include <omp.h>
#include <bitset>
#include <stdint.h>

using namespace std;

struct CompareNodes {
    bool operator()(const std::shared_ptr<HuffmanNode>& a, const std::shared_ptr<HuffmanNode>& b) {
        return a->freq > b->freq;
    }
};

Huffman::Huffman() : root(nullptr) {}

void Huffman::buildTree(const int16_t* data, size_t length) {
    constexpr int OFFSET = 512;
    constexpr int RANGE = 1024;

    // 使用原子类型统计频率
    std::vector<std::atomic<int>> freqTable(RANGE);
    for (auto& f : freqTable) f.store(0, std::memory_order_relaxed);  // 初始化原子

    // 并行统计频率
#pragma omp parallel for
    for (int i = 0; i < static_cast<int>(length); ++i) {
        int index = data[i] + OFFSET;
#pragma omp atomic
        freqTable[index]++;
    }

    // 构建小顶堆
    std::priority_queue<
        std::shared_ptr<HuffmanNode>,
        std::vector<std::shared_ptr<HuffmanNode>>,
        CompareNodes
    > pq;

    for (int i = 0; i < RANGE; ++i) {
        int freq = freqTable[i].load(std::memory_order_relaxed);
        if (freq > 0) {
            pq.push(std::make_shared<HuffmanNode>(i - OFFSET, freq));
        }
    }

    // 合并节点生成哈夫曼树
    while (pq.size() > 1) {
        auto left = pq.top(); pq.pop();
        auto right = pq.top(); pq.pop();

        auto parent = std::make_shared<HuffmanNode>(-1, left->freq + right->freq);
        parent->left = left;
        parent->right = right;

        pq.push(parent);
    }

    // 构建编码表
    root = pq.top();
    codeTable.clear();
    std::vector<bool> code;
    buildCodeTable(root, code);
}

void Huffman::encode(const int16_t* data, size_t length, std::vector<bool>& encoded) {
    encoded.clear();  // Clear the output vector

    std::vector<size_t> bit_lengths(length); // Stores bit length of each encoded symbol
    std::vector<size_t> bit_offsets(length); // Stores the bit offset of each symbol in the output stream

    // Step 1: Compute the bit length of each symbol in parallel
#pragma omp parallel for
    for (int i = 0; i < static_cast<int>(length); ++i) {
        bit_lengths[i] = codeTable[data[i]].size();
    }

    // Step 2: Build the bit offset table serially
    size_t totalBits = 0;
    for (size_t i = 0; i < length; ++i) {
        bit_offsets[i] = totalBits;
        totalBits += bit_lengths[i];
    }

    // Step 3: Resize the encoded bitstream to fit all encoded bits
    encoded.resize(totalBits);

    // Step 4: Encode each symbol's bit sequence into the output in parallel
#pragma omp parallel for
    for (int i = 0; i < static_cast<int>(length); ++i) {
        const auto& code = codeTable[data[i]];
        size_t offset = bit_offsets[i];

        // Write bits directly into the output bitstream
        for (size_t j = 0; j < code.size(); ++j) {
            encoded[offset + j] = code[j];
        }
    }

    // Save offsets for decoding use
    lastOffsets = std::move(bit_offsets);
}

void Huffman::buildCodeTable(const std::shared_ptr<HuffmanNode>& node, std::vector<bool>& code) {
    if (node->isLeaf()) {
        codeTable[node->symbol] = code;
        // Update max_bits_per_symbol with the longest code length
        if (code.size() > max_bits_per_symbol) {
            max_bits_per_symbol = code.size();
        }
        return;
    }
    if (node->left) {
        code.push_back(false);
        buildCodeTable(node->left, code);
        code.pop_back();
    }
    if (node->right) {
        code.push_back(true);
        buildCodeTable(node->right, code);
        code.pop_back();
    }
}

void Huffman::decode(const std::vector<bool>& encoded, size_t data_size, std::vector<int16_t>& decoded) {
    decoded.resize(data_size);  
#pragma omp parallel for
    for (int i = 0; i < static_cast<int>(data_size); ++i) {
        size_t offset = lastOffsets[i];
        std::shared_ptr<HuffmanNode> current = root;

        while (current->left || current->right) {
            if (offset >= encoded.size())
                throw std::runtime_error("Offset out of bounds during decode");

            current = encoded[offset++] ? current->right : current->left;
            if (!current)
                throw std::runtime_error("Invalid bitstream during decode");
        }

        decoded[i] = current->symbol;
    }
}

void Huffman::writeBits(std::ofstream& out, const std::vector<bool>& bits) {
    uint8_t byte = 0;
    int bitCount = 0;
    for (bool bit : bits) {
        byte = (byte << 1) | bit;
        bitCount++;
        if (bitCount == 8) {
            out.put(byte);
            bitCount = 0;
            byte = 0;
        }
    }
    if (bitCount > 0) {
        byte <<= (8 - bitCount);
        out.put(byte);
    }
}

void Huffman::readBits(std::ifstream& in, size_t bitCount, std::vector<bool>& bits) {
    size_t byteCount = (bitCount + 7) / 8;
    std::vector<uint8_t> rawData(byteCount);
    in.read(reinterpret_cast<char*>(rawData.data()), byteCount);

    bits.resize(bitCount);

#pragma omp parallel for
    for (int i = 0; i < bitCount; ++i) {
        int byteIndex = i / 8;
        int bitIndex = 7 - (i % 8);
        bits[i] = (rawData[byteIndex] >> bitIndex) & 1;
    }
}

void Huffman::saveToFile(const std::vector<bool>& fullStream, int YBlocks, int CBlocks, double thresholdPercent,const std::string& filename, size_t ySize, size_t crSize, size_t cbSize) {
    std::ofstream out(filename, std::ios::binary);
    if (!out) {
        std::cerr << "Failed to open file for writing.\n";
        return;
    }

    // Write metadata
    out.write(reinterpret_cast<char*>(&YBlocks), sizeof(YBlocks));
    out.write(reinterpret_cast<char*>(&CBlocks), sizeof(CBlocks));
    out.write(reinterpret_cast<char*>(&thresholdPercent), sizeof(thresholdPercent));

    out.write(reinterpret_cast<char*>(&ySize), sizeof(size_t));
    out.write(reinterpret_cast<char*>(&crSize), sizeof(size_t));
    out.write(reinterpret_cast<char*>(&cbSize), sizeof(size_t));

    size_t totalBits = fullStream.size();
    out.write(reinterpret_cast<char*>(&totalBits), sizeof(size_t));

    writeBits(out, fullStream);
    out.close();
}

bool Huffman::loadCompressedData(const std::string& filename,
    std::vector<bool>& encodedY,
    std::vector<bool>& encodedCr,
    std::vector<bool>& encodedCb,
    int& YBlocks, int& CBlocks, double& thresholdPercent)
{
    std::ifstream in(filename, std::ios::binary);
    if (!in) {
        std::cerr << "Failed to open file for reading.\n";
        return false;
    }

    size_t ySize, crSize, cbSize, totalBits;

    in.read(reinterpret_cast<char*>(&YBlocks), sizeof(YBlocks));
    in.read(reinterpret_cast<char*>(&CBlocks), sizeof(CBlocks));
    in.read(reinterpret_cast<char*>(&thresholdPercent), sizeof(thresholdPercent));
    in.read(reinterpret_cast<char*>(&ySize), sizeof(size_t));
    in.read(reinterpret_cast<char*>(&crSize), sizeof(size_t));
    in.read(reinterpret_cast<char*>(&cbSize), sizeof(size_t));
    in.read(reinterpret_cast<char*>(&totalBits), sizeof(size_t));

    std::vector<bool> fullBits;
    readBits(in, totalBits, fullBits);  
    in.close();

    // 并行切割
#pragma omp parallel sections
    {
#pragma omp section
        {
            encodedY.assign(fullBits.begin(), fullBits.begin() + ySize);
        }
#pragma omp section
        {
            encodedCr.assign(fullBits.begin() + ySize, fullBits.begin() + ySize + crSize);
        }
#pragma omp section
        {
            encodedCb.assign(fullBits.begin() + ySize + crSize, fullBits.end());
        }
    }

    return true;
}

//void Huffman::decode_parallel(const std::vector<bool>& encoded, int16_t* decoded, size_t total_symbols) {
//    size_t threads = omp_get_max_threads();
//    std::vector<size_t> offsets(threads + 1, 0);  // 每段起点
//
//    // 分段目标数量（每段解码 count 个符号）
//    size_t count_per_thread = total_symbols / threads;
//
//#pragma omp parallel
//    {
//        int tid = omp_get_thread_num();
//        size_t decoded_count = 0;
//        size_t i = 0;
//        auto current = root;
//
//        // 寻找每段的 bit 起点（基于“前面共解了 count_per_thread * tid 个符号”）
//#pragma omp critical
//        {
//            if (tid == 0) offsets[0] = 0;
//            else {
//                // 用上一个线程的结束位置
//                size_t start_bit = offsets[tid];
//                current = root;
//                while (decoded_count < count_per_thread && start_bit < encoded.size()) {
//                    if (encoded[start_bit]) current = current->right;
//                    else current = current->left;
//                    start_bit++;
//                    if (current->isLeaf()) {
//                        decoded_count++;
//                        current = root;
//                    }
//                }
//                offsets[tid + 1] = start_bit;
//            }
//        }
//    }
//
//    // 真正并行解码
//#pragma omp parallel
//    {
//        int tid = omp_get_thread_num();
//        size_t bit_start = offsets[tid];
//        size_t bit_end = (tid == threads - 1) ? encoded.size() : offsets[tid + 1];
//        size_t symbol_index = tid * count_per_thread;
//        auto current = root;
//
//        for (size_t i = bit_start; i < bit_end && symbol_index < total_symbols; ++i) {
//            current = encoded[i] ? current->right : current->left;
//            if (current->isLeaf()) {
//                decoded[symbol_index++] = current->symbol;
//                current = root;
//            }
//        }
//    }
//}

//void Huffman::packBitsToBytes(const std::vector<bool>& bits, std::vector<uint8_t>& bytes) {
//    size_t byteCount = (bits.size() + 7) / 8;
//    bytes.resize(byteCount, 0);
//
//#pragma omp parallel for
//    for (int i = 0; i < static_cast<int>(bits.size()); ++i) {
//        if (bits[i]) {
//#pragma omp atomic
//            bytes[i / 8] |= (1 << (7 - (i % 8)));
//        }
//    }
//}
//
//void Huffman::unpackBytesToBits(const std::vector<uint8_t>& bytes, std::vector<bool>& bits, size_t bitSize) {
//    bits.resize(bitSize);
//#pragma omp parallel for
//    for (int i = 0; i < static_cast<int>(bitSize); ++i) {
//        bits[i] = (bytes[i / 8] >> (7 - (i % 8))) & 1;
//    }
//}