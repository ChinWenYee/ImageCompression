﻿#include "Huffman.hpp"
#include <stdexcept>

Huffman::Huffman() : root(nullptr) {}

Huffman::~Huffman() {
    deleteTree(root);
}

void Huffman::deleteTree(HuffmanNode* node) {
    if (!node) return;
    deleteTree(node->left);
    deleteTree(node->right);
    delete node;
}

void Huffman::buildCodes(HuffmanNode* node, std::vector<bool>& code) {
    if (!node) return;
    if (!node->left && !node->right) {
        codes[node->value] = code;
        return;
    }
    code.push_back(false);
    buildCodes(node->left, code);
    code.back() = true;
    buildCodes(node->right, code);
    code.pop_back();
}

void Huffman::buildTree(const std::vector<int16_t>& data) {
    // Build frequency table
    std::map<int16_t, uint64_t> freq;
    for (int16_t val : data) {
        freq[val]++;
    }

    // Priority queue for Huffman tree
    auto cmp = [](HuffmanNode* a, HuffmanNode* b) { return a->freq > b->freq; };
    std::priority_queue<HuffmanNode*, std::vector<HuffmanNode*>, decltype(cmp)> pq(cmp);

    for (const auto& pair : freq) {
        pq.push(new HuffmanNode(pair.first, pair.second));
    }

    // Handle empty or single-value case
    if (pq.empty()) {
        return;
    }
    if (pq.size() == 1) {
        auto node = pq.top();
        pq.pop();
        root = new HuffmanNode(0, 0);
        root->left = node;
        codes[node->value] = { false };
        return;
    }

    // Build tree
    while (pq.size() > 1) {
        HuffmanNode* left = pq.top();
        pq.pop();
        HuffmanNode* right = pq.top();
        pq.pop();
        HuffmanNode* parent = new HuffmanNode(0, left->freq + right->freq);
        parent->left = left;
        parent->right = right;
        pq.push(parent);
    }
    root = pq.top();

    // Generate codes
    std::vector<bool> code;
    buildCodes(root, code);
}

void Huffman::encode(const std::vector<int16_t>& data, std::vector<bool>& encoded) {
    encoded.clear();
    for (int16_t val : data) {
        if (codes.find(val) == codes.end()) {
            throw std::runtime_error("Value not found in Huffman codes");
        }
        encoded.insert(encoded.end(), codes[val].begin(), codes[val].end());
    }
}

void Huffman::decode(const std::vector<bool>& encoded, size_t data_size, std::vector<int16_t>& decoded) {
    decoded.clear();
    HuffmanNode* current = root;
    for (bool bit : encoded) {
        if (!current) {
            throw std::runtime_error("Invalid encoded data");
        }
        current = bit ? current->right : current->left;
        if (!current->left && !current->right) {
            decoded.push_back(current->value);
            current = root;
        }
    }
    if (decoded.size() != data_size) {
        throw std::runtime_error("Decoded data size mismatch");
    }
}

void Huffman::saveToFile(const std::vector<bool>& encoded, size_t Y_blocks, size_t C_blocks, double threshold, const std::string& filename) {
    std::ofstream out(filename, std::ios::binary);
    if (!out) {
        throw std::runtime_error("Cannot open output file");
    }

    // Write header
    out.write(reinterpret_cast<const char*>(&Y_blocks), sizeof(Y_blocks));
    out.write(reinterpret_cast<const char*>(&C_blocks), sizeof(C_blocks));
    out.write(reinterpret_cast<const char*>(&threshold), sizeof(threshold));

    // Write codes
    uint32_t codes_size = codes.size();
    out.write(reinterpret_cast<const char*>(&codes_size), sizeof(codes_size));
    for (const auto& pair : codes) {
        int16_t val = pair.first;
        uint32_t code_len = pair.second.size();
        out.write(reinterpret_cast<const char*>(&val), sizeof(val));
        out.write(reinterpret_cast<const char*>(&code_len), sizeof(code_len));
        std::vector<uint8_t> code_bytes((code_len + 7) / 8, 0);
        for (size_t i = 0; i < code_len; i++) {
            if (pair.second[i]) {
                code_bytes[i / 8] |= (1 << (7 - (i % 8)));
            }
        }
        out.write(reinterpret_cast<const char*>(code_bytes.data()), code_bytes.size());
    }

    // Write encoded data
    uint64_t bit_count = encoded.size();
    out.write(reinterpret_cast<const char*>(&bit_count), sizeof(bit_count));
    std::vector<uint8_t> bytes((bit_count + 7) / 8, 0);
    for (size_t i = 0; i < bit_count; i++) {
        if (encoded[i]) {
            bytes[i / 8] |= (1 << (7 - (i % 8)));
        }
    }
    out.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
    out.close();
}

bool Huffman::loadFromFile(std::vector<bool>& encoded, size_t& Y_blocks, size_t& C_blocks, double& threshold, const std::string& filename) {
    std::ifstream in(filename, std::ios::binary);
    if (!in) {
        return false;
    }

    // Read header
    in.read(reinterpret_cast<char*>(&Y_blocks), sizeof(Y_blocks));
    in.read(reinterpret_cast<char*>(&C_blocks), sizeof(C_blocks));
    in.read(reinterpret_cast<char*>(&threshold), sizeof(threshold));

    // Read codes
    codes.clear();
    uint32_t codes_size;
    in.read(reinterpret_cast<char*>(&codes_size), sizeof(codes_size));
    for (uint32_t i = 0; i < codes_size; i++) {
        int16_t val;
        uint32_t code_len;
        in.read(reinterpret_cast<char*>(&val), sizeof(val));
        in.read(reinterpret_cast<char*>(&code_len), sizeof(code_len));
        std::vector<uint8_t> code_bytes((code_len + 7) / 8);
        in.read(reinterpret_cast<char*>(code_bytes.data()), code_bytes.size());
        std::vector<bool> code(code_len);
        for (size_t j = 0; j < code_len; j++) {
            code[j] = (code_bytes[j / 8] & (1 << (7 - (j % 8)))) != 0;
        }
        codes[val] = code;
    }

    // Rebuild tree
    deleteTree(root);
    root = nullptr;
    if (!codes.empty()) {
        root = new HuffmanNode(0, 0);
        for (const auto& pair : codes) {
            HuffmanNode* current = root;
            for (bool bit : pair.second) {
                if (bit) {
                    if (!current->right) current->right = new HuffmanNode(0, 0);
                    current = current->right;
                }
                else {
                    if (!current->left) current->left = new HuffmanNode(0, 0);
                    current = current->left;
                }
            }
            current->value = pair.first;
        }
    }

    // Read encoded data
    uint64_t bit_count;
    in.read(reinterpret_cast<char*>(&bit_count), sizeof(bit_count));
    std::vector<uint8_t> bytes((bit_count + 7) / 8);
    in.read(reinterpret_cast<char*>(bytes.data()), bytes.size());
    encoded.resize(bit_count);
    for (size_t i = 0; i < bit_count; i++) {
        encoded[i] = (bytes[i / 8] & (1 << (7 - (i % 8)))) != 0;
    }
    in.close();
    return true;
}

size_t Huffman::getCodesSize() const {
    return codes.size();
}