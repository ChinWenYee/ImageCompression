﻿#ifndef HUFFMAN_HPP
#define HUFFMAN_HPP

#include <vector>
#include <map>
#include <string>
#include <fstream>
#include <queue>

struct HuffmanNode {
    int16_t value;
    uint64_t freq;
    HuffmanNode* left, * right;
    HuffmanNode(int16_t val, uint64_t f) : value(val), freq(f), left(nullptr), right(nullptr) {}
};

class Huffman {
private:
    HuffmanNode* root;
    std::map<int16_t, std::vector<bool>> codes;
    void buildCodes(HuffmanNode* node, std::vector<bool>& code);
    void deleteTree(HuffmanNode* node);

public:
    Huffman();
    ~Huffman();
    void buildTree(const std::vector<int16_t>& data);
    void encode(const std::vector<int16_t>& data, std::vector<bool>& encoded);
    void decode(const std::vector<bool>& encoded, size_t data_size, std::vector<int16_t>& decoded);
    void saveToFile(const std::vector<bool>& encoded, size_t Y_blocks, size_t C_blocks, double threshold, const std::string& filename);
    bool loadFromFile(std::vector<bool>& encoded, size_t& Y_blocks, size_t& C_blocks, double& threshold, const std::string& filename);
    size_t getCodesSize() const; // New method to access codes.size()
};

#endif