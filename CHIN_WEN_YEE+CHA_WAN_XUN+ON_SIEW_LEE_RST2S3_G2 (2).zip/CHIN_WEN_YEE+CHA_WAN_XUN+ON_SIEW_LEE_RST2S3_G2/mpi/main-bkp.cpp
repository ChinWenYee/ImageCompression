#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <chrono>
#include <filesystem>
#include <vector>
#include <mpi.h>
#include <algorithm>

#include "FFT.hpp"

using namespace std;
using namespace cv;
namespace fs = std::filesystem;

// Constants
const double DEFAULT_THRESHOLD = 0.1;
const int BLOCK_SIZE = 8;

// Structure for performance metrics
struct PerfMetrics {
    double io_time = 0;
    double comp_time = 0;
    double comm_time = 0;
    double total_time = 0;
};

// Function declarations
void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void createDirectory(const string& path);
void applyThreshold(xformBlock* block, double threshold);
void create_xformblock_mpi_type(MPI_Datatype* mpi_xformblock_type);
void processImage(const string& inputPath, double thresholdPercentage, int rank, int size, PerfMetrics& metrics);
void printPerformanceMetrics(const PerfMetrics& metrics, int rank, int size);

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (argc < 2 && rank == 0) {
        cerr << "Usage: " << argv[0] << " <image_path> [threshold_percentage]\n";
        MPI_Finalize();
        return 1;
    }

    string inputPath = argv[1];
    double thresholdPercentage = DEFAULT_THRESHOLD;

    if (rank == 0 && argc >= 3) {
        try {
            thresholdPercentage = stod(argv[2]);
            if (thresholdPercentage <= 0 || thresholdPercentage > 1) {
                throw out_of_range("Threshold must be between 0 and 1");
            }
        }
        catch (exception& e) {
            cerr << "[ERROR] Invalid threshold percentage: " << e.what() << endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
            return 1;
        }
    }

    // Broadcast threshold to all processes
    MPI_Bcast(&thresholdPercentage, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    PerfMetrics metrics;
    double startTotal = MPI_Wtime();

    try {
        processImage(inputPath, thresholdPercentage, rank, size, metrics);
    }
    catch (const exception& e) {
        cerr << "[RANK " << rank << "] ERROR: " << e.what() << endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    metrics.total_time = MPI_Wtime() - startTotal;

    // Print performance metrics
    printPerformanceMetrics(metrics, rank, size);

    MPI_Finalize();
    return 0;
}

void processImage(const string& inputPath, double thresholdPercentage, int rank, int size, PerfMetrics& metrics) {
    // Create custom MPI datatype
    MPI_Datatype mpi_xformblock_type;
    create_xformblock_mpi_type(&mpi_xformblock_type);

    Mat img;
    int numRows = 0, numCols = 0;
    int numBlocks = 0;
    xformBlock* blockArr = nullptr;
    xformBlock* myBlocks = nullptr;

    double startIO = MPI_Wtime();

    // Only rank 0 reads the image
    if (rank == 0) {
        string outputDir = "./images/";
        createDirectory(outputDir);

        cout << "[INFO] Loading image: " << inputPath << endl;
        img = imread(inputPath, IMREAD_COLOR);
        if (img.empty()) {
            throw runtime_error("Could not open image file: " + inputPath);
        }

        // Convert to YCrCb color space
        Mat ycrcbImg;
        cvtColor(img, ycrcbImg, COLOR_BGR2YCrCb);

        // Separate channels
        vector<Mat> channels;
        split(ycrcbImg, channels);
        Mat Y = channels[0];

        numRows = Y.rows;
        numCols = Y.cols;

        // Ensure image dimensions are multiples of BLOCK_SIZE
        numRows = (numRows / BLOCK_SIZE) * BLOCK_SIZE;
        numCols = (numCols / BLOCK_SIZE) * BLOCK_SIZE;
        numBlocks = (numRows / BLOCK_SIZE) * (numCols / BLOCK_SIZE);

        // Allocate memory for all blocks
        blockArr = new xformBlock[numBlocks];

        // Preprocessing: divide image into blocks
        int blockidx = 0;
        for (int currRow = 0; currRow < numRows; currRow += BLOCK_SIZE) {
            for (int currCol = 0; currCol < numCols; currCol += BLOCK_SIZE) {
                Rect roi(currCol, currRow, BLOCK_SIZE, BLOCK_SIZE);
                Mat im_roi = Y(roi).clone();
                mat2block(&im_roi, &blockArr[blockidx]);
                blockidx++;
            }
        }
    }

    metrics.io_time = MPI_Wtime() - startIO;

    // Broadcast image dimensions
    MPI_Bcast(&numRows, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&numCols, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&numBlocks, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Calculate block distribution with better load balancing
    int baseBlocks = numBlocks / size;
    int extraBlocks = numBlocks % size;
    int myBlockCount = baseBlocks + (rank < extraBlocks ? 1 : 0);

    // Prepare counts and displacements for Scatterv/Gatherv
    vector<int> counts(size), displacements(size);
    int offset = 0;
    for (int i = 0; i < size; i++) {
        counts[i] = baseBlocks + (i < extraBlocks ? 1 : 0);
        displacements[i] = offset;
        offset += counts[i];
    }

    // Allocate memory for local blocks
    myBlocks = new xformBlock[myBlockCount];

    double startComm = MPI_Wtime();

    // Scatter blocks to all processes
    MPI_Scatterv(blockArr, counts.data(), displacements.data(), mpi_xformblock_type,
        myBlocks, myBlockCount, mpi_xformblock_type,
        0, MPI_COMM_WORLD);

    metrics.comm_time += MPI_Wtime() - startComm;

    double startComp = MPI_Wtime();

    // Process local blocks
    for (int i = 0; i < myBlockCount; i++) {
        FFT_8x8(&myBlocks[i]);
        applyThreshold(&myBlocks[i], thresholdPercentage);
        IFFT_8x8(&myBlocks[i]);
    }

    metrics.comp_time = MPI_Wtime() - startComp;

    startComm = MPI_Wtime();

    // Gather processed blocks
    MPI_Gatherv(myBlocks, myBlockCount, mpi_xformblock_type,
        blockArr, counts.data(), displacements.data(), mpi_xformblock_type,
        0, MPI_COMM_WORLD);

    metrics.comm_time += MPI_Wtime() - startComm;

    // Reconstruct image on rank 0
    if (rank == 0) {
        Mat compressedY = Mat::zeros(numRows, numCols, CV_8UC1);
        int blockidx = 0;
        for (int currRow = 0; currRow < numRows; currRow += BLOCK_SIZE) {
            for (int currCol = 0; currCol < numCols; currCol += BLOCK_SIZE) {
                Rect roi(currCol, currRow, BLOCK_SIZE, BLOCK_SIZE);
                Mat im_roi = compressedY(roi);
                block2mat(&im_roi, &blockArr[blockidx]);
                blockidx++;
            }
        }

        // Process chroma channels with downsampling
        Mat ycrcbImg;
        cvtColor(img, ycrcbImg, COLOR_BGR2YCrCb);
        vector<Mat> channels;
        split(ycrcbImg, channels);
        Mat Cr = channels[1], Cb = channels[2];

        // Downsample chroma channels (4:2:0)
        resize(Cr, Cr, Size(numCols / 2, numRows / 2), 0, 0, INTER_AREA);
        resize(Cb, Cb, Size(numCols / 2, numRows / 2), 0, 0, INTER_AREA);

        // Upsample back to original size
        resize(Cr, Cr, Size(numCols, numRows), 0, 0, INTER_LINEAR);
        resize(Cb, Cb, Size(numCols, numRows), 0, 0, INTER_LINEAR);

        // Merge channels and save
        vector<Mat> compressedChannels = { compressedY, Cr, Cb };
        Mat compressedYCbCr;
        merge(compressedChannels, compressedYCbCr);

        Mat compressedImg;
        cvtColor(compressedYCbCr, compressedImg, COLOR_YCrCb2BGR);

        vector<int> compression_params = { IMWRITE_JPEG_QUALITY, 80 };
        string outputPath = "./images/compressed_mpi.jpg";
        imwrite(outputPath, compressedImg, compression_params);

        cout << "[INFO] Compression completed successfully\n";

        // Clean up
        delete[] blockArr;
    }

    // Clean up
    delete[] myBlocks;
    MPI_Type_free(&mpi_xformblock_type);
}

void create_xformblock_mpi_type(MPI_Datatype* mpi_xformblock_type) {
    xformBlock dummy;
    int block_lengths[1] = { 64 }; // 8x8 complex numbers
    MPI_Aint displacements[1] = { 0 };
    MPI_Datatype types[1] = { MPI_C_DOUBLE_COMPLEX };

    MPI_Type_create_struct(1, block_lengths, displacements, types, mpi_xformblock_type);
    MPI_Type_commit(mpi_xformblock_type);
}

void applyThreshold(xformBlock* block, double threshold) {
    const int totalCoeffs = BLOCK_SIZE * BLOCK_SIZE;
    const int coeffsToKeep = static_cast<int>(totalCoeffs * threshold);

    // Flatten coefficients and sort by magnitude
    vector<pair<double, complex<double>*>> coeffs;
    coeffs.reserve(totalCoeffs);

    for (int i = 0; i < BLOCK_SIZE; i++) {
        for (int j = 0; j < BLOCK_SIZE; j++) {
            double magnitude = abs(block->data[i][j]);
            coeffs.emplace_back(magnitude, &block->data[i][j]);
        }
    }

    // Partial sort to find the threshold point (more efficient than full sort)
    nth_element(coeffs.begin(), coeffs.begin() + coeffsToKeep, coeffs.end(),
        [](const auto& a, const auto& b) { return a.first > b.first; });

    // Zero out small coefficients
    for (int k = coeffsToKeep; k < totalCoeffs; k++) {
        *(coeffs[k].second) = 0;
    }
}

void mat2block(Mat* mat, xformBlock* block) {
    for (int currRow = 0; currRow < BLOCK_SIZE; currRow++) {
        for (int currCol = 0; currCol < BLOCK_SIZE; currCol++) {
            block->data[currRow][currCol] = mat->at<uchar>(currRow, currCol);
        }
    }
}

void block2mat(Mat* mat, xformBlock* block) {
    for (int currRow = 0; currRow < BLOCK_SIZE; currRow++) {
        for (int currCol = 0; currCol < BLOCK_SIZE; currCol++) {
            // Clamp values to 0-255 range
            double val = block->data[currRow][currCol].real();
            val = max(0.0, min(255.0, val));
            mat->at<uchar>(currRow, currCol) = static_cast<uchar>(val);
        }
    }
}

void createDirectory(const string& path) {
    if (!fs::exists(path)) {
        if (!fs::create_directory(path)) {
            throw runtime_error("Failed to create directory: " + path);
        }
        cout << "[INFO] Created output directory: " << path << endl;
    }
}

void printPerformanceMetrics(const PerfMetrics& metrics, int rank, int size) {
    // Gather all metrics to rank 0 for reporting
    vector<PerfMetrics> allMetrics(size);
    MPI_Gather(&metrics, sizeof(PerfMetrics), MPI_BYTE,
        allMetrics.data(), sizeof(PerfMetrics), MPI_BYTE,
        0, MPI_COMM_WORLD);

    if (rank == 0) {
        cout << "\n===== Performance Metrics =====\n";
        cout << "Number of processes: " << size << "\n";

        // Calculate averages
        double avg_io = 0, avg_comp = 0, avg_comm = 0, avg_total = 0;
        for (const auto& m : allMetrics) {
            avg_io += m.io_time;
            avg_comp += m.comp_time;
            avg_comm += m.comm_time;
            avg_total += m.total_time;
        }
        avg_io /= size;
        avg_comp /= size;
        avg_comm /= size;
        avg_total /= size;

        cout << "Average I/O Time: " << avg_io << " s\n";
        cout << "Average Computation Time: " << avg_comp << " s\n";
        cout << "Average Communication Time: " << avg_comm << " s\n";
        cout << "Average Total Time: " << avg_total << " s\n";

        // Find max times
        double max_comp = 0;
        for (const auto& m : allMetrics) {
            if (m.comp_time > max_comp) max_comp = m.comp_time;
        }
        cout << "Max Computation Time (load imbalance): " << max_comp << " s\n";
        cout << "Load Imbalance Ratio: " << max_comp / avg_comp << "\n";
    }
}