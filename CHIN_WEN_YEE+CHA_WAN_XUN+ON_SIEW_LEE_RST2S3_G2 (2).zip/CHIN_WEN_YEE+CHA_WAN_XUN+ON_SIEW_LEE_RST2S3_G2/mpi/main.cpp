#include <mpi.h>
#include<iostream>
#include "FFT.hpp"
#include "Huffman.hpp"
#include "ImageProcessing.hpp"
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>
#include <filesystem>
#include <stdint.h>
#include <string> 
#include <chrono>
using namespace std;
using namespace cv;



void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void getblockarray(Mat mat, xformBlock* blockarr);
void getmat(Mat mat, xformBlock* blockarr);

void block2bitstream(xformBlock* block, uint8* arr);
void bitstream2block(xformBlock* block, uint8* arr);

void block2bitstream16(xformBlock* block, int16_t* arr);
void bitstream2block16(xformBlock* block, int16_t* arr);

double PSNR(Mat PreImg, Mat PostImg);
void applyThreshold(xformBlock* block, double thresholdPercent);
size_t getFileSize(const string& filename);
void reportImageSizes(const cv::Mat& original, const cv::Mat& decompressed, const std::string& compressedBinPath, const std::string& jpegPath);

#include <mpi.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include "FFT.hpp"
#include "ImageProcessing.hpp"
#include "Huffman.hpp"
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <stdint.h>
#include <string>

using namespace std;
using namespace cv;

typedef struct {
    int rank;
    int Y_blockstart;
    int Y_blockend;
    int C_blockstart;
    int C_blockend;
    xformBlock* Y_blockarr;
    int16_t* Y_bitstream16;
    xformBlock* Cb_blockarr;
    int16_t* Cb_bitstream16;
    xformBlock* Cr_blockarr;
    int16_t* Cr_bitstream16;
} thread_args;

void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void getblockarray(Mat mat, xformBlock* blockarr);
void getmat(Mat mat, xformBlock* blockarr);
void block2bitstream(xformBlock* block, uint8_t* arr);
void bitstream2block(xformBlock* block, uint8_t* arr);
void block2bitstream16(xformBlock* block, int16_t* arr);
void bitstream2block16(xformBlock* block, int16_t* arr);
double PSNR(Mat PreImg, Mat PostImg);
void applyThreshold(xformBlock* block, double thresholdPercent);
size_t getFileSize(const string& filename);
size_t getImageMemorySize(const string& filename);

int main(int argc, char** argv) {
    // Initialize MPI
    MPI_Init(&argc, &argv);
    int my_rank, num_process;
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &num_process);

    if (argc < 3 && my_rank == 0) {
        cerr << "Usage: " << argv[0] << " <image_path> <threshold>\n";
        MPI_Finalize();
        return 1;
    }

    string inputPath = argv[1];
    double THRESHOLD_PERCENT = 0.0;
    double THRESHOLD_Quantize = 0.5;
    size_t input_file_size = 0;
    Mat img;
    int orig_rows = 0, orig_cols = 0;
    Mat myImage_Converted;
    int Y_numBlocks = 0, Y_numRows = 0, Y_numCols = 0;
    int C_numBlocks = 0, C_numRows = 0, C_numCols = 0;
    Mat Y, Cr_422, Cb_422;
    double start, end;
    string extension;

    // Root process handles input and preprocessing
    if (my_rank == 0) {
        try {
            THRESHOLD_PERCENT = stod(argv[2]);
            THRESHOLD_Quantize = stod(argv[3]);
            if (THRESHOLD_PERCENT <= 0 || THRESHOLD_PERCENT > 1) {
                throw invalid_argument("Threshold must be between 0 and 100");
            }
            if (THRESHOLD_Quantize <= 0 || THRESHOLD_Quantize > 1) {
                throw invalid_argument("THRESHOLD_Quantize must be between 0 and 100");
            }
        }
        catch (const exception& e) {
            cerr << "[ERROR] Invalid threshold: " << argv[2] << ". Use a number between 0 and 100.\n";
            return 1;
        }

        input_file_size = getFileSize(inputPath);
        if (input_file_size == 0) {
            cerr << "[ERROR] Could not determine input file size: " << inputPath << endl;
            MPI_Finalize();
            return 1;
        }

        img = imread(inputPath, IMREAD_COLOR);
        filesystem::path inputFilePath(inputPath);
        extension = inputFilePath.extension().string();
        if (img.empty()) {
            cerr << "[ERROR] Could not open image file: " << inputPath << endl;
            MPI_Finalize();
            return 1;
        }

        // Store original dimensions
        orig_rows = img.rows;
        orig_cols = img.cols;

        // Pad image to make dimensions divisible by 8
        int pad_rows = (8 - (img.rows % 8)) % 8;
        int pad_cols = (8 - (img.cols % 8)) % 8;
        if (pad_rows > 0 || pad_cols > 0) {
            Mat img_padded(img.rows + pad_rows, img.cols + pad_cols, img.type(), Scalar(0));
            img.copyTo(img_padded(Rect(0, 0, img.cols, img.rows)));
            img = img_padded;
        }

        // Convert to YCrCb
        cvtColor(img, myImage_Converted, COLOR_BGR2YCrCb);
        Mat different_Channels[3];
        split(myImage_Converted, different_Channels);
        Y = different_Channels[0];
        Mat Cr = different_Channels[1];
        Mat Cb = different_Channels[2];

        Y_numRows = myImage_Converted.rows;
        Y_numCols = myImage_Converted.cols;
        Y_numBlocks = (Y_numRows / 8) * (Y_numCols / 8);

        // 4:2:2 subsampling
        Cr_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
        Cb_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
        SubSample422(Cr, Cr_422);
        SubSample422(Cb, Cb_422);

        // Pad chrominance matrices
        C_numRows = Cr_422.rows;
        C_numCols = Cr_422.cols;
        int padding_cols = (8 - (C_numCols % 8)) % 8;
        if (padding_cols > 0) {
            Mat temp_cr(C_numRows, C_numCols + padding_cols, CV_8UC1, Scalar(128));
            Mat temp_cb(C_numRows, C_numCols + padding_cols, CV_8UC1, Scalar(128));
            Cr_422.copyTo(temp_cr(Rect(0, 0, Cr_422.cols, Cr_422.rows)));
            Cb_422.copyTo(temp_cb(Rect(0, 0, Cb_422.cols, Cb_422.rows)));
            Cr_422 = temp_cr;
            Cb_422 = temp_cb;
            C_numCols = Cr_422.cols;
        }

        C_numBlocks = (C_numRows / 8) * (C_numCols / 8);

        cout << "\n==================== Info of Image =======================\n";
        cout << "[INFO] Image to compress: " << inputPath << endl;
        cout << "[INFO] Input File Size: " << input_file_size << " bytes\n";
        cout << "[INFO] Threshold: Keeping top " << THRESHOLD_PERCENT * 100 << "% of coefficients\n";
        cout << "[INFO] Level of Quantization: " << THRESHOLD_Quantize * 100 << "%\n";
        cout << "[INFO] Y size: " << Y_numCols << "x" << Y_numRows << ", Processing " << Y_numBlocks << " blocks.\n";
        cout << "[INFO] C size: " << C_numCols << "x" << C_numRows << ", Processing " << C_numBlocks << " blocks.\n";
    }

    // Broadcast metadata
    MPI_Bcast(&THRESHOLD_PERCENT, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&input_file_size, 1, MPI_UNSIGNED_LONG, 0, MPI_COMM_WORLD);
    MPI_Bcast(&orig_rows, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&orig_cols, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Y_numBlocks, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&C_numBlocks, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Y_numRows, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Y_numCols, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&C_numRows, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&C_numCols, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Calculate block distribution
    int Y_blocks_per_proc = Y_numBlocks / num_process;
    int Y_remainder = Y_numBlocks % num_process;
    int Y_start = my_rank * Y_blocks_per_proc + min(my_rank, Y_remainder);
    int Y_end = Y_start + Y_blocks_per_proc + (my_rank < Y_remainder ? 1 : 0);
    int my_Y_numBlocks = Y_end - Y_start;

    int C_blocks_per_proc = C_numBlocks / num_process;
    int C_remainder = C_numBlocks % num_process;
    int C_start = my_rank * C_blocks_per_proc + min(my_rank, C_remainder);
    int C_end = C_start + C_blocks_per_proc + (my_rank < C_remainder ? 1 : 0);
    int my_C_numBlocks = C_end - C_start;

    // Allocate memory
    xformBlock* Y_blockArr = nullptr;
    xformBlock* Cr_blockArr = nullptr;
    xformBlock* Cb_blockArr = nullptr;
    if (my_rank == 0) {
        Y_blockArr = new xformBlock[Y_numBlocks];
        Cr_blockArr = new xformBlock[C_numBlocks];
        Cb_blockArr = new xformBlock[C_numBlocks];
    }
    xformBlock* my_Y_blockArr = new xformBlock[my_Y_numBlocks];
    xformBlock* my_Cr_blockArr = new xformBlock[my_C_numBlocks];
    xformBlock* my_Cb_blockArr = new xformBlock[my_C_numBlocks];

    vector<uint8_t> Y_bitstream(Y_numBlocks * 136);
    vector<uint8_t> Cr_bitstream(C_numBlocks * 136);
    vector<uint8_t> Cb_bitstream(C_numBlocks * 136);
    vector<uint8_t> my_Y_bitstream(my_Y_numBlocks * 136);
    vector<uint8_t> my_Cr_bitstream(my_C_numBlocks * 136);
    vector<uint8_t> my_Cb_bitstream(my_C_numBlocks * 136);

    vector<int16_t> Y_bitstream16(Y_numBlocks * 272);
    vector<int16_t> Cr_bitstream16(C_numBlocks * 272);
    vector<int16_t> Cb_bitstream16(C_numBlocks * 272);
    vector<int16_t> my_Y_bitstream16(my_Y_numBlocks * 272);
    vector<int16_t> my_Cr_bitstream16(my_C_numBlocks * 272);
    vector<int16_t> my_Cb_bitstream16(my_C_numBlocks * 272);

    // Prepare for Scatterv
    vector<int> Y_sendcounts(num_process), Y_displs(num_process);
    vector<int> C_sendcounts(num_process), C_displs(num_process);
    for (int i = 0; i < num_process; i++) {
        Y_sendcounts[i] = (Y_blocks_per_proc + (i < Y_remainder ? 1 : 0)) * sizeof(xformBlock);
        Y_displs[i] = (i * Y_blocks_per_proc + min(i, Y_remainder)) * sizeof(xformBlock);
        C_sendcounts[i] = (C_blocks_per_proc + (i < C_remainder ? 1 : 0)) * sizeof(xformBlock);
        C_displs[i] = (i * C_blocks_per_proc + min(i, C_remainder)) * sizeof(xformBlock);
    }

    // Compression
    if (my_rank == 0) {
        getblockarray(Y, Y_blockArr);
        getblockarray(Cr_422, Cr_blockArr);
        getblockarray(Cb_422, Cb_blockArr);
        for (int i = 0; i < Y_numBlocks; i++) {
            block2bitstream(&Y_blockArr[i], &Y_bitstream[i * 136]);
        }
        for (int i = 0; i < C_numBlocks; i++) {
            block2bitstream(&Cr_blockArr[i], &Cr_bitstream[i * 136]);
            block2bitstream(&Cb_blockArr[i], &Cb_bitstream[i * 136]);
        }
    }

    // Scatter bitstreams
    for (int i = 0; i < num_process; i++) {
        Y_sendcounts[i] = (Y_blocks_per_proc + (i < Y_remainder ? 1 : 0)) * 136;
        Y_displs[i] = (i * Y_blocks_per_proc + min(i, Y_remainder)) * 136;
        C_sendcounts[i] = (C_blocks_per_proc + (i < C_remainder ? 1 : 0)) * 136;
        C_displs[i] = (i * C_blocks_per_proc + min(i, C_remainder)) * 136;
    }
    MPI_Scatterv(Y_bitstream.data(), Y_sendcounts.data(), Y_displs.data(), MPI_UINT8_T,
        my_Y_bitstream.data(), my_Y_numBlocks * 136, MPI_UINT8_T, 0, MPI_COMM_WORLD);
    MPI_Scatterv(Cr_bitstream.data(), C_sendcounts.data(), C_displs.data(), MPI_UINT8_T,
        my_Cr_bitstream.data(), my_C_numBlocks * 136, MPI_UINT8_T, 0, MPI_COMM_WORLD);
    MPI_Scatterv(Cb_bitstream.data(), C_sendcounts.data(), C_displs.data(), MPI_UINT8_T,
        my_Cb_bitstream.data(), my_C_numBlocks * 136, MPI_UINT8_T, 0, MPI_COMM_WORLD);

    // Compression processing
    MPI_Barrier(MPI_COMM_WORLD);
    start = MPI_Wtime();
    if (my_rank == 0) {
        cout << "\n============= Start Compression ====================\n";
    }

    for (int i = 0; i < my_Y_numBlocks; i++) {
        bitstream2block(&my_Y_blockArr[i], &my_Y_bitstream[i * 136]);
        FFT_8x8(&my_Y_blockArr[i]);
        applyThreshold(&my_Y_blockArr[i], THRESHOLD_PERCENT);
        QuantizeLuminance(&my_Y_blockArr[i], THRESHOLD_Quantize);
        block2bitstream16(&my_Y_blockArr[i], &my_Y_bitstream16[i * 272]);
    }
    for (int i = 0; i < my_C_numBlocks; i++) {
        bitstream2block(&my_Cr_blockArr[i], &my_Cr_bitstream[i * 136]);
        FFT_8x8(&my_Cr_blockArr[i]);
        applyThreshold(&my_Cr_blockArr[i], THRESHOLD_PERCENT);
        QuantizeChrominance(&my_Cr_blockArr[i], THRESHOLD_Quantize);
        block2bitstream16(&my_Cr_blockArr[i], &my_Cr_bitstream16[i * 272]);
        bitstream2block(&my_Cb_blockArr[i], &my_Cb_bitstream[i * 136]);
        FFT_8x8(&my_Cb_blockArr[i]);
        applyThreshold(&my_Cb_blockArr[i], THRESHOLD_PERCENT);
        QuantizeChrominance(&my_Cb_blockArr[i], THRESHOLD_Quantize);
        block2bitstream16(&my_Cb_blockArr[i], &my_Cb_bitstream16[i * 272]);
    }

    // Gather compressed bitstreams
    for (int i = 0; i < num_process; i++) {
        Y_sendcounts[i] = (Y_blocks_per_proc + (i < Y_remainder ? 1 : 0)) * 272;
        Y_displs[i] = (i * Y_blocks_per_proc + min(i, Y_remainder)) * 272;
        C_sendcounts[i] = (C_blocks_per_proc + (i < C_remainder ? 1 : 0)) * 272;
        C_displs[i] = (i * C_blocks_per_proc + min(i, C_remainder)) * 272;
    }
    MPI_Gatherv(my_Y_bitstream16.data(), my_Y_numBlocks * 272, MPI_INT16_T,
        Y_bitstream16.data(), Y_sendcounts.data(), Y_displs.data(), MPI_INT16_T, 0, MPI_COMM_WORLD);
    MPI_Gatherv(my_Cr_bitstream16.data(), my_C_numBlocks * 272, MPI_INT16_T,
        Cr_bitstream16.data(), C_sendcounts.data(), C_displs.data(), MPI_INT16_T, 0, MPI_COMM_WORLD);
    MPI_Gatherv(my_Cb_bitstream16.data(), my_C_numBlocks * 272, MPI_INT16_T,
        Cb_bitstream16.data(), C_sendcounts.data(), C_displs.data(), MPI_INT16_T, 0, MPI_COMM_WORLD);

    // Huffman encoding
    size_t compressed_size = 0;
    if (my_rank == 0) {
        vector<int16_t> combined_bitstream;
        combined_bitstream.insert(combined_bitstream.end(), Y_bitstream16.begin(), Y_bitstream16.end());
        combined_bitstream.insert(combined_bitstream.end(), Cr_bitstream16.begin(), Cr_bitstream16.end());
        combined_bitstream.insert(combined_bitstream.end(), Cb_bitstream16.begin(), Cb_bitstream16.end());

        Huffman huffman;
        huffman.buildTree(combined_bitstream);
        vector<bool> encoded;
        huffman.encode(combined_bitstream, encoded);
        huffman.saveToFile(encoded, Y_numBlocks, C_numBlocks, THRESHOLD_PERCENT * 100, "compress.bin");

        compressed_size = getFileSize("compress.bin");
        if (compressed_size == 0) {
            compressed_size = (encoded.size() + 7) / 8 + sizeof(Y_numBlocks) + sizeof(C_numBlocks) + sizeof(THRESHOLD_PERCENT * 100);
        }

        end = MPI_Wtime();
        cout << "[INFO] Compression Time: " << (end - start) << " seconds\n";
        cout << "[INFO] Compressed data saved to: compress.bin\n";
    }

    // Decompression
    MPI_Barrier(MPI_COMM_WORLD);
    start = MPI_Wtime();
    vector<int16_t> decoded_bitstream;
    size_t total_values = Y_numBlocks * 272 + 2 * C_numBlocks * 272;
    if (my_rank == 0) {
        cout << "\n============= Start Decompression ====================\n";
        Huffman huffman;
        vector<bool> encoded_loaded;
        size_t Y_blocks_loaded, C_blocks_loaded;
        double threshold_loaded;
        if (!huffman.loadFromFile(encoded_loaded, Y_blocks_loaded, C_blocks_loaded, threshold_loaded, "compress.bin")) {
            cerr << "[ERROR] Failed to load compress.bin\n";
            if (my_rank == 0) {
                delete[] Y_blockArr;
                delete[] Cr_blockArr;
                delete[] Cb_blockArr;
            }
            delete[] my_Y_blockArr;
            delete[] my_Cr_blockArr;
            delete[] my_Cb_blockArr;
            MPI_Finalize();
            return 1;
        }
        if (Y_blocks_loaded != Y_numBlocks || C_blocks_loaded != C_numBlocks || abs(threshold_loaded - THRESHOLD_PERCENT * 100) > 1e-6) {
            cerr << "[ERROR] Mismatch in loaded parameters\n";
            if (my_rank == 0) {
                delete[] Y_blockArr;
                delete[] Cr_blockArr;
                delete[] Cb_blockArr;
            }
            delete[] my_Y_blockArr;
            delete[] my_Cr_blockArr;
            delete[] my_Cb_blockArr;
            MPI_Finalize();
            return 1;
        }
        decoded_bitstream.resize(total_values);
        huffman.decode(encoded_loaded, total_values, decoded_bitstream);
    }
    else {
        decoded_bitstream.resize(total_values);
    }

    // Broadcast decoded bitstream
    MPI_Bcast(decoded_bitstream.data(), total_values, MPI_INT16_T, 0, MPI_COMM_WORLD);

    // Split bitstream locally
    vector<int16_t> my_Y_bitstream16_decomp(my_Y_numBlocks * 272);
    vector<int16_t> my_Cr_bitstream16_decomp(my_C_numBlocks * 272);
    vector<int16_t> my_Cb_bitstream16_decomp(my_C_numBlocks * 272);
    for (int i = 0; i < my_Y_numBlocks; i++) {
        copy(decoded_bitstream.begin() + (Y_start + i) * 272,
            decoded_bitstream.begin() + (Y_start + i + 1) * 272,
            my_Y_bitstream16_decomp.begin() + i * 272);
    }
    for (int i = 0; i < my_C_numBlocks; i++) {
        copy(decoded_bitstream.begin() + Y_numBlocks * 272 + (C_start + i) * 272,
            decoded_bitstream.begin() + Y_numBlocks * 272 + (C_start + i + 1) * 272,
            my_Cr_bitstream16_decomp.begin() + i * 272);
        copy(decoded_bitstream.begin() + Y_numBlocks * 272 + C_numBlocks * 272 + (C_start + i) * 272,
            decoded_bitstream.begin() + Y_numBlocks * 272 + C_numBlocks * 272 + (C_start + i + 1) * 272,
            my_Cb_bitstream16_decomp.begin() + i * 272);
    }

    // Decompression processing
    for (int i = 0; i < my_Y_numBlocks; i++) {
        bitstream2block16(&my_Y_blockArr[i], &my_Y_bitstream16_decomp[i * 272]);
        InvQuantizeLuminance(&my_Y_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&my_Y_blockArr[i]);
        block2bitstream(&my_Y_blockArr[i], &my_Y_bitstream[i * 136]);
    }
    for (int i = 0; i < my_C_numBlocks; i++) {
        bitstream2block16(&my_Cr_blockArr[i], &my_Cr_bitstream16_decomp[i * 272]);
        InvQuantizeChrominance(&my_Cr_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&my_Cr_blockArr[i]);
        block2bitstream(&my_Cr_blockArr[i], &my_Cr_bitstream[i * 136]);
        bitstream2block16(&my_Cb_blockArr[i], &my_Cb_bitstream16_decomp[i * 272]);
        InvQuantizeChrominance(&my_Cb_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&my_Cb_blockArr[i]);
        block2bitstream(&my_Cb_blockArr[i], &my_Cb_bitstream[i * 136]);
    }

    // Gather decompressed bitstreams
    for (int i = 0; i < num_process; i++) {
        Y_sendcounts[i] = (Y_blocks_per_proc + (i < Y_remainder ? 1 : 0)) * 136;
        Y_displs[i] = (i * Y_blocks_per_proc + min(i, Y_remainder)) * 136;
        C_sendcounts[i] = (C_blocks_per_proc + (i < C_remainder ? 1 : 0)) * 136;
        C_displs[i] = (i * C_blocks_per_proc + min(i, C_remainder)) * 136;
    }
    MPI_Gatherv(my_Y_bitstream.data(), my_Y_numBlocks * 136, MPI_UINT8_T,
        Y_bitstream.data(), Y_sendcounts.data(), Y_displs.data(), MPI_UINT8_T, 0, MPI_COMM_WORLD);
    MPI_Gatherv(my_Cr_bitstream.data(), my_C_numBlocks * 136, MPI_UINT8_T,
        Cr_bitstream.data(), C_sendcounts.data(), C_displs.data(), MPI_UINT8_T, 0, MPI_COMM_WORLD);
    MPI_Gatherv(my_Cb_bitstream.data(), my_C_numBlocks * 136, MPI_UINT8_T,
        Cb_bitstream.data(), C_sendcounts.data(), C_displs.data(), MPI_UINT8_T, 0, MPI_COMM_WORLD);

    // Post-processing
    if (my_rank == 0) {
        end = MPI_Wtime();
        cout << "[INFO] Decompression Time: " << (end - start) << " seconds\n";

        // Convert bitstreams to blocks
        for (int i = 0; i < Y_numBlocks; i++) {
            bitstream2block(&Y_blockArr[i], &Y_bitstream[i * 136]);
        }
        for (int i = 0; i < C_numBlocks; i++) {
            bitstream2block(&Cr_blockArr[i], &Cr_bitstream[i * 136]);
            bitstream2block(&Cb_blockArr[i], &Cb_bitstream[i * 136]);
        }

        // Initialize matrices
        Mat Y_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
        Mat Cr_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
        Mat Cb_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
        Mat Cr_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
        Mat Cb_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));

        // Convert blocks to matrices
        getmat(Y_compressed, Y_blockArr);
        getmat(Cr_422_compressed, Cr_blockArr);
        getmat(Cb_422_compressed, Cb_blockArr);

        // Upsample chrominance (4:2:2)
        UpSample422(Cr_422_compressed, Cr_compressed);
        UpSample422(Cb_422_compressed, Cb_compressed);

        // Crop to original dimensions
        Mat Y_compressed_cropped = Y_compressed(Rect(0, 0, orig_cols, orig_rows));
        Mat Cr_compressed_cropped = Cr_compressed(Rect(0, 0, orig_cols, orig_rows));
        Mat Cb_compressed_cropped = Cb_compressed(Rect(0, 0, orig_cols, orig_rows));

        // Merge channels
        Mat different_Channels[3] = { Y_compressed_cropped, Cr_compressed_cropped, Cb_compressed_cropped };
        Mat img_compressed;
        merge(different_Channels, 3, img_compressed);
        Mat img_compressed_rgb;
        cvtColor(img_compressed, img_compressed_rgb, COLOR_YCrCb2BGR);

        string compPath = "Image_Decompressed_MPI.bmp";
        string compOriPath = "Image_Decompressed_MPI" + extension;

        //string diffPath = "Difference_Image_Serial.png";
        if (!imwrite(compPath, img_compressed_rgb)) {
            cerr << "[ERROR] Failed to save decompressed image at " << compPath << endl;
        }
        else {
            //int out = rename(compPath.c_str(), compOriPath.c_str());
            // cout << "[INFO] Decompressed image from bin saved to: " << compPath << endl;
        }
        //resize(img_compressed_rgb, img_compressed_rgb, img.size());

        if (!imwrite(compOriPath, img_compressed_rgb)) {
            cerr << "[ERROR] Failed to save image at " << compOriPath << endl;
        }
        else {
            cout << "[INFO] Decompressed image saved to: " << compOriPath << endl;
        }
        img = imread(inputPath, IMREAD_COLOR);
        // Compute PSNR
        Mat img_channels[3];
        split(img, img_channels);
        Mat B = img_channels[0];
        Mat G = img_channels[1];
        Mat R = img_channels[2];

        Mat img_channels_compress[3];
        split(img_compressed_rgb, img_channels_compress);
        Mat B_compress = img_channels_compress[0];
        Mat G_compress = img_channels_compress[1];
        Mat R_compress = img_channels_compress[2];

        double PSNR_R = PSNR(R, R_compress);
        double PSNR_G = PSNR(G, G_compress);
        double PSNR_B = PSNR(B, B_compress);
        cout << "\n============= Quality of Compression ====================\n";
        cout << "[INFO] PSNR_R: " << PSNR_R << " dB\n";
        cout << "[INFO] PSNR_G: " << PSNR_G << " dB\n";
        cout << "[INFO] PSNR_B: " << PSNR_B << " dB\n";

        // Compression statistics
        size_t original_size = getFileSize(inputPath);
        size_t de_size = getFileSize(compPath);
        size_t memory_size = getImageMemorySize(inputPath);
        size_t dememory_size = getImageMemorySize(compPath);
        double compression_rate = static_cast<double>(original_size) / compressed_size;
        cout << "\n==================== Summary of Comparison ====================\n";
        cout << "[INFO] Original Size: " << original_size << " bytes\n";
        cout << "[INFO] Used memory to display: " << memory_size << " bytes\n";
        cout << "[INFO] Decompressed Size: " << de_size << " bytes\n";
        cout << "[INFO] Used memory to display: " << dememory_size << " bytes\n";
        cout << "[INFO] Compressed Size: " << compressed_size << " bytes\n";
        cout << "[INFO] Compression Rate: " << compression_rate << ":1\n";

        reportImageSizes(img, img_compressed_rgb, "compress.bin", compOriPath);
    }

    // Cleanup
    if (my_rank == 0) {
        delete[] Y_blockArr;
        delete[] Cr_blockArr;
        delete[] Cb_blockArr;
    }
    delete[] my_Y_blockArr;
    delete[] my_Cr_blockArr;
    delete[] my_Cb_blockArr;

    MPI_Finalize();
    return 0;
}

void mat2block(Mat* mat, xformBlock* block) {
    for (int currRow = 0; currRow < 8; currRow++) {
        for (int currCol = 0; currCol < 8; currCol++) {
            block->data[currRow][currCol] = mat->at<uchar>(currRow, currCol);
        }
    }
}

void block2mat(Mat* mat, xformBlock* block) {
    for (int currRow = 0; currRow < 8; currRow++) {
        for (int currCol = 0; currCol < 8; currCol++) {
            uchar temp;
            if (block->data[currRow][currCol].real() > 255.0) {
                temp = 255;
            }
            else if (block->data[currRow][currCol].real() < 0.0) {
                temp = 0;
            }
            else {
                temp = round(block->data[currRow][currCol].real());
            }
            mat->at<uchar>(currRow, currCol) = temp;
        }
    }
}

void getblockarray(Mat mat, xformBlock* blockarr) {
    int blockidx = 0;
    Mat im_roi = Mat(8, 8, CV_8UC1, 0.0);
    for (int currRow = 0; currRow < mat.rows; currRow += 8) {
        for (int currCol = 0; currCol < mat.cols; currCol += 8) {
            Rect roi(currCol, currRow, 8, 8);
            im_roi = mat(roi).clone();
            mat2block(&im_roi, &blockarr[blockidx]);
            blockidx++;
        }
    }
}

void getmat(Mat mat, xformBlock* blockarr) {
    int blockidx = 0;
    Mat im_roi = Mat(8, 8, CV_8UC1, 0.0);
    for (int currRow = 0; currRow < mat.rows; currRow += 8) {
        for (int currCol = 0; currCol < mat.cols; currCol += 8) {
            Rect roi(currCol, currRow, 8, 8);
            block2mat(&im_roi, &blockarr[blockidx]);
            im_roi.copyTo(mat(roi));
            blockidx++;
        }
    }
}

void block2bitstream(xformBlock* block, uint8_t* arr) {
    memcpy(arr, &block->row_index, sizeof(int));
    memcpy(&arr[5], &block->col_index, sizeof(int));
    int arridx = 9;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            uint8_t temp_real;
            uint8_t temp_imag = (uint8_t)block->data[i][j].imag();
            if (block->data[i][j].real() > 255.0) {
                temp_real = 255;
            }
            else if (block->data[i][j].real() < 0.0) {
                temp_real = 0;
            }
            else {
                temp_real = (uint8_t)block->data[i][j].real();
            }
            memcpy(&arr[arridx], &temp_real, sizeof(uint8_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(uint8_t));
            arridx += 2;
        }
    }
}

void bitstream2block(xformBlock* block, uint8_t* arr) {
    block->row_index = arr[0] | (arr[1] << 8) | (arr[2] << 16) | (arr[3] << 24);
    block->col_index = arr[5] | (arr[6] << 8) | (arr[7] << 16) | (arr[8] << 24);
    int arridx = 9;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }
}

void block2bitstream16(xformBlock* block, int16_t* arr) {
    int arridx = 5;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            int16_t temp_real = (int16_t)block->data[i][j].real();
            int16_t temp_imag = (int16_t)block->data[i][j].imag();
            memcpy(&arr[arridx], &temp_real, sizeof(int16_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(int16_t));
            arridx += 2;
        }
    }
}

void bitstream2block16(xformBlock* block, int16_t* arr) {
    int arridx = 5;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }
}

double PSNR(Mat PreImg, Mat PostImg) {
    double MSE = 0.0;
    double temp = 0.0;
    for (int currRow = 0; currRow < PreImg.rows; currRow++) {
        for (int currCol = 0; currCol < PreImg.cols; currCol++) {
            temp = (int)PreImg.at<uchar>(currRow, currCol) - (int)PostImg.at<uchar>(currRow, currCol);
            MSE += pow(temp, 2);
        }
    }
    MSE = MSE / ((int)PreImg.rows * (int)PostImg.cols);
    return 10 * log10(pow(255, 2) / MSE);
}

void applyThreshold(xformBlock* block, double thresholdPercent) {
    vector<pair<double, pair<int, int>>> magnitudes;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            double mag = abs(block->data[i][j]);
            magnitudes.push_back({ mag, {i, j} });
        }
    }
    sort(magnitudes.rbegin(), magnitudes.rend());
    int keep_count = static_cast<int>(64 * thresholdPercent);
    if (keep_count < 1) keep_count = 1;
    for (int idx = keep_count; idx < 64; idx++) {
        int i = magnitudes[idx].second.first;
        int j = magnitudes[idx].second.second;
        block->data[i][j] = complex<double>(0, 0);
    }
}

size_t getFileSize(const string& filename) {
    ifstream in(filename, ios::binary | ios::ate);
    if (!in) return 0;
    size_t size = in.tellg();
    in.close();
    return size;
}

size_t getImageMemorySize(const string& filename) {
    Mat img = imread(filename, IMREAD_UNCHANGED);
    if (img.empty()) {
        cerr << "Failed to load image: " << filename << endl;
        return 0;
    }
    return img.total() * img.elemSize();
}

void reportImageSizes(
    const cv::Mat& original,
    const cv::Mat& decompressed,
    const std::string& compressedBinPath,
    const std::string& jpegPath
) {
    size_t original_memory = original.total() * original.elemSize();
    size_t decompressed_memory = decompressed.total() * decompressed.elemSize();
    size_t compressed_bin_size = getFileSize(compressedBinPath);
    size_t jpeg_file_size = getFileSize(jpegPath);

    std::cout << "\n============= Memory Size Report =========================\n";
    std::cout << std::fixed << std::setprecision(2);

    std::cout << "[INFO] Original Image (RAM):       " << original_memory << " bytes (" << original_memory / 1024.0 << " KB)\n";
    std::cout << "[INFO] Decompressed Image (RAM):   " << decompressed_memory << " bytes (" << decompressed_memory / 1024.0 << " KB)\n";
    std::cout << "[INFO] Compressed File (BIN):      " << compressed_bin_size << " bytes (" << compressed_bin_size / 1024.0 << " KB)\n";
    std::cout << "[INFO] Compressed JPEG (imwrite):  " << jpeg_file_size << " bytes (" << jpeg_file_size / 1024.0 << " KB)\n";

    double compression_rate = (double)original_memory / compressed_bin_size;
    double compression_percent = (1.0 - (double)compressed_bin_size / original_memory) * 100.0;

    std::cout << "[INFO] Compression Rate (RAM : BIN) = " << compression_rate << " : 1\n";
    std::cout << "[INFO] Space Saved (vs RAM) = " << compression_percent << " %\n";

    double jpeg_percent = (1.0 - (double)jpeg_file_size / original_memory) * 100.0;
    std::cout << "[INFO] JPEG Space Saved (vs RAM) = " << jpeg_percent << " %\n";
}



