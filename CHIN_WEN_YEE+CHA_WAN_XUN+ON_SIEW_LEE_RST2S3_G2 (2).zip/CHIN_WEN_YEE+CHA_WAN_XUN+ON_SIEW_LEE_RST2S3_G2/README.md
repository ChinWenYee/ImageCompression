# FFT-Image-Compression
This project demonstrates lossy image compression using the 2D Fast Fourier Transform (FFT), implemented in both serial and parallel (MPI-based) versions for performance comparison.

# 🧠 FFT Image Compression: Serial vs Parallel (MPI)

This project demonstrates **lossy image compression** using the **2D Fast Fourier Transform (FFT)**, implemented in both **serial** and **parallel (MPI-based)** versions for performance comparison.

---

## 🔍 Overview

We compress grayscale images by:

- Converting the image to **YCrCb** color space and working on the **luminance (Y)** channel  
- Applying **8×8 block-wise 2D FFT**  
- Performing **threshold-based frequency filtering** to retain the most significant coefficients  
- Applying **inverse FFT (IFFT)** to reconstruct the image  
- Saving the compressed result  

---

## 🚀 Features

- 📦 **Serial version**: Basic implementation using OpenCV and custom FFT  
- ⚡ **Parallel version (MPI)**: Uses `MPI_Scatterv` and `MPI_Gatherv` to distribute and collect 8x8 FFT blocks across multiple processes  
- 🧮 **Compression ratio calculation**  
- ⏱️ **Measures execution time** for performance benchmarking  

---

## 🖼️ Example Results

- Original vs Compressed image size  
- Compression ratio and quality tradeoff based on threshold  
- Timing comparison between serial and parallel versions  

---


## 🖼️ FLOW

- 🔵 Compression Flow:
  Input Image -> imread
             -> Validate file + threshold (0–100%)
             -> Convert to YCrCb
             -> Split to Y, Cr, Cb
  
  Y/Cr/Cb -> Pad to 8×8 blocks (if needed)
           -> 4:2:2 Subsample Cr, Cb
  
  Y/Cr/Cb Blocks -> FFT (8x8)
                  -> Threshold coefficients (keep top X%)
                  -> Quantize (Y: luminance, Cr/Cb: chrominance)
                  -> Convert to bitstream (272 values/block)
  
  All Bitstreams -> Combine Y, Cr, Cb
                 -> Huffman Encode
                 -> Save as compress.bin + header
  
  Temp Thresholded Blocks -> IFFT (8x8)
                           -> Reconstruct matrices
                           -> Upsample Cr/Cb
                           -> Merge YCrCb -> BGR
                           -> Save as Thresholded_Image.png
  
  Measure:
  Original size + compress.bin size
  -> Compression Rate
  -> Compression Time


- 🔴 Decompression Flow:
  compress.bin -> Read header (Y blocks, C blocks, threshold)
                -> Huffman Decode
                -> Split into Y, Cr, Cb bitstreams
  
  Y/Cr/Cb Bitstreams -> Convert to blocks
                      -> Inverse Quantize
                      -> IFFT (8x8)
  
  Blocks -> Reconstruct Y, Cr, Cb matrices
          -> Upsample Cr/Cb
          -> Crop to original size
          -> Merge to YCrCb -> BGR
          -> Save as Image_Compressed_Serial.png
  
  Compare:
  Original vs Compressed -> Difference Image
                          -> Save Difference_Image_Serial.png
                          -> Compute PSNR (BGR)
                          -> Report Decompression Time
  


---


## 🧪 How to Run

### 🔧 Serial Version

```bash
serial_image_compression.exe test.jpg 0.5 0.5
mpiexec -n 4 mpi_image_compression.exe test.jpeg 0.5 0.5
```
### Sample
```
==================== Info of Image =======================
[INFO] Image to compress: hinata.jpeg
[INFO] Input File Size: 167226 bytes
[INFO] Threshold: Keeping top 50% of coefficients
[INFO] Level of Quantization: 50%
[INFO] Y size: 240x240, Processing 900 blocks.
[INFO] C size: 120x240, Processing 450 blocks.

============= Start Compression ====================
[INFO] Compression Time: 3.78175 seconds
[INFO] Compressed data saved to: compress.bin

============= Start Decompression ====================
[INFO] Decompression Time: 0.491048 seconds
[INFO] Decompressed image saved to: Image_Decompressed_Serial.jpeg

============= Quality of Compression ====================
[INFO] PSNR_R: 34.1626 dB
[INFO] PSNR_G: 36.0318 dB
[INFO] PSNR_B: 34.6707 dB

==================== Summary of Comparison ====================
[INFO] Original Size: 167226 bytes
[INFO] Used memory to display: 167088 bytes
[INFO] Decompressed Size: 167142 bytes
[INFO] Used memory to display: 167088 bytes
[INFO] Compressed Size: 86489 bytes
[INFO] Compression Rate: 1.93349:1

============= Memory Size Report =========================
[INFO] Original Image (RAM):       167088 bytes (163.17 KB)
[INFO] Decompressed Image (RAM):   167088 bytes (163.17 KB)
[INFO] Compressed File (BIN):      86489 bytes (84.46 KB)
[INFO] Compressed JPEG (imwrite):  18084 bytes (17.66 KB)
[INFO] Compression Rate (RAM : BIN) = 1.93 : 1
[INFO] Space Saved (vs RAM) = 48.24 %
[INFO] JPEG Space Saved (vs RAM) = 89.18 %
```
