﻿#include<iostream>
#include "FFT.hpp"
#include "ImageProcessing.hpp"
#include "Huffman.hpp"
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>
#include <iomanip> 
#include <filesystem> 
#include <stdint.h>
#include <string> 
#include <chrono>

using namespace std;
using namespace cv;
namespace fs = std::filesystem;

void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void getblockarray(Mat mat, xformBlock* blockarr);
void getmat(Mat mat, xformBlock* blockarr);

void block2bitstream(xformBlock* block, uint8* arr);
void bitstream2block(xformBlock* block, uint8* arr);

void block2bitstream16(xformBlock* block, int16_t* arr);
void bitstream2block16(xformBlock* block, int16_t* arr);

//void* compress(void* args);
//void* decompress(void* args);

double PSNR(Mat PreImg, Mat PostImg);
void applyThreshold(xformBlock* block, double thresholdPercent);
size_t getFileSize(const string& filename);
void reportImageSizes(const cv::Mat& original, const cv::Mat& decompressed, const std::string& compressedBinPath, const std::string& jpegPath);
size_t getImageMemorySize(const string& filename);

int main(int argc, const char** argv) {
    if (argc < 4) {
        cerr << "Usage: " << argv[0] << " <image_path> <threshold> <Quantize>\n";
        return 1;
    }

    string inputPath = argv[1];
    double THRESHOLD_PERCENT;
    double THRESHOLD_Quantize;
    try {
        THRESHOLD_PERCENT = stod(argv[2]);
        THRESHOLD_Quantize = stod(argv[3]);
        if (THRESHOLD_PERCENT <= 0 || THRESHOLD_PERCENT > 1) {
            throw invalid_argument("Threshold must be between 0 and 100");
        }
        if (THRESHOLD_Quantize <= 0 || THRESHOLD_Quantize > 1) {
            throw invalid_argument("THRESHOLD_Quantize must be between 0 and 100");
        }
    }
    catch (const exception& e) {
        cerr << "[ERROR] Invalid threshold: " << argv[2] << ". Use a number between 0 and 100.\n";
        return 1;
    }

    // Get input file size
    size_t input_file_size = getFileSize(inputPath);
    if (input_file_size == 0) {
        cerr << "[ERROR] Could not determine input file size: " << inputPath << endl;
        return 1;
    }
    cout << "\n==================== Info of Image =======================\n";

    cout << "[INFO] Image to compress: " << inputPath << endl;
    cout << "[INFO] Input File Size: " << input_file_size << " bytes\n";
    cout << "[INFO] Threshold: Keeping top " << THRESHOLD_PERCENT*100 << "% of coefficients\n";
    cout << "[INFO] Level of Quantization: " << THRESHOLD_Quantize * 100 << "%\n";
    // Read image
    Mat img = imread(inputPath, IMREAD_COLOR);
    fs::path inputFilePath(inputPath);
    string extension = inputFilePath.extension().string(); // e.g., ".png"

    if (img.empty()) {
        cerr << "[ERROR] Could not open image file: " << inputPath << endl;
        return 1;
    }

    // Store original dimensions
    int orig_rows = img.rows;
    int orig_cols = img.cols;

    // Convert to YCrCb
    Mat ycrcbImg;
    cvtColor(img, ycrcbImg, COLOR_BGR2YCrCb);

    // Split channels
    Mat channels[3];
    split(ycrcbImg, channels);
    Mat Y = channels[0], Cr = channels[1], Cb = channels[2];

    // Pad Y channel to be divisible by 8
    int Y_numRows = ycrcbImg.rows;
    int Y_numCols = ycrcbImg.cols;
    int pad_rows = (8 - (Y_numRows % 8)) % 8;
    int pad_cols = (8 - (Y_numCols % 8)) % 8;
    if (pad_rows > 0 || pad_cols > 0) {
        Mat Y_padded(Y_numRows + pad_rows, Y_numCols + pad_cols, CV_8UC1, Scalar(128));
        Y.copyTo(Y_padded(Rect(0, 0, Y_numCols, Y_numRows)));
        Y = Y_padded;
        Y_numRows = Y.rows;
        Y_numCols = Y.cols;

        Mat Cr_padded(Y_numRows, Y_numCols, CV_8UC1, Scalar(128));
        Cr.copyTo(Cr_padded(Rect(0, 0, Cr.cols, Cr.rows)));
        Cr = Cr_padded;

        Mat Cb_padded(Y_numRows, Y_numCols, CV_8UC1, Scalar(128));
        Cb.copyTo(Cb_padded(Rect(0, 0, Cb.cols, Cb.rows)));
        Cb = Cb_padded;
    }

    // Calculate Y block counts
    int Y_numBlocks = (Y_numRows / 8) * (Y_numCols / 8);

    // 4:2:2 subsampling
    Mat Cr_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
    Mat Cb_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(128));
    SubSample422(Cr, Cr_422);
    SubSample422(Cb, Cb_422);

    // Pad Cr_422 and Cb_422 cols
    int C_numCols = Cr_422.cols;
    int C_numRows = Cr_422.rows;
    pad_cols = (8 - (C_numCols % 8)) % 8;
    if (pad_cols > 0) {
        Mat temp_cr(C_numRows, C_numCols + pad_cols, CV_8UC1, Scalar(128));
        Mat temp_cb(C_numRows, C_numCols + pad_cols, CV_8UC1, Scalar(128));
        Cr_422.copyTo(temp_cr(Rect(0, 0, Cr_422.cols, Cr_422.rows)));
        Cb_422.copyTo(temp_cb(Rect(0, 0, Cb_422.cols, Cb_422.rows)));
        Cr_422 = temp_cr;
        Cb_422 = temp_cb;
        C_numCols = Cr_422.cols;
    }

    int C_numBlocks = (C_numRows / 8) * (C_numCols / 8);

    cout << "[INFO] Y size: " << Y_numCols << "x" << Y_numRows << ", Processing " << Y_numBlocks << " blocks.\n";
    cout << "[INFO] C size: " << C_numCols << "x" << C_numRows << ", Processing " << C_numBlocks << " blocks.\n";

    // Allocate block arrays
    xformBlock* Y_blockArr = new xformBlock[Y_numBlocks];
    xformBlock* Cr_blockArr = new xformBlock[C_numBlocks];
    xformBlock* Cb_blockArr = new xformBlock[C_numBlocks];

    // Allocate temporary block arrays for thresholding
    xformBlock* Y_blockArr_temp = new xformBlock[Y_numBlocks];
    xformBlock* Cr_blockArr_temp = new xformBlock[C_numBlocks];
    xformBlock* Cb_blockArr_temp = new xformBlock[C_numBlocks];

    // Populate block arrays
    getblockarray(Y, Y_blockArr);
    getblockarray(Cr_422, Cr_blockArr);
    getblockarray(Cb_422, Cb_blockArr);

    // Copy to temp arrays
    memcpy(Y_blockArr_temp, Y_blockArr, Y_numBlocks * sizeof(xformBlock));
    memcpy(Cr_blockArr_temp, Cr_blockArr, C_numBlocks * sizeof(xformBlock));
    memcpy(Cb_blockArr_temp, Cb_blockArr, C_numBlocks * sizeof(xformBlock));

    // Compression
    cout << "\n============= Start Compression ====================\n";
    // cout << "[INFO] Starting compression...\n";
    auto start = chrono::high_resolution_clock::now();

    // Process Y channel
    vector<int16_t> Y_bitstream(Y_numBlocks * 272);
    for (int i = 0; i < Y_numBlocks; i++) {
        FFT_8x8(&Y_blockArr[i]);
        applyThreshold(&Y_blockArr[i], THRESHOLD_PERCENT);
        QuantizeLuminance(&Y_blockArr[i], THRESHOLD_Quantize);
        block2bitstream16(&Y_blockArr[i], &Y_bitstream[i * 136]);
    }

    // Process Cr and Cb channels
    vector<int16_t> Cr_bitstream(C_numBlocks * 272);
    vector<int16_t> Cb_bitstream(C_numBlocks * 272);
    for (int i = 0; i < C_numBlocks; i++) {
        FFT_8x8(&Cr_blockArr[i]);
        applyThreshold(&Cr_blockArr[i], THRESHOLD_PERCENT);
        QuantizeChrominance(&Cr_blockArr[i], THRESHOLD_Quantize);
        block2bitstream16(&Cr_blockArr[i], &Cr_bitstream[i * 136]);

        FFT_8x8(&Cb_blockArr[i]);
        applyThreshold(&Cb_blockArr[i], THRESHOLD_PERCENT);
        QuantizeChrominance(&Cb_blockArr[i], THRESHOLD_Quantize);
        block2bitstream16(&Cb_blockArr[i], &Cb_bitstream[i * 136]);
    }

    // Combine bitstreams for Huffman
    vector<int16_t> combined_bitstream;
    combined_bitstream.insert(combined_bitstream.end(), Y_bitstream.begin(), Y_bitstream.end());
    combined_bitstream.insert(combined_bitstream.end(), Cr_bitstream.begin(), Cr_bitstream.end());
    combined_bitstream.insert(combined_bitstream.end(), Cb_bitstream.begin(), Cb_bitstream.end());

    // Huffman encoding
    Huffman huffman;
    huffman.buildTree(combined_bitstream);
    vector<bool> encoded;
    huffman.encode(combined_bitstream, encoded);
    huffman.saveToFile(encoded, Y_numBlocks, C_numBlocks, THRESHOLD_PERCENT*100, "compress.bin");

    // Get actual compressed size
    size_t compressed_size = getFileSize("compress.bin");
    if (compressed_size == 0) {
        cerr << "[WARNING] Could not determine compress.bin size\n";
        compressed_size = (encoded.size() + 7) / 8 + sizeof(Y_numBlocks) + sizeof(C_numBlocks) + sizeof(THRESHOLD_PERCENT*100);
    }

    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> compress_time = end - start;
    cout << "[INFO] Compression Time: " << compress_time.count() << " seconds\n";
    cout << "[INFO] Compressed data saved to: compress.bin\n";

    // Save thresholded image
    cout << "\n============= Start Decompression ====================\n";

    // cout << "[INFO] Saving thresholded image...\n";
    for (int i = 0; i < Y_numBlocks; i++) {
        FFT_8x8(&Y_blockArr_temp[i]);
        applyThreshold(&Y_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Y_blockArr_temp[i]);
    }
    for (int i = 0; i < C_numBlocks; i++) {
        FFT_8x8(&Cr_blockArr_temp[i]);
        applyThreshold(&Cr_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Cr_blockArr_temp[i]);

        FFT_8x8(&Cb_blockArr_temp[i]);
        applyThreshold(&Cb_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Cb_blockArr_temp[i]);
    }

    Mat Y_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cr_422_thresholded = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    Mat Cb_422_thresholded = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));

    getmat(Y_thresholded, Y_blockArr_temp);
    getmat(Cr_422_thresholded, Cr_blockArr_temp);
    getmat(Cb_422_thresholded, Cb_blockArr_temp);

    Mat Cr_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cb_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    UpSample422(Cr_422_thresholded, Cr_thresholded);
    UpSample422(Cb_422_thresholded, Cb_thresholded);

    Mat threshChannels[3] = { Y_thresholded, Cr_thresholded, Cb_thresholded };
    Mat img_thresholded;
    merge(threshChannels, 3, img_thresholded);

    Mat img_thresholded_rgb;
    cvtColor(img_thresholded, img_thresholded_rgb, COLOR_YCrCb2BGR);
    Mat resized_image = img_thresholded_rgb(Rect(0, 0, orig_cols, orig_rows));

    string threshPath = "Compressed_Image" + extension;
    //{ cv::IMWRITE_JPEG_QUALITY, 30 }
    if (!imwrite(threshPath, resized_image)) {
        cerr << "[ERROR] Failed to save thresholded image at " << threshPath << endl;
    }
    else {
        //cout << "[INFO] Compressed image saved to: " << threshPath << endl;
    }

    // Decompression
    // cout << "[INFO] Starting decompression...\n";
    start = chrono::high_resolution_clock::now();

    // Load and decode compressed data
    vector<bool> encoded_loaded;
    size_t Y_blocks_loaded, C_blocks_loaded;
    double threshold_loaded;
    if (!huffman.loadFromFile(encoded_loaded, Y_blocks_loaded, C_blocks_loaded, threshold_loaded, "compress.bin")) {
        cerr << "[ERROR] Failed to load compress.bin\n";
        delete[] Y_blockArr;
        delete[] Cr_blockArr;
        delete[] Cb_blockArr;
        delete[] Y_blockArr_temp;
        delete[] Cr_blockArr_temp;
        delete[] Cb_blockArr_temp;
        return 1;
    }

    if (Y_blocks_loaded != Y_numBlocks || C_blocks_loaded != C_numBlocks || abs(threshold_loaded - THRESHOLD_PERCENT*100) > 1e-6) {
        cerr << "[ERROR] Mismatch in loaded parameters\n";
        delete[] Y_blockArr;
        delete[] Cr_blockArr;
        delete[] Cb_blockArr;
        delete[] Y_blockArr_temp;
        delete[] Cr_blockArr_temp;
        delete[] Cb_blockArr_temp;
        return 1;
    }

    vector<int16_t> decoded_bitstream;
    size_t total_values = Y_numBlocks * 272 + 2 * C_numBlocks * 272;
    huffman.decode(encoded_loaded, total_values, decoded_bitstream);

    // Split bitstream
    Y_bitstream.assign(decoded_bitstream.begin(), decoded_bitstream.begin() + Y_numBlocks * 272);
    Cr_bitstream.assign(decoded_bitstream.begin() + Y_numBlocks * 272, decoded_bitstream.begin() + Y_numBlocks * 272 + C_numBlocks * 272);
    Cb_bitstream.assign(decoded_bitstream.begin() + Y_numBlocks * 272 + C_numBlocks * 272, decoded_bitstream.end());

    // Decompress Y channel
    for (int i = 0; i < Y_numBlocks; i++) {
        bitstream2block16(&Y_blockArr[i], &Y_bitstream[i * 136]);
        InvQuantizeLuminance(&Y_blockArr[i],THRESHOLD_Quantize);
        IFFT_8x8(&Y_blockArr[i]);
    }

    // Decompress Cr and Cb channels
    for (int i = 0; i < C_numBlocks; i++) {
        bitstream2block16(&Cr_blockArr[i], &Cr_bitstream[i * 136]);
        InvQuantizeChrominance(&Cr_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&Cr_blockArr[i]);

        bitstream2block16(&Cb_blockArr[i], &Cb_bitstream[i * 136]);
        InvQuantizeChrominance(&Cb_blockArr[i], THRESHOLD_Quantize);
        IFFT_8x8(&Cb_blockArr[i]);
    }

    end = chrono::high_resolution_clock::now();
    chrono::duration<double> decompress_time = end - start;
    cout << "[INFO] Decompression Time: " << decompress_time.count() << " seconds\n";

    // Reconstruct image
    Mat Y_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cr_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    Mat Cb_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));

    getmat(Y_compressed, Y_blockArr);
    getmat(Cr_422_compressed, Cr_blockArr);
    getmat(Cb_422_compressed, Cb_blockArr);

    // Upsample Cr and Cb
    Mat Cr_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cb_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    UpSample422(Cr_422_compressed, Cr_compressed);
    UpSample422(Cb_422_compressed, Cb_compressed);

    // Crop to original dimensions
    Mat Y_compressed_cropped = Y_compressed(Rect(0, 0, orig_cols, orig_rows));
    Mat Cr_compressed_cropped = Cr_compressed(Rect(0, 0, orig_cols, orig_rows));
    Mat Cb_compressed_cropped = Cb_compressed(Rect(0, 0, orig_cols, orig_rows));

    // Merge channels
    Mat decompChannels[3] = { Y_compressed_cropped, Cr_compressed_cropped, Cb_compressed_cropped };
    Mat img_compressed;
    merge(decompChannels, 3, img_compressed);

    // Convert to BGR
    Mat final_image = img_compressed(Rect(0, 0, orig_cols, orig_rows));

    Mat img_compressed_rgb;
    cvtColor(final_image, img_compressed_rgb, COLOR_YCrCb2BGR);

    // Compute difference image
    //Mat differenceImage;
    //absdiff(ycrcbImg, img_compressed, differenceImage);

    // Save images
    string compPath = "Image_Decompressed_Serial.bmp";
    string compOriPath = "Image_Decompressed_Serial" + extension;

    //string diffPath = "Difference_Image_Serial.png";
    if (!imwrite(compPath, img_compressed_rgb)) {
        cerr << "[ERROR] Failed to save decompressed image at " << compPath << endl;
    }
    else {
        //int out = rename(compPath.c_str(), compOriPath.c_str());
        // cout << "[INFO] Decompressed image from bin saved to: " << compPath << endl;
    }
    //resize(img_compressed_rgb, img_compressed_rgb, img.size());

    if (!imwrite(compOriPath, img_compressed_rgb)) {
        cerr << "[ERROR] Failed to save image at " << compOriPath << endl;
    }
    else {
        cout << "[INFO] Decompressed image saved to: " << compOriPath << endl;
    }

    // Compute PSNR
    Mat img_channels[3];
    split(img, img_channels);
    Mat B = img_channels[0]; // BGR order
    Mat G = img_channels[1];
    Mat R = img_channels[2];

    Mat img_channels_compress[3];
    split(img_compressed_rgb, img_channels_compress);
    Mat B_compress = img_channels_compress[0];
    Mat G_compress = img_channels_compress[1];
    Mat R_compress = img_channels_compress[2];

    double PSNR_R = PSNR(R, R_compress);
    double PSNR_G = PSNR(G, G_compress);
    double PSNR_B = PSNR(B, B_compress);
    cout << "\n============= Quality of Compression ====================\n";
    cout << "[INFO] PSNR_R: " << PSNR_R << " dB\n";
    cout << "[INFO] PSNR_G: " << PSNR_G << " dB\n";
    cout << "[INFO] PSNR_B: " << PSNR_B << " dB\n";

    // Calculate compression rates
    //size_t original_size = orig_rows * orig_cols * 3; // Original RGB
    size_t original_size = getFileSize(inputPath);
    size_t de_size = getFileSize(compPath);
    size_t memory_size = getImageMemorySize(inputPath);
    size_t dememory_size = getImageMemorySize(compPath);
    double compression_rate = static_cast<double>(original_size) / compressed_size;
    cout << "\n==================== Summary of Comparison ====================\n";
    cout << "[INFO] Original Size: " << original_size << " bytes\n";
    cout << "[INFO] Used memory to display: " << memory_size << " bytes\n";
    cout << "[INFO] Decompressed Size: " << de_size << " bytes\n";
    cout << "[INFO] Used memory to display: " << dememory_size << " bytes\n";
    cout << "[INFO] Compressed Size: " << compressed_size << " bytes\n";
    cout << "[INFO] Compression Rate: " << compression_rate << ":1\n";
   

    reportImageSizes(img, img_compressed_rgb, "compress.bin", threshPath);

    // Clean up
    delete[] Y_blockArr;
    delete[] Cr_blockArr;
    delete[] Cb_blockArr;
    delete[] Y_blockArr_temp;
    delete[] Cr_blockArr_temp;
    delete[] Cb_blockArr_temp;

    return 0;
}

void getmat(Mat mat, xformBlock* blockarr)
{
    int blockidx = 0;
    Mat im_roi = Mat(8, 8, CV_8UC1, 0.0);

    for (int currRow = 0; currRow < mat.rows; currRow += 8)
    {
        for (int currCol = 0; currCol < mat.cols; currCol += 8)
        {
            Rect roi(currCol, currRow, 8, 8);

            block2mat(&im_roi, &blockarr[blockidx]);

            im_roi.copyTo(mat(roi));

            blockidx++;
        }
    }
}

void getblockarray(Mat mat, xformBlock* blockarr)
{
    int blockidx = 0;
    Mat im_roi = Mat(8, 8, CV_8UC1, 0.0);

    for (int currRow = 0; currRow < mat.rows; currRow += 8)
    {
        for (int currCol = 0; currCol < mat.cols; currCol += 8)
        {
            //rect function is col,row
            Rect roi(currCol, currRow, 8, 8);

            im_roi = mat(roi).clone();

            mat2block(&im_roi, &blockarr[blockidx]);

            blockidx++;
        }
    }
}

void mat2block(Mat* mat, xformBlock* block)
{
    for (int currRow = 0; currRow < 8; currRow++)
    {
        for (int currCol = 0; currCol < 8; currCol++)
        {
            block->data[currRow][currCol] = mat->at<uchar>(currRow, currCol);
        }
    }
}

void block2mat(Mat* mat, xformBlock* block)
{
    for (int currRow = 0; currRow < 8; currRow++)
    {
        for (int currCol = 0; currCol < 8; currCol++)
        {
            uchar temp;
            if (block->data[currRow][currCol].real() > 255.0)
            {
                temp = 255;
            }
            else if (block->data[currRow][currCol].real() < 0.0)
            {
                temp = 0;
            }
            else
            {
                temp = round(block->data[currRow][currCol].real());
            }
            mat->at<uchar>(currRow, currCol) = temp;
        }
    }
}

void block2bitstream(xformBlock* block, uint8* arr)
{
    memcpy(arr, &block->row_index, sizeof(int));
    memcpy(&arr[5], &block->col_index, sizeof(int));

    int arridx = 9;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            uint8 temp_real;
            uint8 temp_imag = (uint8_t)block->data[i][j].imag();
            if (block->data[i][j].real() > 255.0)
            {
                temp_real = 255;
            }
            else if (block->data[i][j].real() < 0.0)
            {
                temp_real = 0;
            }
            else
            {
                temp_real = (uint8_t)block->data[i][j].real();
            }

            memcpy(&arr[arridx], &temp_real, sizeof(uint8_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(uint8_t));
            arridx += 2;
        }
    }
}

void bitstream2block(xformBlock* block, uint8* arr)
{
    block->row_index = arr[0] | (arr[1] << 8) | (arr[2] << 16) | (arr[3] << 24);
    block->col_index = arr[5] | (arr[6] << 8) | (arr[7] << 16) | (arr[8] << 24);
    //cout<<block->row_index << " "<< block->col_index<<endl;

    int arridx = 9;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }

}

void block2bitstream16(xformBlock* block, int16_t* arr)
{

    int arridx = 5;

    //copy data plus convert to uchar
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            int16_t temp_real = (int16_t)block->data[i][j].real();
            int16_t temp_imag = (int16_t)block->data[i][j].imag();
            memcpy(&arr[arridx], &temp_real, sizeof(int16_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(int16_t));
            arridx += 2;
        }
    }
}

void bitstream2block16(xformBlock* block, int16_t* arr)
{
    int arridx = 5;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }

}

double PSNR(Mat PreImg, Mat PostImg)
{
    double MSE = 0.0;
    double PSNR = 0.0;
    double temp = 0.0;
    for (int currRow = 0; currRow < PreImg.rows; currRow++)
    {
        for (int currCol = 0; currCol < PreImg.cols; currCol++)
        {
            temp = (int)PreImg.at<uchar>(currRow, currCol) - (int)PostImg.at<uchar>(currRow, currCol);
            MSE += pow(temp, 2);
        }
    }
    MSE = MSE / ((int)PreImg.rows * (int)PostImg.cols);
    PSNR = 10 * log10(pow(255, 2) / MSE);
    return PSNR;
}

void applyThreshold(xformBlock* block, double thresholdPercent) {
    // Collect magnitudes
    vector<pair<double, pair<int, int>>> magnitudes;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            double mag = abs(block->data[i][j]);
            magnitudes.push_back({ mag, {i, j} });
        }
    }

    // Sort descending
    sort(magnitudes.rbegin(), magnitudes.rend());

    // Calculate cutoff index
    int keep_count = static_cast<int>(64 * thresholdPercent);
    if (keep_count < 1) keep_count = 1; // Keep at least one coefficient

    // Zero out coefficients below threshold
    for (int idx = keep_count; idx < 64; idx++) {
        int i = magnitudes[idx].second.first;
        int j = magnitudes[idx].second.second;
        block->data[i][j] = complex<double>(0, 0);
    }
}

size_t getFileSize(const string& filename) {
    ifstream in(filename, ios::binary | ios::ate);
    if (!in) return 0;
    size_t size = in.tellg();
    in.close();
    return size;
}

size_t getImageMemorySize(const string& filename) {
    Mat img = imread(filename, IMREAD_UNCHANGED);
    if (img.empty()) {
        cerr << "Failed to load image: " << filename << endl;
        return 0;
    }
    return img.total() * img.elemSize();
}

///* Compression computation for all bands */
//void* compress(void* args)
//{
//    thread_args* t_args = (thread_args*)args;
//    for (int i = t_args->Y_blockstart; i < t_args->Y_blockend; i++)
//    {
//        FFT_8x8(&t_args->Y_blockarr[i]);
//        QuantizeLuminance(&t_args->Y_blockarr[i]);
//
//        block2bitstream16(&t_args->Y_blockarr[i], &t_args->Y_bitstream16[i * 136]);
//
//    }
//
//
//    for (int i = t_args->C_blockstart; i < t_args->C_blockend; i++)
//    {
//        FFT_8x8(&t_args->Cb_blockarr[i]);
//        QuantizeChrominance(&t_args->Cb_blockarr[i]);
//
//        FFT_8x8(&t_args->Cr_blockarr[i]);
//        QuantizeChrominance(&t_args->Cr_blockarr[i]);
//
//        block2bitstream16(&t_args->Cb_blockarr[i], &t_args->Cb_bitstream16[i * 136]);
//        block2bitstream16(&t_args->Cr_blockarr[i], &t_args->Cr_bitstream16[i * 136]);
//    }
//}
//
///* Decompression computation for all bands */
//void* decompress(void* args)
//{
//    thread_args* t_args = (thread_args*)args;
//    for (int i = t_args->Y_blockstart; i < t_args->Y_blockend; i++)
//    {
//        bitstream2block16(&t_args->Y_blockarr[i], &t_args->Y_bitstream16[i * 136]);
//
//
//        InvQuantizeLuminance(&t_args->Y_blockarr[i]);
//        IFFT_8x8(&t_args->Y_blockarr[i]);
//    }
//
//    for (int i = t_args->C_blockstart; i < t_args->C_blockend; i++)
//    {
//        bitstream2block16(&t_args->Cb_blockarr[i], &t_args->Cb_bitstream16[i * 136]);
//        bitstream2block16(&t_args->Cr_blockarr[i], &t_args->Cr_bitstream16[i * 136]);
//
//        InvQuantizeChrominance(&t_args->Cb_blockarr[i]);
//        IFFT_8x8(&t_args->Cb_blockarr[i]);
//
//        InvQuantizeChrominance(&t_args->Cr_blockarr[i]);
//        IFFT_8x8(&t_args->Cr_blockarr[i]);
//    }
//}



void reportImageSizes(
    const cv::Mat& original,
    const cv::Mat& decompressed,
    const std::string& compressedBinPath,
    const std::string& jpegPath
) {
    size_t original_memory = original.total() * original.elemSize();
    size_t decompressed_memory = decompressed.total() * decompressed.elemSize();
    size_t compressed_bin_size = getFileSize(compressedBinPath);
    size_t jpeg_file_size = getFileSize(jpegPath);

    std::cout << "\n============= Memory Size Report =========================\n";
    std::cout << std::fixed << std::setprecision(2);

    std::cout << "[INFO] Original Image (RAM):       " << original_memory << " bytes (" << original_memory / 1024.0 << " KB)\n";
    std::cout << "[INFO] Decompressed Image (RAM):   " << decompressed_memory << " bytes (" << decompressed_memory / 1024.0 << " KB)\n";
    std::cout << "[INFO] Compressed File (BIN):      " << compressed_bin_size << " bytes (" << compressed_bin_size / 1024.0 << " KB)\n";
    std::cout << "[INFO] Compressed JPEG (imwrite):  " << jpeg_file_size << " bytes (" << jpeg_file_size / 1024.0 << " KB)\n";

    double compression_rate = (double)original_memory / compressed_bin_size;
    double compression_percent = (1.0 - (double)compressed_bin_size / original_memory) * 100.0;

    std::cout << "[INFO] Compression Rate (RAM : BIN) = " << compression_rate << " : 1\n";
    std::cout << "[INFO] Space Saved (vs RAM) = " << compression_percent << " %\n";

    double jpeg_percent = (1.0 - (double)jpeg_file_size / original_memory) * 100.0;
    std::cout << "[INFO] JPEG Space Saved (vs RAM) = " << jpeg_percent << " %\n";
}

