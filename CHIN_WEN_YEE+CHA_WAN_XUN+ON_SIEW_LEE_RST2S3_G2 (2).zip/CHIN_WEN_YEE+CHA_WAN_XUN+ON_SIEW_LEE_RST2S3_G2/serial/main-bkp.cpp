﻿#include <iostream>
#include <bitset>
#include <fstream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <chrono>
#include <thread>
#include <filesystem>
#include <vector>

#include "FFT.hpp"  // Assuming this contains FFT_8x8 and IFFT_8x8
#include "Huffman.hpp"

using namespace std;
using namespace cv;
namespace fs = std::filesystem;

void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void createDirectory(const string& path);
void applyThreshold(xformBlock* block, double threshold);
double calculateCompressionRatio(size_t originalSize, size_t compressedSize);
double computePSNR(const cv::Mat& I1, const cv::Mat& I2);
double computeSSIM(const cv::Mat& img1, const cv::Mat& img2);
//void compressImageToBinary(const Mat& img, const string& outputPath);
//void decompressImageFromBinary(const string& inputPath, const string& outputJpgPath);
void saveCompressedBitStringToFile(const std::string& bitString, const std::string& filePath);
string loadCompressedBitStringFromFile(const std::string& filePath);

const double THRESHOLD_PERCENTAGE = 0.1;

int main(int argc, const char** argv) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <image_path>\n";
        return 1;
    }

    string inputPath = argv[1];

    double thresholdPercentage = THRESHOLD_PERCENTAGE;

    // Parse threshold percentage if provided
    if (argc >= 3) {
        try {
            thresholdPercentage = stod(argv[2]);
        } catch (exception& e) {
            cerr << "[ERROR] Invalid threshold percentage: " << argv[2] << endl;
            return 1;
        }
    }

    string outputDir = "./images/";
    createDirectory(outputDir);

    cout << "[INFO] Loading image: " << inputPath << endl;
    Mat img = imread(inputPath);
    if (img.empty()) {
        cerr << "[ERROR] Could not open image file: " << inputPath << endl;
        return 1;
    }

    cout << "[INFO] Using threshold percentage: " << thresholdPercentage << endl;

    auto start = chrono::high_resolution_clock::now();

    // Convert to YCrCb color space
    Mat ycrcbImg;
    cvtColor(img, ycrcbImg, COLOR_BGR2YCrCb);
    
    // Split into channels
    vector<Mat> channels;
    split(ycrcbImg, channels);
    Mat Y = channels[0], Cr = channels[1], Cb = channels[2];

    int numRows = Y.rows, numCols = Y.cols;
    int numBlocks = (numRows / 8) * (numCols / 8);
    cout << "[INFO] Image size: " << numCols << "x" << numRows << ", Processing " << numBlocks << " blocks.\n";

    // Process Y channel (luminance)
    xformBlock* blockArr = new xformBlock[numBlocks];
    int blockidx = 0;

    // Forward FFT and apply threshold
    for (int currRow = 0; currRow < numRows; currRow += 8) {
        for (int currCol = 0; currCol < numCols; currCol += 8) {
            Rect roi(currCol, currRow, 8, 8);
            Mat im_roi = Y(roi).clone();
            mat2block(&im_roi, &blockArr[blockidx]);
            FFT_8x8(&blockArr[blockidx]);
            applyThreshold(&blockArr[blockidx], thresholdPercentage);
            blockidx++;
        }
    }

    // Reconstruct Y channel
    Mat compressedY = Mat::zeros(numRows, numCols, CV_8UC1);
    blockidx = 0;
    for (int currRow = 0; currRow < numRows; currRow += 8) {
        for (int currCol = 0; currCol < numCols; currCol += 8) {
            Rect roi(currCol, currRow, 8, 8);
            Mat im_roi = Y(roi).clone();
            IFFT_8x8(&blockArr[blockidx]);
            block2mat(&im_roi, &blockArr[blockidx]);
            im_roi.copyTo(compressedY(roi));
            blockidx++;
        }
    }
    
    // 4:2:2
    resize(Cr, Cr, Size(numCols, numRows), 0, 0, INTER_LINEAR);
    resize(Cb, Cb, Size(numCols, numRows), 0, 0, INTER_LINEAR);

    // Merge channels back
    vector<Mat> compressedChannels = {compressedY, Cr, Cb};
    Mat compressedYCbCr;
    merge(compressedChannels, compressedYCbCr);
    
    // Convert back to BGR
    Mat compressedImg;
    cvtColor(compressedYCbCr, compressedImg, COLOR_YCrCb2BGR);

    // Save compressed image
    vector<int> compression_params;
    compression_params.push_back(IMWRITE_JPEG_QUALITY);
    compression_params.push_back(80);  // JPEG quality (0-100)
    
    string outputPath = outputDir + "compressed.jpg";
    imwrite(outputPath, compressedImg, compression_params);


    size_t originalSize = fs::file_size(inputPath);
    size_t compressedSize = fs::file_size(outputPath);
    double ratio = calculateCompressionRatio(originalSize, compressedSize);

    // compress
    Mat huffman_compress_image = imread(outputPath, IMREAD_GRAYSCALE);

    int originalRows = huffman_compress_image.rows;
    int originalCols = huffman_compress_image.cols;
    int originalType = huffman_compress_image.type();

    Huffman huff;
    string binOutputPath = outputDir + "compressed.bin";
    string compressedBitString = huff.compress(huffman_compress_image);
    cout << "Compressed bits: " << compressedBitString.size() << " bits" << std::endl;
    saveCompressedBitStringToFile(compressedBitString, binOutputPath);

    // 读取 + 解压
    string loadedBitString = loadCompressedBitStringFromFile(binOutputPath);
    string binDeOutputPath = outputDir + "decompressed.jpg";

    // Decompress the Y channel
    cv::Mat decompressedImage = huff.decompress(loadedBitString, originalRows, originalCols, originalType);
    std::cout << "[DEBUG] Type: " << decompressedImage.type() << std::endl;

    // Reintegrate the Cr and Cb channels
    resize(Cr, Cr, Size(originalCols, originalRows), 0, 0, INTER_LINEAR);
    resize(Cb, Cb, Size(originalCols, originalRows), 0, 0, INTER_LINEAR);

    // Merge channels back together (Y, Cr, Cb)
    vector<Mat> decompressedChannels = { decompressedImage, Cr, Cb };
    Mat decompressedYCbCr;
    merge(decompressedChannels, decompressedYCbCr);

    // Convert back to BGR
    Mat finalDecompressedImg;
    cvtColor(decompressedYCbCr, finalDecompressedImg, COLOR_YCrCb2BGR);

    // Save the final decompressed image with color
    if (!imwrite(binDeOutputPath, finalDecompressedImg)) {
        cerr << "[ERROR] Failed to save decompressed image at " << binDeOutputPath << endl;
        return -1;
    }

    cout << "[INFO] Decompressed image saved to: " << binDeOutputPath << endl;

    //// 保存为Huffman压缩的二进制文件
    //string binOutputPath = outputDir + "compressed.bin";
    //compressImageToBinary(compressedImg, binOutputPath);

    //decompressImageFromBinary(binOutputPath, binDeOutputPath);

    Mat originalImg = imread(inputPath);
    Mat decompressedImg = imread(binDeOutputPath);

    bool evaluateQuality = !originalImg.empty();
    double psnr = 0.0;
    double ssim = 0.0;

    if (evaluateQuality) {
        cout << "caculating ... similarity" << endl;
        Mat resizedOriginal = originalImg;
        if (originalImg.size() != decompressedImg.size()) {
            resize(originalImg, resizedOriginal, decompressedImg.size());
        }

        psnr = computePSNR(resizedOriginal, decompressedImg);
        ssim = computeSSIM(resizedOriginal, decompressedImg);
    }

    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end - start;
    cout << "[INFO] Execution time: " << elapsed.count() << " seconds.\n";
    cout << "[INFO] Compressed image saved to: " << outputPath << endl;
    cout << "[INFO] Compressed bin saved to: " << binOutputPath << endl;
    cout << "[INFO] Decompressed image saved to: " << binDeOutputPath << endl;
    cout << "[INFO] Original image size: " << fs::file_size(inputPath) << " bytes\n";
    cout << "[INFO] Compressed image size: " << fs::file_size(outputPath) << " bytes\n";
    cout << "[INFO] Compression ratio: " << ratio << ":1\n";
    cout << "[INFO] PSNR: " << psnr << " dB" << endl;
    cout << "[INFO] SSIM: " << ssim << endl;

    delete[] blockArr;
    return 0;
}

void saveCompressedBitStringToFile(const std::string& bitString, const std::string& filePath) {
    std::ofstream out(filePath, std::ios::binary);
    if (!out) {
        std::cerr << "Failed to open file for writing: " << filePath << std::endl;
        return;
    }

    // 将 bitstring 每 8 位转换成 byte 写入
    for (size_t i = 0; i < bitString.length(); i += 8) {
        std::string byteStr = bitString.substr(i, 8);
        if (byteStr.length() < 8) {
            byteStr.append(8 - byteStr.length(), '0'); // 补 0
        }
        std::bitset<8> bits(byteStr);
        unsigned char byte = static_cast<unsigned char>(bits.to_ulong());
        out.write(reinterpret_cast<char*>(&byte), sizeof(byte));
    }

    out.close();
}

std::string loadCompressedBitStringFromFile(const std::string& filePath) {
    std::ifstream in(filePath, std::ios::binary);
    if (!in) {
        std::cerr << "Failed to open file for reading: " << filePath << std::endl;
        return "";
    }

    std::string bitString;
    char byte;
    while (in.read(&byte, 1)) {
        std::bitset<8> bits(static_cast<unsigned char>(byte));
        bitString += bits.to_string();
    }

    in.close();
    return bitString;
}


double computePSNR(const cv::Mat& I1, const cv::Mat& I2) {
    cv::Mat s1;
    absdiff(I1, I2, s1);       // |I1 - I2|
    s1.convertTo(s1, CV_32F);  // make sure values are float
    s1 = s1.mul(s1);           // square it

    Scalar s = sum(s1);        // sum elements per channel

    double sse = s[0] + s[1] + s[2]; // for 3 channels
    if (sse <= 1e-10) return INFINITY; // avoid log(0)

    double mse = sse / (double)(I1.channels() * I1.total());
    double psnr = 10.0 * log10((255 * 255) / mse);
    return psnr;
}

double computeSSIM(const cv::Mat& img1, const cv::Mat& img2) {
    const double C1 = 6.5025, C2 = 58.5225;

    int d = CV_32F;

    cv::Mat I1, I2;
    img1.convertTo(I1, d);
    img2.convertTo(I2, d);

    cv::Mat I1_2 = I1.mul(I1);        // I1^2
    cv::Mat I2_2 = I2.mul(I2);        // I2^2
    cv::Mat I1_I2 = I1.mul(I2);       // I1 * I2

    cv::Mat mu1, mu2;                 // PRELIMINARY COMPUTING
    cv::GaussianBlur(I1, mu1, Size(11, 11), 1.5);
    cv::GaussianBlur(I2, mu2, Size(11, 11), 1.5);

    cv::Mat mu1_2 = mu1.mul(mu1);
    cv::Mat mu2_2 = mu2.mul(mu2);
    cv::Mat mu1_mu2 = mu1.mul(mu2);

    cv::Mat sigma1_2, sigma2_2, sigma12;

    cv::GaussianBlur(I1_2, sigma1_2, Size(11, 11), 1.5);
    sigma1_2 -= mu1_2;

    cv::GaussianBlur(I2_2, sigma2_2, Size(11, 11), 1.5);
    sigma2_2 -= mu2_2;

    cv::GaussianBlur(I1_I2, sigma12, Size(11, 11), 1.5);
    sigma12 -= mu1_mu2;

    cv::Mat t1, t2, t3;

    t1 = 2 * mu1_mu2 + C1;
    t2 = 2 * sigma12 + C2;
    t3 = t1.mul(t2);                // t3 = ((2*mu1_mu2 + C1).*(2*sigma12 + C2))

    t1 = mu1_2 + mu2_2 + C1;
    t2 = sigma1_2 + sigma2_2 + C2;
    t1 = t1.mul(t2);                // t1 = ((mu1_2 + mu2_2 + C1).*(sigma1_2 + sigma2_2 + C2))

    cv::Mat ssim_map;
    divide(t3, t1, ssim_map);       // SSIM = t3 / t1

    Scalar mssim = mean(ssim_map);  // average over image

    return (mssim[0] + mssim[1] + mssim[2]) / 3;
}


void applyThreshold(xformBlock* block, double threshold) {
    // Calculate number of coefficients to keep
    int totalCoeffs = 8 * 8;
    int coeffsToKeep = static_cast<int>(totalCoeffs * threshold);
    
    // Flatten coefficients and sort by magnitude
    vector<pair<double, complex<double>*>> coeffs;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            double magnitude = abs(block->data[i][j]);
            coeffs.emplace_back(magnitude, &block->data[i][j]);
        }
    }
    
    // Sort by magnitude in descending order
    sort(coeffs.begin(), coeffs.end(), 
        [](const auto& a, const auto& b) { return a.first > b.first; });
    
    // Zero out small coefficients
    for (int k = coeffsToKeep; k < totalCoeffs; k++) {
        *(coeffs[k].second) = 0;
    }
}

void mat2block(Mat* mat, xformBlock* block) {
    for (int currRow = 0; currRow < 8; currRow++) {
        for (int currCol = 0; currCol < 8; currCol++) {
            block->data[currRow][currCol] = mat->at<uchar>(currRow, currCol);
        }
    }
}

void block2mat(Mat* mat, xformBlock* block) {
    for (int currRow = 0; currRow < 8; currRow++) {
        for (int currCol = 0; currCol < 8; currCol++) {
            mat->at<uchar>(currRow, currCol) = (uchar)block->data[currRow][currCol].real();
        }
    }
}

void createDirectory(const string& path) {
    if (!fs::exists(path)) {
        fs::create_directory(path);
        cout << "[INFO] Created output directory: " << path << endl;
    }
}

double calculateCompressionRatio(size_t originalSize, size_t compressedSize) {
    if (compressedSize == 0) return 0;
    return static_cast<double>(originalSize) / compressedSize;
}