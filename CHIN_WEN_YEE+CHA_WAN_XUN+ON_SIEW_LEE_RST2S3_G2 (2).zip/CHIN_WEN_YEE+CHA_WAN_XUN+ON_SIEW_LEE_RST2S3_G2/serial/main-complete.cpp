﻿
#include<iostream>
#include "FFT.hpp"
#include "ImageProcessing.hpp"
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

#include <stdint.h>
#include <string> 
#include <chrono>

using namespace std;
using namespace cv;


typedef struct thread_args {
    int rank;
    int Y_blockstart;
    int Y_blockend;
    int C_blockstart;
    int C_blockend;
    xformBlock* Y_blockarr;
    int16* Y_bitstream16;
    xformBlock* Cb_blockarr;
    int16* Cb_bitstream16;
    xformBlock* Cr_blockarr;
    int16* Cr_bitstream16;
} thread_args;



void mat2block(Mat* mat, xformBlock* block);
void block2mat(Mat* mat, xformBlock* block);
void getblockarray(Mat mat, xformBlock* blockarr);
void getmat(Mat mat, xformBlock* blockarr);

void block2bitstream(xformBlock* block, uint8* arr);
void bitstream2block(xformBlock* block, uint8* arr);

void block2bitstream16(xformBlock* block, int16_t* arr);
void bitstream2block16(xformBlock* block, int16_t* arr);

//void* compress(void* args);
//void* decompress(void* args);

double PSNR(Mat PreImg, Mat PostImg);
//void decompress(int blockstart, int blockend, block* blockarr, int16* bitstream16);
void applyThreshold(xformBlock* block, double thresholdPercent);

// Threshold percentage (adjustable)
//const double THRESHOLD_PERCENT = 50.0; // Keep top 50% of coefficients

int main(int argc, const char** argv) {
    if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <image_path> <threshold>\n";
        return 1;
    }

    string inputPath = argv[1];
    double THRESHOLD_PERCENT = stod(argv[2]);

    cout << "[INFO] Image to compress: " << inputPath << endl;
    cout << "[INFO] Threshold: Keeping top " << THRESHOLD_PERCENT << "% of coefficients\n";

    // Read image
    Mat img = imread(inputPath, IMREAD_COLOR);
    if (img.empty()) {
        cerr << "[ERROR] Could not open image file: " << inputPath << endl;
        return 1;
    }

    // Convert to YCrCb
    Mat ycrcbImg;
    cvtColor(img, ycrcbImg, COLOR_BGR2YCrCb); // BGR2YCrCb for OpenCV

    // Split channels
    Mat channels[3];
    split(ycrcbImg, channels);
    Mat Y = channels[0], Cr = channels[1], Cb = channels[2];

    // Calculate block counts
    int Y_numRows = ycrcbImg.rows;
    int Y_numCols = ycrcbImg.cols;
    int Y_numBlocks = (Y_numRows / 8) * (Y_numCols / 8);

    // 4:2:2 subsampling for Cr and Cb (half cols, full rows)
    Mat Cr_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(0));
    Mat Cb_422 = Mat(Y_numRows, Y_numCols / 2, CV_8UC1, Scalar(0));
    SubSample(Cr, Cr_422); // Assumes SubSample handles 4:2:2 (horizontal only)
    SubSample(Cb, Cb_422);

    // Pad Cr_422 and Cb_422 (only cols, rows match Y)
    Mat row_cr = Mat(1, Cr_422.cols, CV_8UC1, Scalar(128));
    Mat row_cb = Mat(1, Cr_422.cols, CV_8UC1, Scalar(128));
    row_cr.copyTo(Cr_422.row(Cr_422.rows - 1));
    row_cb.copyTo(Cb_422.row(Cr_422.rows - 1));

    int padding_cols = Cr_422.cols % 8;
    if (padding_cols != 0) {
        int new_cols = Cr_422.cols + (8 - padding_cols);
        Cr_422.resize(Cr_422.rows, new_cols);
        Cb_422.resize(Cb_422.rows, new_cols);
        for (int col = Cr_422.cols - padding_cols; col < new_cols; col++) {
            Cr_422.col(col).setTo(128);
            Cb_422.col(col).setTo(128);
        }
    }

    int C_numRows = Cr_422.rows;
    int C_numCols = Cr_422.cols;
    int C_numBlocks = (C_numRows / 8) * (C_numCols / 8);

    cout << "[INFO] Y size: " << Y_numCols << "x" << Y_numRows << ", Processing " << Y_numBlocks << " blocks.\n";
    cout << "[INFO] C size: " << C_numCols << "x" << C_numRows << ", Processing " << C_numBlocks << " blocks.\n";

    // Allocate block arrays
    xformBlock* Y_blockArr = new xformBlock[Y_numBlocks];
    xformBlock* Cr_blockArr = new xformBlock[C_numBlocks];
    xformBlock* Cb_blockArr = new xformBlock[C_numBlocks];

    // Allocate bitstream buffers
    int16_t* Y_bitstream16 = new int16_t[Y_numBlocks * 272];
    int16_t* Cr_bitstream16 = new int16_t[C_numBlocks * 272];
    int16_t* Cb_bitstream16 = new int16_t[C_numBlocks * 272];

    // Allocate temporary block arrays for thresholding
    xformBlock* Y_blockArr_temp = new xformBlock[Y_numBlocks];
    xformBlock* Cr_blockArr_temp = new xformBlock[C_numBlocks];
    xformBlock* Cb_blockArr_temp = new xformBlock[C_numBlocks];

    // Populate block arrays
    getblockarray(Y, Y_blockArr);
    getblockarray(Cr_422, Cr_blockArr);
    getblockarray(Cb_422, Cb_blockArr);

    // Copy to temp arrays for thresholding
    memcpy(Y_blockArr_temp, Y_blockArr, Y_numBlocks * sizeof(xformBlock));
    memcpy(Cr_blockArr_temp, Cr_blockArr, C_numBlocks * sizeof(xformBlock));
    memcpy(Cb_blockArr_temp, Cb_blockArr, C_numBlocks * sizeof(xformBlock));

    // Compression
    cout << "[INFO] Starting compression...\n";
    auto start = chrono::high_resolution_clock::now();

    // Compress Y channel
    for (int i = 0; i < Y_numBlocks; i++) {
        FFT_8x8(&Y_blockArr[i]);
        applyThreshold(&Y_blockArr[i], THRESHOLD_PERCENT);
        QuantizeLuminance(&Y_blockArr[i]);
        block2bitstream16(&Y_blockArr[i], &Y_bitstream16[i * 136]);
    }

    // Compress Cr and Cb channels
    for (int i = 0; i < C_numBlocks; i++) {
        FFT_8x8(&Cr_blockArr[i]);
        applyThreshold(&Cr_blockArr[i], THRESHOLD_PERCENT);
        QuantizeChrominance(&Cr_blockArr[i]);
        block2bitstream16(&Cr_blockArr[i], &Cr_bitstream16[i * 136]);

        FFT_8x8(&Cb_blockArr[i]);
        applyThreshold(&Cb_blockArr[i], THRESHOLD_PERCENT);
        QuantizeChrominance(&Cb_blockArr[i]);
        block2bitstream16(&Cb_blockArr[i], &Cb_bitstream16[i * 136]);
    }

    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> compress_time = end - start;
    cout << "[INFO] Compression Time: " << compress_time.count() << " seconds\n";

    // Save thresholded image
    cout << "[INFO] Saving thresholded image...\n";
    for (int i = 0; i < Y_numBlocks; i++) {
        FFT_8x8(&Y_blockArr_temp[i]);
        applyThreshold(&Y_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Y_blockArr_temp[i]);
    }
    for (int i = 0; i < C_numBlocks; i++) {
        FFT_8x8(&Cr_blockArr_temp[i]);
        applyThreshold(&Cr_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Cr_blockArr_temp[i]);

        FFT_8x8(&Cb_blockArr_temp[i]);
        applyThreshold(&Cb_blockArr_temp[i], THRESHOLD_PERCENT);
        IFFT_8x8(&Cb_blockArr_temp[i]);
    }

    Mat Y_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cr_422_thresholded = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    Mat Cb_422_thresholded = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));

    getmat(Y_thresholded, Y_blockArr_temp);
    getmat(Cr_422_thresholded, Cr_blockArr_temp);
    getmat(Cb_422_thresholded, Cb_blockArr_temp);

    Mat Cr_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cb_thresholded = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    UpSample(Cr_422_thresholded, Cr_thresholded); // Upsample cols only
    UpSample(Cb_422_thresholded, Cb_thresholded);

    Mat threshChannels[3] = { Y_thresholded, Cr_thresholded, Cb_thresholded };
    Mat img_thresholded;
    merge(threshChannels, 3, img_thresholded);

    Mat img_thresholded_rgb;
    cvtColor(img_thresholded, img_thresholded_rgb, COLOR_YCrCb2BGR);

    string threshPath = "Thresholded_Image.png";
    if (!imwrite(threshPath, img_thresholded_rgb)) {
        cerr << "[ERROR] Failed to save thresholded image at " << threshPath << endl;
    }
    else {
        cout << "[INFO] Thresholded image saved to: " << threshPath << endl;
    }

    // Decompression
    cout << "[INFO] Starting decompression...\n";
    start = chrono::high_resolution_clock::now();

    // Decompress Y channel
    for (int i = 0; i < Y_numBlocks; i++) {
        bitstream2block16(&Y_blockArr[i], &Y_bitstream16[i * 136]);
        InvQuantizeLuminance(&Y_blockArr[i]);
        IFFT_8x8(&Y_blockArr[i]);
    }

    // Decompress Cr and Cb channels
    for (int i = 0; i < C_numBlocks; i++) {
        bitstream2block16(&Cr_blockArr[i], &Cr_bitstream16[i * 136]);
        InvQuantizeChrominance(&Cr_blockArr[i]);
        IFFT_8x8(&Cr_blockArr[i]);

        bitstream2block16(&Cb_blockArr[i], &Cb_bitstream16[i * 136]);
        InvQuantizeChrominance(&Cb_blockArr[i]);
        IFFT_8x8(&Cb_blockArr[i]);
    }

    end = chrono::high_resolution_clock::now();
    chrono::duration<double> decompress_time = end - start;
    cout << "[INFO] Decompression Time: " << decompress_time.count() << " seconds\n";

    // Reconstruct image
    Mat Y_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cr_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));
    Mat Cb_422_compressed = Mat(C_numRows, C_numCols, CV_8UC1, Scalar(0));

    getmat(Y_compressed, Y_blockArr);
    getmat(Cr_422_compressed, Cr_blockArr);
    getmat(Cb_422_compressed, Cb_blockArr);

    // Upsample Cr and Cb
    Mat Cr_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    Mat Cb_compressed = Mat(Y_numRows, Y_numCols, CV_8UC1, Scalar(0));
    UpSample(Cr_422_compressed, Cr_compressed);
    UpSample(Cb_422_compressed, Cb_compressed);

    // Merge channels
    Mat decompChannels[3] = { Y_compressed, Cr_compressed, Cb_compressed };
    Mat img_compressed;
    merge(decompChannels, 3, img_compressed);

    // Convert to BGR
    Mat img_compressed_rgb;
    cvtColor(img_compressed, img_compressed_rgb, COLOR_YCrCb2BGR);

    // Compute difference image
    Mat differenceImage;
    absdiff(ycrcbImg, img_compressed, differenceImage);

    // Save images
    string compPath = "Image_Compressed_Serial.png";
    string diffPath = "Difference_Image_Serial.png";
    if (!imwrite(compPath, img_compressed_rgb)) {
        cerr << "[ERROR] Failed to save compressed image at " << compPath << endl;
    }
    else {
        cout << "[INFO] Compressed image saved to: " << compPath << endl;
    }
    if (!imwrite(diffPath, differenceImage)) {
        cerr << "[ERROR] Failed to save difference image at " << diffPath << endl;
    }
    else {
        cout << "[INFO] Difference image saved to: " << diffPath << endl;
    }

    // Compute PSNR
    Mat img_channels[3];
    split(img, img_channels);
    Mat B = img_channels[0]; // BGR order
    Mat G = img_channels[1];
    Mat R = img_channels[2];

    Mat img_channels_compress[3];
    split(img_compressed_rgb, img_channels_compress);
    Mat B_compress = img_channels_compress[0];
    Mat G_compress = img_channels_compress[1];
    Mat R_compress = img_channels_compress[2];

    double PSNR_R = PSNR(R, R_compress);
    double PSNR_G = PSNR(G, G_compress);
    double PSNR_B = PSNR(B, B_compress);

    cout << "[INFO] PSNR_R: " << PSNR_R << " dB\n";
    cout << "[INFO] PSNR_G: " << PSNR_G << " dB\n";
    cout << "[INFO] PSNR_B: " << PSNR_B << " dB\n";

    // Calculate compression rate
    size_t original_size = Y_numRows * Y_numCols * 3; // RGB, 8 bits per channel
    size_t coeffs_per_block = 64; // 8x8
    double kept_coeffs = coeffs_per_block * (THRESHOLD_PERCENT);
    size_t compressed_size = (Y_numBlocks + 2 * C_numBlocks) * kept_coeffs * 4; // 4 bytes per coefficient
    double compression_rate = static_cast<double>(original_size) / compressed_size;

    cout << "[INFO] Original Size: " << original_size << " bytes\n";
    cout << "[INFO] Compressed Size (estimated): " << compressed_size << " bytes\n";
    cout << "[INFO] Compression Rate: " << compression_rate << ":1\n";

    // Clean up
    delete[] Y_blockArr;
    delete[] Cr_blockArr;
    delete[] Cb_blockArr;
    delete[] Y_bitstream16;
    delete[] Cr_bitstream16;
    delete[] Cb_bitstream16;
    delete[] Y_blockArr_temp;
    delete[] Cr_blockArr_temp;
    delete[] Cb_blockArr_temp;

    return 0;
}
/*******************************************************************
    getmat

    inputs:
        opencv mat object, pointer to block array
    outputs:
        modified mat to reflect block array data
    description:
        takes an array of xformBlock structs and copys them into the proper place in the opencv mat

*******************************************************************/
void getmat(Mat mat, xformBlock* blockarr)
{
    int blockidx = 0;
    Mat im_roi = Mat(8, 8, CV_8UC1, 0.0);

    for (int currRow = 0; currRow < mat.rows; currRow += 8)
    {
        for (int currCol = 0; currCol < mat.cols; currCol += 8)
        {
            Rect roi(currCol, currRow, 8, 8);

            block2mat(&im_roi, &blockarr[blockidx]);

            im_roi.copyTo(mat(roi));

            blockidx++;
        }
    }
}

/*******************************************************************
    getblockarray

    inputs:
        mat object with image data, empty xformblock array.
        mat dimensions must be divisible by 8 to work properly.
    outputs:
        xformblock array will be filled with image data and metadata
    description:
        Takes opencv mat object and converts it into a 1D array of
        xformblock objects, with associated metadata.

*******************************************************************/
void getblockarray(Mat mat, xformBlock* blockarr)
{
    int blockidx = 0;
    Mat im_roi = Mat(8, 8, CV_8UC1, 0.0);

    for (int currRow = 0; currRow < mat.rows; currRow += 8)
    {
        for (int currCol = 0; currCol < mat.cols; currCol += 8)
        {
            //rect function is col,row
            Rect roi(currCol, currRow, 8, 8);

            im_roi = mat(roi).clone();

            mat2block(&im_roi, &blockarr[blockidx]);

            blockidx++;
        }
    }
}

/* Helper function, copies the data of a single xformBlock struct into an opencv mat  */
void mat2block(Mat* mat, xformBlock* block)
{
    for (int currRow = 0; currRow < 8; currRow++)
    {
        for (int currCol = 0; currCol < 8; currCol++)
        {
            block->data[currRow][currCol] = mat->at<uchar>(currRow, currCol);
        }
    }
}

/* Helper function, copies the data of a single opencv mat struct into a xformBlock struct  */
void block2mat(Mat* mat, xformBlock* block)
{
    for (int currRow = 0; currRow < 8; currRow++)
    {
        for (int currCol = 0; currCol < 8; currCol++)
        {

            /* The math within openCV's color transformation functions will occasionally cause an overflow/underflow
                with imprecise numbers caused by our quantization. This math instead saturates potential errors */
            uchar temp;
            if (block->data[currRow][currCol].real() > 255.0)
            {
                temp = 255;
            }
            else if (block->data[currRow][currCol].real() < 0.0)
            {
                temp = 0;
            }
            else
            {
                temp = round(block->data[currRow][currCol].real());
            }
            mat->at<uchar>(currRow, currCol) = temp;
        }
    }
}

/*******************************************************************
    block2bitstream

    inputs:
        xformblock pointer with data, uint8 array pointer
    outputs:
        xformblock pointer with data, uint8 array pointer with data
    description:
        takes a xformblock struct and outputs a uint8 bitstream

*******************************************************************/
void block2bitstream(xformBlock* block, uint8* arr)
{
    memcpy(arr, &block->row_index, sizeof(int));
    memcpy(&arr[5], &block->col_index, sizeof(int));

    int arridx = 9;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            /* The math within openCV's color transformation functions will occasionally cause an overflow/underflow
                    with imprecise numbers caused by our quantization. This math instead saturates potential errors */
            uint8 temp_real;
            uint8 temp_imag = (uint8_t)block->data[i][j].imag();
            if (block->data[i][j].real() > 255.0)
            {
                temp_real = 255;
            }
            else if (block->data[i][j].real() < 0.0)
            {
                temp_real = 0;
            }
            else
            {
                temp_real = (uint8_t)block->data[i][j].real();
            }

            memcpy(&arr[arridx], &temp_real, sizeof(uint8_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(uint8_t));
            arridx += 2;
        }
    }
}


/*******************************************************************
    bitstream2block

    inputs:
        xformblock pointer, uint8 array pointer with data
    outputs:
        xformblock pointer with data, uint8 array pointer with data
    description:
        takes a stream of uint8s and transforms it into an xformblock

*******************************************************************/
void bitstream2block(xformBlock* block, uint8* arr)
{
    block->row_index = arr[0] | (arr[1] << 8) | (arr[2] << 16) | (arr[3] << 24);
    block->col_index = arr[5] | (arr[6] << 8) | (arr[7] << 16) | (arr[8] << 24);
    //cout<<block->row_index << " "<< block->col_index<<endl;

    int arridx = 9;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }

}

/*******************************************************************
    block2bitstream16

    inputs:
        xformblock pointer with data, uint16 array pointer
    outputs:
        xformblock pointer with data, uint16 array pointer with data
    description:
        takes a xformblock struct and outputs a uint16 bitstream

*******************************************************************/
void block2bitstream16(xformBlock* block, int16_t* arr)
{
    //memcpy(arr,&block->row_index,sizeof(int));
    //memcpy(&arr[5],&block->col_index,sizeof(int));

    int arridx = 5;

    //copy data plus convert to uchar
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            int16_t temp_real = (int16_t)block->data[i][j].real();
            int16_t temp_imag = (int16_t)block->data[i][j].imag();
            memcpy(&arr[arridx], &temp_real, sizeof(int16_t));
            memcpy(&arr[arridx + 1], &temp_imag, sizeof(int16_t));
            arridx += 2;
        }
    }
}

/*******************************************************************
    bitstream2block16

    inputs:
        xformblock pointer, uint16 array pointer with data
    outputs:
        xformblock pointer with data, uint16 array pointer with data
    description:
        takes a stream of uint16s and transforms it into an xformblock

*******************************************************************/
void bitstream2block16(xformBlock* block, int16_t* arr)
{
    //block->row_index = arr[0] | (arr[1] << 8) | (arr[2] << 16) | (arr[3] << 24);
    //block->col_index = arr[5] | (arr[6] << 8) | (arr[7] << 16) | (arr[8] << 24);
    //cout<<block->row_index << " "<< block->col_index<<endl;

    int arridx = 5;

    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            block->data[i][j].real(arr[arridx]);
            block->data[i][j].imag(arr[arridx + 1]);
            arridx += 2;
        }
    }

}

/*******************************************************************
    PSNR

    inputs:
        2D mat object holding a single color band
        another 2D mat object holding a single color band to be eveluated against
    outputs:
        double that is the result of the Peak-Signal to Noise Ratio of the two mats
    description:
        calculates Peak-Signal to Noise Ratio

*******************************************************************/
double PSNR(Mat PreImg, Mat PostImg)
{
    double MSE = 0.0;
    double PSNR = 0.0;
    double temp = 0.0;
    for (int currRow = 0; currRow < PreImg.rows; currRow++)
    {
        for (int currCol = 0; currCol < PreImg.cols; currCol++)
        {
            temp = (int)PreImg.at<uchar>(currRow, currCol) - (int)PostImg.at<uchar>(currRow, currCol);
            MSE += pow(temp, 2);
        }
    }
    MSE = MSE / ((int)PreImg.rows * (int)PostImg.cols);
    PSNR = 10 * log10(pow(255, 2) / MSE);
    return PSNR;
}

void applyThreshold(xformBlock* block, double thresholdPercent) {
    // Collect magnitudes
    vector<pair<double, pair<int, int>>> magnitudes;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            double mag = abs(block->data[i][j]);
            magnitudes.push_back({ mag, {i, j} });
        }
    }

    // Sort descending
    sort(magnitudes.rbegin(), magnitudes.rend());

    // Calculate cutoff index
    int keep_count = static_cast<int>(64 * thresholdPercent);
    if (keep_count < 1) keep_count = 1; // Keep at least one coefficient

    // Zero out coefficients below threshold
    for (int idx = keep_count; idx < 64; idx++) {
        int i = magnitudes[idx].second.first;
        int j = magnitudes[idx].second.second;
        block->data[i][j] = complex<double>(0, 0);
    }
}

///* Compression computation for all bands */
//void* compress(void* args)
//{
//    thread_args* t_args = (thread_args*)args;
//    for (int i = t_args->Y_blockstart; i < t_args->Y_blockend; i++)
//    {
//        FFT_8x8(&t_args->Y_blockarr[i]);
//        QuantizeLuminance(&t_args->Y_blockarr[i]);
//
//        block2bitstream16(&t_args->Y_blockarr[i], &t_args->Y_bitstream16[i * 136]);
//
//    }
//
//
//    for (int i = t_args->C_blockstart; i < t_args->C_blockend; i++)
//    {
//        FFT_8x8(&t_args->Cb_blockarr[i]);
//        QuantizeChrominance(&t_args->Cb_blockarr[i]);
//
//        FFT_8x8(&t_args->Cr_blockarr[i]);
//        QuantizeChrominance(&t_args->Cr_blockarr[i]);
//
//        block2bitstream16(&t_args->Cb_blockarr[i], &t_args->Cb_bitstream16[i * 136]);
//        block2bitstream16(&t_args->Cr_blockarr[i], &t_args->Cr_bitstream16[i * 136]);
//    }
//}
//
///* Decompression computation for all bands */
//void* decompress(void* args)
//{
//    thread_args* t_args = (thread_args*)args;
//    for (int i = t_args->Y_blockstart; i < t_args->Y_blockend; i++)
//    {
//        bitstream2block16(&t_args->Y_blockarr[i], &t_args->Y_bitstream16[i * 136]);
//
//
//        InvQuantizeLuminance(&t_args->Y_blockarr[i]);
//        IFFT_8x8(&t_args->Y_blockarr[i]);
//    }
//
//    for (int i = t_args->C_blockstart; i < t_args->C_blockend; i++)
//    {
//        bitstream2block16(&t_args->Cb_blockarr[i], &t_args->Cb_bitstream16[i * 136]);
//        bitstream2block16(&t_args->Cr_blockarr[i], &t_args->Cr_bitstream16[i * 136]);
//
//        InvQuantizeChrominance(&t_args->Cb_blockarr[i]);
//        IFFT_8x8(&t_args->Cb_blockarr[i]);
//
//        InvQuantizeChrominance(&t_args->Cr_blockarr[i]);
//        IFFT_8x8(&t_args->Cr_blockarr[i]);
//    }
//}