import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk
import subprocess
import re
import os
import csv
import shutil

# Variable to store threshold from slider
uploaded_file = None

def extract_metrics(output):
    return {
        "Image": re_search(r"Image to compress: (.+)", output),
        "Input File Size": re_search(r"Input File Size: (\d+) bytes", output),
        "Threshold": re_search(r"Threshold: Keeping top (.+)% of coefficients", output),
        "Y Size": re_search(r"Y size: (.+),", output),
        "C Size": re_search(r"C size: (.+),", output),
        "Compression Time": re_search(r"Compression Time: ([\d.]+) seconds", output),
        "Decompression Time": re_search(r"Decompression Time: ([\d.]+) seconds", output),
        "Original Image (RAM)": re_search(r"Original Image \(RAM\):\s+([\d]+ bytes)", output),
        "Compressed File (BIN)": re_search(r"Compressed File \(BIN\):\s+([\d]+ bytes)", output),
        "Compression Rate (RAM : BIN)": re_search(r"Compression Rate \(RAM : BIN\) = ([\d.]+ : [\d.]+)", output),
        "Space Saved (vs RAM)": re_search(r"Space Saved \(vs RAM\) = ([\d.]+)", output),
        "JPEG Space Saved (vs RAM)": re_search(r"JPEG Space Saved \(vs RAM\) = ([\d.]+)", output)
    }

def re_search(pattern, text):
    m = re.search(pattern, text)
    return m.group(1) if m else ""

def update_metrics_display(metrics):
    keys = ["Compression Time", "Compression Rate (RAM : BIN)", "Original Image (RAM)", "Compressed File (BIN)"]
    for k in keys:
        if k in metric_labels:
            metric_labels[k].config(text=f"{k}: {metrics.get(k, '')}")

def show_images(original_path):
    def load_image(path):
        try:
            img = Image.open(path)
            # img.thumbnail((256, 256))
            return ImageTk.PhotoImage(img)
        except:
            return None

    orig_img = load_image(original_path)
    comp_img = load_image("Compressed_Image.jpg")

    if orig_img:
        original_label.config(image=orig_img)
        original_label.image = orig_img
    decompressed_label.config(image="", text="")  # Clear old image
    if comp_img:
        decompressed_label.config(image=comp_img)
        decompressed_label.image = comp_img

def show_images(original_path):
    def load_image(path):
        try:
            img = Image.open(path)
            # img.thumbnail((256, 256))
            return img
        except:
            return None

    orig_img_obj = load_image(original_path)
    comp_img_obj = load_image("Compressed_Image.jpg")

    # 原圖顯示 + 尺寸
    if orig_img_obj:
        orig_img_tk = ImageTk.PhotoImage(orig_img_obj)
        original_label.config(image=orig_img_tk)
        original_label.image = orig_img_tk
        original_size_label.config(text=f"Size: {orig_img_obj.width} x {orig_img_obj.height}")
    else:
        original_label.config(image="", text="")
        original_label.image = None
        original_size_label.config(text="Size: ")

    # 解壓圖顯示 + 尺寸
    if comp_img_obj:
        comp_img_tk = ImageTk.PhotoImage(comp_img_obj)
        decompressed_label.config(image=comp_img_tk)
        decompressed_label.image = comp_img_tk
        decompressed_size_label.config(text=f"Size: {comp_img_obj.width} x {comp_img_obj.height}")
    else:
        decompressed_label.config(image="", text="")
        decompressed_label.image = None
        decompressed_size_label.config(text="Size: ")

def run_compression():
    if not uploaded_file:
        return

    filename = os.path.basename(uploaded_file)
    extension = os.path.splitext(filename)[1]
    mode = compression_mode.get()
    threshold = str(threshold_var.get())
    threshold_quant = str(threshold_quant_var.get())

    if mode == "Serial":
        cmd = ["serial_image_compression.exe", uploaded_file, threshold,threshold_quant]
    elif mode == "MPI":
        cmd = ["mpiexec", "-n", "4", "mpi_image_compression.exe", uploaded_file, threshold, threshold_quant]  
    elif mode == "OpenMP":
        cmd = ["openmp_image_compression.exe", uploaded_file, threshold, threshold_quant] 
    elif mode == "CUDA":
        cmd = ["./cuda_image_compression", uploaded_file, threshold, "c", threshold_quant]

    try:
        process = subprocess.run(cmd, capture_output=True, text=True)
        output = process.stdout
        log_text.delete("1.0", tk.END)
        log_text.insert(tk.END, output)

        metrics = extract_metrics(output)
        metrics["Mode"] = mode 
        update_metrics_display(metrics)

        if mode == "MPI":
            decompressed_prefix = "Image_Decompressed_MPI"
        elif mode == "CUDA":
            decompressed_prefix = "Image_Decompressed_CUDA"
        elif mode == "OpenMP":
            decompressed_prefix = "Image_Decompressed_OpenMP"
        else:
            decompressed_prefix = "Image_Decompressed_Serial"

        for f in os.listdir():
            if f.startswith(decompressed_prefix):
                shutil.copy(f, "Compressed_Image.jpg")
                break

        show_images(uploaded_file)
        write_to_csv(metrics)

    except Exception as e:
        log_text.insert(tk.END, f"[ERROR] {e}")

def write_to_csv(metrics):
    file_exists = os.path.exists("compression_results.csv")
    with open("compression_results.csv", "a", newline="") as csvfile:
        fieldnames = list(metrics.keys())
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(metrics)

def upload_image():
    global uploaded_file
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.jpeg *.png")])
    if file_path:
        uploaded_file = file_path
        show_images(file_path)
        decompressed_label.config(image="", text="")  # Clear old image
    else:
        original_size_label.config(text="Size: ")



# ===================== GUI =====================

root = tk.Tk()
root.title("Image Compression GUI")

threshold_var = tk.DoubleVar(value=0.5)
threshold_quant_var = tk.DoubleVar(value=0.5)

# Top buttons: Upload, Mode, Run
top_frame = tk.Frame(root)
top_frame.pack(pady=10)
style = ttk.Style()
style.configure("ModernBlue.TButton",
                foreground="white",
                background="#007BFF",  # 純藍色
                font=("Arial", 10, "bold"),
                borderwidth=0)
style.map("ModernBlue.TButton",
          background=[("active", "#007BFF"), ("pressed", "#007BFF")])


upload_btn = ttk.Button(top_frame, text="Upload Image", command=upload_image, style="ModernBlue.TButton")
upload_btn = tk.Button(top_frame, text="Upload Image", command=upload_image,
                       bg="#007BFF", fg="white", font=("Arial", 10, "bold"), relief="flat")
upload_btn.pack(side="left", padx=10)


compression_mode = tk.StringVar(value="Serial")
radio_styles = {
    "font": ("Arial", 10),
    "padding": 3
}
ttk.Radiobutton(top_frame, text="Serial", variable=compression_mode, value="Serial").pack(side="left")
ttk.Radiobutton(top_frame, text="MPI", variable=compression_mode, value="MPI").pack(side="left")
ttk.Radiobutton(top_frame, text="OpenMP", variable=compression_mode, value="OpenMP").pack(side="left")
ttk.Radiobutton(top_frame, text="CUDA", variable=compression_mode, value="CUDA").pack(side="left")


run_btn = tk.Button(top_frame, text="Run Compression", command=run_compression,
                    bg="#007BFF", fg="white", font=("Arial", 10, "bold"), relief="flat")
run_btn.pack(side="left", padx=10)

# Threshold slider (below buttons)
threshold_frame = tk.Frame(root)
threshold_frame.pack(pady=5)

tk.Label(threshold_frame, text="Threshold").pack()
threshold_slider = tk.Scale(
    threshold_frame, 
    from_=0.0, to=1.0, 
    resolution=0.01, 
    orient="horizontal", 
    length=200,
    variable=threshold_var
)
threshold_slider.pack()

threshold_quant_frame = tk.Frame(root)
threshold_quant_frame.pack(pady=5)

tk.Label(threshold_quant_frame, text="Quantization").pack()
threshold_quant_slider = tk.Scale(
    threshold_quant_frame, 
    from_=0.0, to=1.0, 
    resolution=0.01, 
    orient="horizontal", 
    length=200,
    variable=threshold_quant_var
)
threshold_quant_slider.pack()

# Display area: Original - Metrics - Compressed
display_frame = tk.Frame(root)
display_frame.pack(pady=10, padx=10, fill="x")

# Left - Original Image
left_frame = tk.Frame(display_frame)
left_frame.pack(side="left", padx=10)
tk.Label(left_frame, text="Original Image").pack()
original_label = tk.Label(left_frame)
original_label.pack()
original_size_label = tk.Label(left_frame, text="Size: ")
original_size_label.pack()

# Center - Metrics
center_frame = tk.Frame(display_frame)
center_frame.pack(side="left", padx=20, ipadx=30, expand=True)
metric_labels = {}
for label in ["Compression Time", "Compression Rate (RAM : BIN)", "Original Image (RAM)", "Compressed File (BIN)"]:
    metric_labels[label] = tk.Label(center_frame, text=f"{label}:")
    metric_labels[label].pack(anchor="w")

# Right - Compressed Image
right_frame = tk.Frame(display_frame)
right_frame.pack(side="left", padx=10)
tk.Label(right_frame, text="Decompress Image").pack()
decompressed_label = tk.Label(right_frame)
decompressed_label.pack()
decompressed_size_label = tk.Label(right_frame, text="Size: ")
decompressed_size_label.pack()

# Log Output
log_text = tk.Text(root, height=15, width=100)
log_text.pack(padx=10, pady=10)

root.mainloop()
